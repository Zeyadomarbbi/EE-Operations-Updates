import unittest
from unittest.mock import patch

from selenium.common.exceptions import TimeoutException

import web_driver


class _Button:
    def __init__(self, driver, click_sends):
        self.driver = driver
        self.click_sends = click_sends
        self.enter_count = 0

    def is_displayed(self):
        return True

    def is_enabled(self):
        return True

    def click(self):
        if self.click_sends:
            self.driver.sent = True

    def send_keys(self, key):
        if str(key) in {"\ue007", "\ue006"}:
            self.enter_count += 1
            self.driver.sent = True


class _OutgoingMessage:
    def __init__(self, text):
        self.text = text

    def get_attribute(self, _name):
        return self.text


class _Driver:
    def __init__(self, click_sends, outgoing_text=""):
        self.sent = False
        self.outgoing_text = outgoing_text
        self.button = _Button(self, click_sends)
        self.switch_to = type("SwitchTo", (), {"active_element": self.button})()

    def find_element(self, _by, _xpath):
        return self.button

    def find_elements(self, _by, xpath):
        if xpath == web_driver._OUTGOING_MESSAGE_XPATH:
            return [_OutgoingMessage(self.outgoing_text)] if self.sent else []
        if xpath == web_driver._SEND_BUTTON_XPATH:
            return [self.button]
        return []

    def execute_script(self, _script, element):
        element.click()


class _ImmediateWait:
    def __init__(self, driver, _timeout):
        self.driver = driver

    def until(self, condition):
        result = condition(self.driver)
        if result:
            return result
        raise TimeoutException()


class WhatsAppDeliveryTests(unittest.TestCase):
    def setUp(self):
        self.delay = patch.object(web_driver.settings, "get_whatsapp_delay_seconds", return_value=0)
        self.delay.start()
        web_driver._last_confirmed_send_at = 0.0
        web_driver._whatsapp_session_warmed_up = True

    def tearDown(self):
        self.delay.stop()
        web_driver._last_confirmed_send_at = 0.0
        web_driver._whatsapp_session_warmed_up = False

    def test_first_send_waits_for_whatsapp_to_sync(self):
        driver = _Driver(click_sends=True)
        web_driver._whatsapp_session_warmed_up = False
        with (
            patch.object(web_driver, "WebDriverWait", _ImmediateWait),
            patch.object(web_driver.time, "sleep") as sleep,
        ):
            self.assertTrue(web_driver.send_current_whatsapp_message(driver))
        sleep.assert_called_once_with(web_driver._INITIAL_SEND_SYNC_SECONDS)
        self.assertTrue(web_driver._whatsapp_session_warmed_up)

    def test_button_send_requires_new_outgoing_message(self):
        driver = _Driver(click_sends=True)
        with patch.object(web_driver, "WebDriverWait", _ImmediateWait):
            self.assertTrue(web_driver.send_current_whatsapp_message(driver))
        self.assertTrue(driver.sent)
        self.assertEqual(driver.button.enter_count, 0)

    def test_enter_fallback_is_used_once_when_click_did_not_send(self):
        driver = _Driver(click_sends=False)
        with patch.object(web_driver, "WebDriverWait", _ImmediateWait):
            self.assertTrue(web_driver.send_current_whatsapp_message(driver))
        self.assertTrue(driver.sent)
        self.assertEqual(driver.button.enter_count, 1)

    def test_enter_retry_requires_the_latest_message_to_match(self):
        driver = _Driver(click_sends=False, outgoing_text="الرسالة المطلوبة")
        with patch.object(web_driver, "WebDriverWait", _ImmediateWait):
            self.assertTrue(
                web_driver.send_current_whatsapp_message(driver, expected_message="الرسالة المطلوبة")
            )
        self.assertEqual(driver.button.enter_count, 1)

    def test_mismatched_latest_message_is_not_confirmed(self):
        driver = _Driver(click_sends=True, outgoing_text="رسالة مختلفة")
        with patch.object(web_driver, "WebDriverWait", _ImmediateWait):
            with self.assertRaises(TimeoutException):
                web_driver.send_current_whatsapp_message(driver, expected_message="الرسالة المطلوبة")
        self.assertEqual(driver.button.enter_count, 1)

    def test_chat_hints_normalize_phone_and_name(self):
        hints = web_driver._chat_hint_variants("+201000000000", "د. محمد أحمد")
        self.assertIn("+201000000000", hints)
        self.assertIn("201000000000", hints)
        self.assertIn("د. محمد أحمد", hints)

    def test_configured_delay_blocks_the_next_send_globally(self):
        driver = _Driver(click_sends=True)
        web_driver._last_confirmed_send_at = 100.0
        with (
            patch.object(web_driver.settings, "get_whatsapp_delay_seconds", return_value=5),
            patch.object(web_driver, "WebDriverWait", _ImmediateWait),
            patch.object(web_driver.time, "monotonic", side_effect=[102.0, 105.0]),
            patch.object(web_driver.time, "sleep") as sleep,
        ):
            self.assertTrue(web_driver.send_current_whatsapp_message(driver))
        sleep.assert_called_once_with(3.0)

    def test_whatsapp_uses_only_the_dedicated_automation_profile(self):
        candidates = web_driver._edge_profile_candidates()
        self.assertEqual(len(candidates), 1)
        self.assertEqual(candidates[0]["user_data_dir"], web_driver.config.EDGE_AUTOMATION_USER_DATA_DIR)
        self.assertIsNone(candidates[0]["profile_directory"])


if __name__ == "__main__":
    unittest.main()
