$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$WshShell = New-Object -ComObject WScript.Shell
$ShortcutPath = Join-Path $env:USERPROFILE "Desktop\تم.lnk"
$LegacyShortcutPath = Join-Path $env:USERPROFILE "Desktop\EE Operations.lnk"
$LegacyArguments = "`"$here\run_app_silent.vbs`""

# Remove only the shortcut created by earlier versions of this application.
if (Test-Path $LegacyShortcutPath) {
    $LegacyShortcut = $WshShell.CreateShortcut($LegacyShortcutPath)
    if ($LegacyShortcut.Arguments -eq $LegacyArguments) {
        Remove-Item -LiteralPath $LegacyShortcutPath -Force
    }
}

$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = Join-Path $env:SystemRoot "System32\wscript.exe"
$Shortcut.Arguments = "`"$here\run_app_silent.vbs`""
$Shortcut.WorkingDirectory = $here
$Shortcut.WindowStyle = 7
$iconPath = Join-Path $here "app_icon.ico"
if (Test-Path $iconPath) {
    $Shortcut.IconLocation = $iconPath
}
$Shortcut.Description = "تم"
$Shortcut.Save()
Write-Output "Shortcut created at: $ShortcutPath"
