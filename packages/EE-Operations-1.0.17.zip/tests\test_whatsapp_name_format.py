import unittest

import pandas as pd

import msgs
import upload_files
from name_format import (
    render_teacher_name_placeholders,
    short_teacher_name,
    whatsapp_recipient_name,
)


class WhatsAppNameFormatTests(unittest.TestCase):
    def test_excel_code_formatting_removes_only_artificial_decimal_places(self):
        data = pd.DataFrame({
            "كود العميل": [123.0, "001.0", "009"],
            "كود الطلب": [456.0, "002.00", "010"],
            "كود الملف": [789.0, "003.0", "011"],
        })
        prepared = upload_files.prepare_delivery_data(data)
        self.assertEqual(prepared["كود العميل"].tolist(), ["123", "001", "009"])
        self.assertEqual(prepared["كود الطلب"].tolist(), ["456", "002", "010"])
        self.assertEqual(prepared["كود الملف"].tolist(), ["789", "003", "011"])

    def test_memo_name_respects_the_title_column(self):
        self.assertEqual(upload_files.format_memo_teacher_name("الدرعمي", "نعم"), "الدرعمي")
        self.assertEqual(upload_files.format_memo_teacher_name("محمود علي", "لا"), "أ. محمود علي")
        self.assertEqual(upload_files.format_memo_teacher_name("م. محمود علي", "لا"), "م. محمود علي")

    def test_short_name_keeps_only_first_name_and_title(self):
        cases = {
            "محمد أحمد علي": "أ. محمد",
            "د. محمد أحمد": "د. محمد",
            "م. أحمد علي": "م. أحمد",
            "أ. علي حسن": "أ. علي",
            "أستاذ. سامي عبد الله": "أستاذ. سامي",
            "عبد الرحمن أحمد علي": "أ. عبد الرحمن",
            "د. عبد الله محمود": "د. عبد الله",
            "أبو بكر محمد": "أ. أبو بكر",
            "ام كلثوم أحمد": "أ. ام كلثوم",
            "م. ابن سينا علي": "م. ابن سينا",
            "نور الدين محمود": "أ. نور الدين",
            "": "أ.",
        }
        for source, expected in cases.items():
            with self.subTest(source=source):
                self.assertEqual(short_teacher_name(source), expected)

    def test_old_title_templates_do_not_duplicate_the_title(self):
        self.assertEqual(
            render_teacher_name_placeholders("السلام عليكم أ. {الاسم}", "د. محمد أحمد"),
            "السلام عليكم د. محمد",
        )
        self.assertEqual(
            render_teacher_name_placeholders("السلام عليكم د. {اسم المعلم}", "د. محمد أحمد"),
            "السلام عليكم د. محمد",
        )

    def test_client_name_is_the_whatsapp_recipient(self):
        row = {"اسم العميل": "أبو بكر محمد", "اسم المعلم": "د. محمود علي"}
        self.assertEqual(whatsapp_recipient_name(row), "أبو بكر محمد")
        self.assertEqual(
            render_teacher_name_placeholders("السلام عليكم {اسم العميل}", row["اسم العميل"]),
            "السلام عليكم أ. أبو بكر",
        )

    def test_old_sheet_falls_back_to_teacher_name_for_whatsapp(self):
        self.assertEqual(whatsapp_recipient_name({"اسم المعلم": "د. محمود علي"}), "د. محمود علي")

    def test_direct_messages_ignore_raw_name_columns(self):
        rows = pd.DataFrame({
            "اسم المعلم": ["د. محمد أحمد"],
            "الاسم": ["محمد أحمد بالكامل"],
            "رقم الواتس": ["01000000000"],
        })
        message = msgs._render_message("السلام عليكم أ. {اسم المعلم} / {الاسم}", rows)
        self.assertEqual(message, "السلام عليكم د. محمد / د. محمد")

    def test_direct_messages_prefer_client_name_over_memo_name(self):
        rows = pd.DataFrame({
            "اسم العميل": ["أبو بكر محمد"],
            "اسم المعلم": ["د. محمود علي"],
            "رقم الواتس": ["01000000000"],
        })
        message = msgs._render_message("السلام عليكم {اسم المعلم} / {اسم العميل}", rows)
        self.assertEqual(message, "السلام عليكم أ. أبو بكر / أ. أبو بكر")

    def test_delivery_template_reserves_both_name_placeholders(self):
        rows = pd.DataFrame({
            "اسم المعلم": ["م. أحمد علي"],
            "الاسم": ["أحمد علي بالكامل"],
            "كود العميل": ["1"],
            "الرابط": ["https://example.test/order"],
        })
        original = upload_files.settings.get_teacher_whatsapp_template
        upload_files.settings.get_teacher_whatsapp_template = lambda: "السلام عليكم أ. {اسم المعلم} / {الاسم}"
        try:
            message = upload_files.build_teacher_whatsapp_message("م. أحمد علي", rows, "شغل 2026", False)
        finally:
            upload_files.settings.get_teacher_whatsapp_template = original
        self.assertEqual(message, "السلام عليكم م. أحمد / م. أحمد")

    def test_delivery_message_uses_client_name_not_memo_name(self):
        rows = pd.DataFrame({
            "اسم العميل": ["عبد الرحمن أحمد"],
            "اسم المعلم": ["د. محمود علي"],
            "كود العميل": ["1"],
            "الرابط": ["https://example.test/order"],
        })
        original = upload_files.settings.get_teacher_whatsapp_template
        upload_files.settings.get_teacher_whatsapp_template = lambda: "السلام عليكم {اسم المعلم} / {اسم العميل}"
        try:
            message = upload_files.build_teacher_whatsapp_message(
                whatsapp_recipient_name(rows.iloc[0]), rows, "شغل 2026", False
            )
        finally:
            upload_files.settings.get_teacher_whatsapp_template = original
        self.assertEqual(message, "السلام عليكم أ. عبد الرحمن / أ. عبد الرحمن")


if __name__ == "__main__":
    unittest.main()
