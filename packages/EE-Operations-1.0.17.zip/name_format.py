"""Small, shared display rules used by every WhatsApp workflow."""

import re


# The spreadsheets can contain roles beyond the common أ./د./م. forms. Any
# standalone token ending in a period is treated as the supplied title.
_TITLE = re.compile(r"^\S+\.$")
_NAME_PLACEHOLDER = re.compile(r"(?<!\S)\S+\.\s*\{(?:الاسم|اسم المعلم|اسم العميل)\}")
_ARABIC_DIACRITICS = re.compile(r"[\u064b-\u065f\u0670]")
_COMPOUND_NAME_STARTS = {"ابو", "ام", "عبد", "ابن", "بن", "ذو", "ذي"}


def _normalise_name_token(token):
    """Normalise only enough Arabic spelling to recognise compound first names."""
    token = _ARABIC_DIACRITICS.sub("", str(token).strip(".,،"))
    return token.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")


def _display_name_parts(parts):
    """Keep a two-word Arabic given name intact while avoiding full sheet names."""
    if len(parts) < 2:
        return parts[:1]

    first = _normalise_name_token(parts[0])
    second = _normalise_name_token(parts[1])
    if first in _COMPOUND_NAME_STARTS or second == "الدين":
        return parts[:2]
    return parts[:1]


def _has_name(value):
    if value is None:
        return False
    text = str(value).strip()
    return bool(text) and text.casefold() not in {"nan", "none", "<na>"}


def whatsapp_recipient_name(row):
    """Use the client name for WhatsApp, with a safe fallback for old sheets."""
    client_name = row.get("اسم العميل", "")
    if _has_name(client_name):
        return str(client_name).strip()
    teacher_name = row.get("اسم المعلم", "")
    return str(teacher_name).strip() if _has_name(teacher_name) else ""


def whatsapp_recipient_column(data):
    """Return the recipient column after optional client-name values are normalised."""
    return "اسم العميل" if "اسم العميل" in data.columns else "اسم المعلم"


def short_teacher_name(value):
    """Return a short name, retaining one title and recognised Arabic compounds."""
    parts = str(value or "").strip().split()
    if not parts:
        return "أ."

    if _TITLE.fullmatch(parts[0]):
        title = parts.pop(0)
    else:
        title = "أ."
    display_parts = _display_name_parts(parts)
    return title if not display_parts else f"{title} {' '.join(display_parts)}"


def render_teacher_name_placeholders(template, value):
    """Replace all supported recipient-name placeholders without duplicate titles."""
    template = _NAME_PLACEHOLDER.sub("{الاسم}", str(template))
    display_name = short_teacher_name(value)
    return (
        template.replace("{اسم المعلم}", display_name)
        .replace("{اسم العميل}", display_name)
        .replace("{الاسم}", display_name)
    )
