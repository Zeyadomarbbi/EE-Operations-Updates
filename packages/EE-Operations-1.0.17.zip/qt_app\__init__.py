"""PySide6 presentation layer for Tam."""
