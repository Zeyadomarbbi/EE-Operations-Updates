import os
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

import upload_files


class DeliverySafetyTests(unittest.TestCase):
    def test_link_write_preserves_a_row_added_during_processing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "orders.xlsx")
            initial = pd.DataFrame([{"كود العميل": "1", "كود الطلب": "10", "الرابط": ""}])
            initial.to_excel(path, index=False)
            processed = upload_files.read_delivery_sheet_safely(path)
            processed["الرابط"] = "https://drive.example/order-10"
            latest = pd.concat([
                upload_files.read_delivery_sheet_safely(path),
                pd.DataFrame([{"كود العميل": "2", "كود الطلب": "20", "الرابط": ""}]),
            ], ignore_index=True)
            latest.to_excel(path, index=False)

            merged = upload_files.write_delivery_links_preserving_updates(path, processed)

            self.assertEqual(merged.loc[0, "الرابط"], "https://drive.example/order-10")
            self.assertEqual(str(merged.loc[1, "كود الطلب"]), "20")
            self.assertTrue(pd.isna(merged.loc[1, "الرابط"]))

    def test_failed_rows_include_the_processing_stage(self):
        rows = pd.DataFrame([{"كود الطلب": "10"}])
        failed = upload_files.failed_rows_for_stage(rows, "التقفيل", "تعذر تجميع PDF الصور")
        self.assertEqual(failed.loc[0, "مرحلة الفشل"], "التقفيل")
        self.assertEqual(failed.loc[0, "سبب الفشل"], "تعذر تجميع PDF الصور")

    def test_image_protection_failure_never_counts_the_original_pdf_as_success(self):
        with tempfile.TemporaryDirectory() as directory:
            pdf_path = os.path.join(directory, "order.pdf")
            with open(pdf_path, "wb") as output:
                output.write(b"original pdf")
            with (
                patch.object(upload_files, "wait_for_saved_pdf", return_value=True),
                patch.object(upload_files, "process_pdf_as_images", side_effect=RuntimeError("image conversion failed")),
                patch.object(upload_files, "log_timing"),
                patch("builtins.print"),
                patch.object(upload_files.time, "sleep"),
            ):
                with self.assertRaisesRegex(RuntimeError, "image conversion failed"):
                    upload_files.finalize_pdf_output(pdf_path, protect_as_images=True)


if __name__ == "__main__":
    unittest.main()
