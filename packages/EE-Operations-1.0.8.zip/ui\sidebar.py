"""الشريط الجانبي: اللوجو + التنقل بين الصفحات + تبديل المظهر أسفل الشريط."""
import os
from tkinter import ttk
import ttkbootstrap as tb
from PIL import Image, ImageTk

from . import theme as th


class Sidebar(ttk.Frame):
    def __init__(self, parent, logo_path, nav_items, on_nav, on_toggle_theme=None, theme_key="dark", version_text="", **kwargs):
        """
        nav_items: قائمة (key, icon, label) بترتيب الظهور.
        on_nav(key): بتتنده أول ما اليوزر يدوس على أي عنصر تنقل (وأول ما الشريط يتبني، عشان تفتح أول صفحة تلقائيًا).
        """
        super().__init__(parent, width=th.SIDEBAR_WIDTH, style="Sidebar.TFrame", **kwargs)
        self.pack_propagate(False)
        self.on_nav = on_nav
        self._nav_buttons = {}
        self._active_key = None

        self._build_logo(logo_path)
        ttk.Separator(self).pack(fill="x")
        self._build_nav(nav_items)
        self._build_footer(on_toggle_theme, theme_key, version_text)

    def _build_logo(self, logo_path):
        wrap = ttk.Frame(self, style="Sidebar.TFrame", padding=(th.SPACE_LG, th.SPACE_XL, th.SPACE_LG, th.SPACE_LG))
        wrap.pack(fill="x")
        self._logo_img = None
        if logo_path and os.path.exists(logo_path):
            try:
                im = Image.open(logo_path)
                target_w = th.SIDEBAR_WIDTH - 2 * th.SPACE_LG
                ratio = target_w / im.width
                im = im.resize((target_w, int(im.height * ratio)), Image.LANCZOS)
                self._logo_img = ImageTk.PhotoImage(im)
                ttk.Label(wrap, image=self._logo_img).pack(anchor="w")
            except Exception:
                pass
        ttk.Label(wrap, text="EE Operations", style="SectionTitle.TLabel").pack(anchor="w", pady=(th.SPACE_SM, 0))
        ttk.Label(wrap, text="Operations Control Center", style="Small.TLabel").pack(anchor="w", pady=(2, 0))

    def _build_nav(self, nav_items):
        nav_wrap = ttk.Frame(self, style="Sidebar.TFrame", padding=(th.SPACE_MD, th.SPACE_SM))
        nav_wrap.pack(fill="x")
        for key, icon, label in nav_items:
            btn = tb.Button(
                nav_wrap,
                text=f"  {icon}   {label}",
                bootstyle="secondary-outline",
                command=lambda k=key: self._select(k),
            )
            btn.pack(fill="x", pady=2, ipady=6)
            self._nav_buttons[key] = btn
        if nav_items:
            # هنا بس شكل الزرار النشط (من غير ما ننده on_nav) — لأن on_nav (show_page)
            # لسه بيتبني في gui.py ومحتاج يشاور على "sidebar" اللي لسه بيتبني هو نفسه
            # دلوقتي. المتصل (gui.py) هو اللي هيفتح أول صفحة بنفسه بعد ما الإنشاء يخلص.
            self.activate(nav_items[0][0])

    def _build_footer(self, on_toggle_theme, theme_key, version_text):
        footer = ttk.Frame(self, style="Sidebar.TFrame", padding=th.SPACE_MD)
        footer.pack(side="bottom", fill="x")
        ttk.Separator(footer).pack(fill="x", pady=(0, th.SPACE_SM))
        self.theme_btn = None
        if on_toggle_theme:
            self.theme_btn = tb.Button(
                footer,
                text=self._theme_btn_text(theme_key),
                bootstyle="secondary-link",
                command=on_toggle_theme,
            )
            self.theme_btn.pack(fill="x", anchor="w")
        if version_text:
            ttk.Label(footer, text=version_text, style="Small.TLabel").pack(anchor="w", pady=(th.SPACE_XS, 0))

    @staticmethod
    def _theme_btn_text(theme_key):
        return "☾  الوضع الفاتح" if theme_key == "dark" else "☀  الوضع الغامق"

    def activate(self, key):
        """تحديث شكل العنصر النشط بس (من غير ما ننده on_nav) — تُستخدم لما الصفحة
        بتتغيّر برمجيًا (زي التنقل التلقائي بعد ما معالجة تخلص)."""
        self._active_key = key
        for k, btn in self._nav_buttons.items():
            btn.configure(bootstyle=("primary" if k == key else "secondary-outline"))

    def _select(self, key):
        self.activate(key)
        self.on_nav(key)

    def set_theme_button_text(self, theme_key):
        if self.theme_btn is not None:
            self.theme_btn.configure(text=self._theme_btn_text(theme_key))
