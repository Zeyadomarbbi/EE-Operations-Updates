"""
مكوّنات واجهة قابلة لإعادة الاستخدام (Card, عناوين الصفحات، مؤشر حالة، حالة فاضية،
صف اختيار ملف/مجلد، لوحة تقدّم). كل الملفات التانية في ui/ وgui.py بتبني عليها
بدل ما تكرر نفس التنسيق في كل مكان.

كل الألوان هنا بتتسحب من style الحالي وقت الرسم (مش قيم ثابتة)، عشان لو المستخدم
بدّل المظهر (فاتح/غامق) من الشريط الجانبي، المكوّنات دي تتلوّن صح تلقائيًا.
"""
import os
from tkinter import ttk
import ttkbootstrap as tb

from . import theme as th
from . import icons


def get_colors():
    return tb.Style().colors


class Card(ttk.Frame):
    """كارت بحدود رفيعة بس (بدون تظليل/ألوان غريبة)، بيستخدم ستايل مسمّى (Card.TFrame)
    عشان يتلوّن تلقائيًا مع أي تبديل ثيم من غير أي كود إضافي وقت التبديل."""

    def __init__(self, parent, padding=th.SPACE_XL, **kwargs):
        super().__init__(parent, style="Card.TFrame", **kwargs)
        self.body = ttk.Frame(self, style="CardBody.TFrame")
        self.body.pack(fill="both", expand=True, padx=padding, pady=padding)


def page_header(parent, title, subtitle=None):
    """عنوان أعلى الصفحة + وصف سطر واحد تحته."""
    wrap = ttk.Frame(parent)
    ttk.Label(wrap, text=title, style="PageTitle.TLabel").pack(anchor="w")
    if subtitle:
        ttk.Label(wrap, text=subtitle, style="PageSubtitle.TLabel").pack(anchor="w", pady=(th.SPACE_XS, 0))
    return wrap


def section_title(parent, title, subtitle=None, wraplength=520):
    """عنوان أصغر جوه كارت."""
    wrap = ttk.Frame(parent)
    ttk.Label(wrap, text=title, style="SectionTitle.TLabel").pack(anchor="w")
    if subtitle:
        ttk.Label(
            wrap, text=subtitle, style="Small.TLabel", wraplength=wraplength, justify="right",
        ).pack(anchor="w", pady=(2, 0), fill="x")
    return wrap


class StatusPill(tb.Label):
    """شارة حالة صغيرة ملوّنة (جاهز / جاري / تم / فشل / تنبيه) بأيقونة نصية + كلمة."""

    def __init__(self, parent, status="ready", **kwargs):
        self._status = status
        super().__init__(
            parent,
            text=self._text_for(status),
            bootstyle=self._style_for(status),
            padding=(10, 3),
            **kwargs,
        )

    @staticmethod
    def _text_for(status):
        return f"{icons.STATUS_ICONS.get(status, '')}  {th.STATUS_LABEL_AR.get(status, status)}"

    @staticmethod
    def _style_for(status):
        return f"{th.STATUS_BOOTSTYLE.get(status, 'secondary')}-inverse"

    def set_status(self, status):
        self._status = status
        self.configure(text=self._text_for(status), bootstyle=self._style_for(status))


def empty_state(parent, icon, title, subtitle, action_text=None, action_cmd=None):
    """حالة فاضية منسّقة (بدل شاشة فاضية سادة) — بترجع Frame جاهز يتحط بـ pack/grid."""
    wrap = ttk.Frame(parent)
    ttk.Label(wrap, text=icon, style="EmptyStateIcon.TLabel").pack(pady=(0, th.SPACE_SM))
    ttk.Label(wrap, text=title, style="SectionTitle.TLabel").pack()
    ttk.Label(
        wrap, text=subtitle, style="Small.TLabel", wraplength=360, justify="center",
    ).pack(pady=(th.SPACE_XS, th.SPACE_BASE))
    if action_text and action_cmd:
        tb.Button(wrap, text=action_text, command=action_cmd, bootstyle="primary").pack()
    return wrap


class FilePickerRow(ttk.Frame):
    """صف اختيار ملف/مجلد قابل لإعادة الاستخدام: زرار + اسم الملف الحالي + شارة حالة."""

    def __init__(self, parent, label, button_text, on_pick=None, **kwargs):
        super().__init__(parent, **kwargs)
        self._label = label

        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Label(top, text=label, style="Small.TLabel").pack(anchor="w")

        row = ttk.Frame(self)
        row.pack(fill="x", pady=(4, 0))

        self.pick_button = tb.Button(row, text=button_text, command=on_pick, bootstyle="secondary-outline")
        self.pick_button.pack(side="left")

        self.status_pill = StatusPill(row, status="ready")
        self.status_pill.pack(side="left", padx=(th.SPACE_SM, 0))

        self.path_label = ttk.Label(self, text="", style="Mono.TLabel", wraplength=620)
        self.path_label.pack(anchor="w", pady=(2, 0))

    def set_path(self, path):
        if path:
            self.status_pill.set_status("completed")
            self.path_label.configure(text=path)
        else:
            self.status_pill.set_status("ready")
            self.path_label.configure(text="لم يتم الاختيار بعد")


class ProgressPanel(ttk.Frame):
    """
    لوحة تقدّم حقيقية (مش نسبة وهمية): بتتحدث بعدد العملاء اللي خلصوا فعليًا
    من إجمالي العدد الحقيقي، لأن المعالجة والرفع والواتساب بيحصلوا متوازيين
    (مفيش "خطوات متتالية" حقيقية نقدر نعرضها بصدق).
    """

    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self._build()
        self.hide()

    def _build(self):
        self.configure(style="Card.TFrame", padding=th.SPACE_BASE)
        header = ttk.Frame(self)
        header.pack(fill="x")
        self.title_label = ttk.Label(header, text="حالة التشغيل", style="SectionTitle.TLabel")
        self.title_label.pack(side="left")
        self.counter_label = ttk.Label(header, text="", style="StatusHeading.TLabel")
        self.counter_label.pack(side="right")

        self.status_label = ttk.Label(self, text="", style="Small.TLabel", wraplength=760, justify="right")
        self.status_label.pack(anchor="w", pady=(2, th.SPACE_SM))

        self.bar = tb.Progressbar(self, mode="determinate", bootstyle="info-striped")
        self.bar.pack(fill="x")

        self.pipeline = ttk.Frame(self)
        self.pipeline.pack(fill="x", pady=(th.SPACE_MD, 0))
        self._stage_labels = {}
        for key, label in (
            ("close", "تجهيز وتقفيل الطلبات"),
            ("upload", "الرفع على Google Drive"),
            ("send", "إرسال WhatsApp"),
        ):
            row = ttk.Frame(self.pipeline)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=label, style="Small.TLabel").pack(side="left")
            state = ttk.Label(row, text="في الانتظار", style="Small.TLabel")
            state.pack(side="right")
            self._stage_labels[key] = state

    def start(self, status_text="جاري التنفيذ...", total=None):
        self.title_label.configure(text=status_text)
        self.pack(fill="x", pady=(0, th.SPACE_BASE))
        for label in self._stage_labels.values():
            label.configure(text="في الانتظار")
        if total:
            self.bar.configure(mode="determinate", maximum=total, value=0)
            self.status_label.configure(text=f"0 من {total} عميل")
            self.counter_label.configure(text="0%")
        else:
            self.status_label.configure(text="جاري التنفيذ...")
            self.counter_label.configure(text="")
            self.bar.configure(mode="indeterminate")
            self.bar.start(12)

    def update_progress(self, done, total, extra_text=""):
        if total > 0:
            if str(self.bar.cget("mode")) == "indeterminate":
                self.bar.stop()
                self.bar.configure(mode="determinate", maximum=total)
            self.bar.configure(value=done)
            self.counter_label.configure(text=f"{round((done / total) * 100)}%")
        text = f"{done} من {total} عميل خلصوا (معالجة + رفع + واتساب)"
        if extra_text:
            text += f" — {extra_text}"
        self.status_label.configure(text=text)

    def set_stage(self, text):
        """Updates the human-facing current step without changing progress."""
        self.status_label.configure(text=text)
        normalized = text.lower()
        if "تقفيل" in normalized or "معالجة" in normalized:
            active = "close"
        elif "رفع" in normalized or "drive" in normalized:
            active = "upload"
        elif "واتساب" in normalized or "whatsapp" in normalized:
            active = "send"
        else:
            return
        for key, label in self._stage_labels.items():
            label.configure(text="جارٍ التنفيذ" if key == active else label.cget("text"))

    def finish(self, text, success=True):
        self.bar.stop()
        try:
            maximum = float(self.bar.cget("maximum"))
        except (TypeError, ValueError):
            maximum = 1
        self.bar.configure(mode="determinate", value=maximum)
        self.title_label.configure(text=text)
        self.status_label.configure(text="")
        self.counter_label.configure(text="100%" if success else "")
        for label in self._stage_labels.values():
            if label.cget("text") == "جارٍ التنفيذ":
                label.configure(text="تم")

    def hide(self):
        self.bar.stop()
        self.pack_forget()
