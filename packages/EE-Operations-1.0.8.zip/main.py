"""Default launcher. Set EE_USE_TK=1 only to use the legacy interface."""

import os


def main():
    if os.getenv("EE_USE_TK") == "1":
        from gui import create_gui
        create_gui()
        return

    from qt_main import main as start_qt
    start_qt()


if __name__ == "__main__":
    main()
