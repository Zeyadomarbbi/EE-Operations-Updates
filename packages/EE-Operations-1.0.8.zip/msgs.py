"""Direct WhatsApp messages, deliberately serial to protect the account."""

import os
import re
import time
import urllib.parse
from datetime import datetime

import pandas as pd

import config
import settings
import web_driver
from name_format import short_teacher_name


excel_file2 = None


def _phone(value):
    number = str(value).strip().split(".")[0]
    if number.startswith("0"):
        number = config.EGYPT_COUNTRY_CODE + number[1:]
    elif not number.startswith("+"):
        number = config.EGYPT_COUNTRY_CODE + number
    if not number[1:].isdigit():
        raise ValueError(f"رقم واتساب غير صالح: {number}")
    return number


def _render_message(template, rows):
    teacher = short_teacher_name(rows.iloc[0].get("اسم المعلم", ""))
    message = template.replace("{اسم المعلم}", teacher).replace("{الاسم}", teacher)
    for placeholder in re.findall(r"{(.*?)}", message):
        column = next((item for item in rows.columns if str(item).strip() == placeholder.strip()), None)
        if column:
            values = []
            for value in rows[column]:
                if pd.notna(value) and str(value).strip() and str(value).strip() not in values:
                    values.append(str(value).strip())
            message = message.replace("{" + placeholder + "}", "\n".join(values))
    return message


def _failure_record(rows, number, reason):
    first = rows.iloc[0].to_dict()
    first["رقم الواتساب"] = number
    first["سبب فشل الإرسال"] = str(reason)
    return first


def _export_failures(records):
    if not records:
        return None
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    os.makedirs(desktop, exist_ok=True)
    path = os.path.join(desktop, f"فشل_رسائل_واتساب_{datetime.now():%Y%m%d_%H%M%S}.xlsx")
    pd.DataFrame(records).to_excel(path, index=False)
    return path


def send_custom_whatsapp_messages(label_status, message_entry=None, custom_message=None, progress_callback=None):
    """Send one confirmed message per phone and export every failed group."""
    global excel_file2

    def status(text, color="black"):
        label_status.after(0, lambda: label_status.config(text=text, foreground=color))

    if not excel_file2:
        raise ValueError("لم يتم اختيار ملف Excel للرسائل.")
    template = (custom_message if custom_message is not None else message_entry.get("1.0", "end")).strip()
    if not template:
        raise ValueError("اكتب نص الرسالة قبل الإرسال.")

    data = pd.read_excel(excel_file2)
    data.columns = data.columns.str.strip()
    if "رقم الواتس" not in data.columns:
        raise ValueError("ملف الرسائل لا يحتوي على عمود «رقم الواتس».")

    groups = list(data.groupby("رقم الواتس", sort=False))
    failures = []
    sent = 0
    for index, (raw_phone, rows) in enumerate(groups, start=1):
        if progress_callback:
            progress_callback(index - 1, len(groups), f"تجهيز رسالة WhatsApp {index} من {len(groups)}")
        number = ""
        try:
            number = _phone(rows.iloc[0]["رقم الواتس"])
            message = _render_message(template, rows)
            with web_driver.driver_lock:
                driver = web_driver.ensure_whatsapp_ready()
                if driver is None:
                    raise RuntimeError("تعذر تجهيز WhatsApp Web.")
                driver.get(f"{config.WHATSAPP_SEND_URL_BASE}?phone={number}&text={urllib.parse.quote(message)}")
                was_unread = web_driver.current_chat_is_unread(driver)
                # The send button exists only after the target chat and composer load.
                web_driver.send_current_whatsapp_message(driver)
                if was_unread:
                    web_driver.restore_current_chat_unread(driver)
            sent += 1
            status(f"تم إرسال الرسالة وتأكيدها إلى {number}", "green")
        except Exception as exc:
            failures.append(_failure_record(rows, number or str(raw_phone), exc))
            status(f"فشل الإرسال إلى {number or raw_phone}: {exc}", "red")
        finally:
            if progress_callback:
                progress_callback(index, len(groups), f"رسائل WhatsApp: {index} من {len(groups)}")

        if index < len(groups):
            time.sleep(settings.get_whatsapp_delay_seconds())

    report = _export_failures(failures)
    if report:
        status(f"تم إرسال {sent} رسالة. تقرير الأرقام الفاشلة: {report}", "red")
    else:
        status(f"تم إرسال وتأكيد كل الرسائل ({sent}).", "green")
    return report
