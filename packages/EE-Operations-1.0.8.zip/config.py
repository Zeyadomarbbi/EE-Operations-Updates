import os
import tempfile

# ==========================================================================
# القسم 1: الحاجة الوحيدة اللي ممكن تحتاج تغيّرها لما تنقل التطبيق لجهاز جديد
# ==========================================================================

# اسم ملف الـ credentials بتاع Google Cloud project اللي بترفع عليه.
# غيّره فقط لو هتستخدم Google Cloud project مختلف تمامًا (يعني ملف client_secret مختلف الاسم).
# لو نفس الـ project وبس عايز تسجل دخول بحساب Drive مختلف، سيب القيمة دي زي ما هي.
GOOGLE_CREDENTIALS_PATH = "client_secret_558788079395-j598vvethlsljirehp53j7luefhgnrao.apps.googleusercontent.com.json"

# اسم ملف التوكين المحفوظ. عادةً مش محتاج تغييره — لو عايز تستخدم حساب Google Drive
# مختلف، امسح ملف token.json من الفولدر (أو متنقلوش للجهاز الجديد) والبرنامج هيفتح
# صفحة تسجيل دخول Google تلقائيًا أول مرة ويحفظ توكين الحساب الجديد بنفس الاسم ده.
GOOGLE_TOKEN_PATH = "token.json"


# ==========================================================================
# القسم 2: بتتحسب تلقائيًا من الجهاز نفسه — عادةً مش محتاجة أي تعديل يدوي
# ==========================================================================

# بروفايل Edge بتاع المستخدم اللي شغّل البرنامج، وده اللي فيه جلسة واتساب ويب
# (بيحدد "أي حساب واتساب" هيتبعت منه). بيتحسب تلقائيًا من يوزر ويندوز الحالي،
# فمش محتاج تغيير لما تنقل لجهاز جديد — بس لازم تسجل دخول واتساب ويب مرة واحدة
# على البروفايل ده على الجهاز الجديد (سكان كود QR).
EDGE_USER_DATA_DIR = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Edge", "User Data")
EDGE_PROFILE_DIRECTORY = "Default"
EDGE_AUTOMATION_USER_DATA_DIR = os.path.join(os.environ.get("LOCALAPPDATA", ""), "EEOperations", "EdgeAutomationProfile")

# ملف مؤقت بيتكتب عليه اللوجو الشفاف قبل ما يتحط في الوورد، وبيتمسح بعدها.
# بيتحط في مجلد Temp بتاع ويندوز نفسه (مش مربوط بقرص معين)، فمش محتاج تعديل.
TRANSPARENT_LOGO_TEMP_PATH = os.path.join(tempfile.gettempdir(), "temp_transpaernt_logo.png")


# ==========================================================================
# القسم 3: إعدادات ثابتة خاصة بنشاط الشركة (المفروض متتغيرش لما تنقل جهاز)
# ==========================================================================

# ---------- Google Drive API ----------
GOOGLE_DRIVE_SCOPES = ["https://www.googleapis.com/auth/drive.file"]

# أسماء المجلدات الرئيسية على Google Drive
DRIVE_FOLDER_GENERAL_PRODUCTS = "منتجات عامة ( كود المبيعات)"
DRIVE_FOLDER_OLD_WORK = "شغل قديم"

# ---------- WhatsApp ----------
WHATSAPP_WEB_URL = "https://web.whatsapp.com"
WHATSAPP_SEND_URL_BASE = "https://web.whatsapp.com/send"
WHATSAPP_PROTOCOL_SEND_BASE = "whatsapp://send"
WHATSAPP_GROUP_INVITE_LINK = "https://chat.whatsapp.com/GPgzyGHEt42A9mqKYlM3TD"
EGYPT_COUNTRY_CODE = "+20"

# ---------- باسورد حماية الـ PDF ----------
# اللاحقة (زي "2425") بتتحسب تلقائيًا من اسم فولدر الشغل المختار،
# راجع settings.get_password_year_suffix()
PASSWORD_PREFIX = "Is"


# ==========================================================================
# القسم 4: مسارات فرعية جوه فولدر الشغل المُختار من الدروب داون في الواجهة
# (زي "شغل 2025")، ونفسه بيتحدد وقت التشغيل — راجع settings.list_work_folders()
# ==========================================================================
ORDERS_SUBDIR = "الطلبات"
LOGO_ORDERS_SUBDIR = "طلبات اللوجو"
WHATSAPP_DATA_SUBDIR = r"رسائل واتساب\البيانات.xlsx"


# ==========================================================================
# القسم 5: إعدادات قديمة — مستخدمة بس جوه كود "شغل 2024" المتوقف (Deprecated)
# لو مسحت شغل 2024 من الكود خالص يوم ما، امسح القسم ده كمان
# ==========================================================================
ORDERS_SUBPATH_2024 = r"شغل 2024\الطلبات"
LOGO_ORDERS_SUBPATH_2024 = r"شغل 2024\طلبات اللوجو"
PASSWORD_YEAR_SUFFIX_2024 = "2324"
