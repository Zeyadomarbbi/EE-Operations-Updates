import os
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google_auth_httplib2 import AuthorizedHttp
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import httplib2
import webbrowser
from tkinter import messagebox
from concurrent.futures import ThreadPoolExecutor
import socket
import threading
import re
import requests
import json
from googleapiclient.errors import HttpError

import config
import settings
SCOPES = config.GOOGLE_DRIVE_SCOPES
_DRIVE_HTTP_TIMEOUT_SECONDS = 180
_DRIVE_UPLOAD_CHUNK_SIZE = 5 * 1024 * 1024
_UPLOAD_SESSION_STATE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    ".drive_upload_sessions.json",
)

# قفل حول قراءة/تجديد وحفظ التوكين، عشان لو أكتر من عميل (أو أكتر من فلو زي الطلبات والشعار)
# بيرفعوا على درايف في نفس الوقت ميحصلش تعارض وهم بيكتبوا في ملف التوكين مع بعض
_token_lock = threading.Lock()

# قفل حول إنشاء/البحث عن الفولدر الرئيسي المشترك بين كل العملاء (والفلوهات) على درايف
# عشان الرفع المتوازي ميعملش نسخة مكررة من نفس الفولدر لو أكتر من ثريد وصل لها في نفس اللحظة
_shared_folder_lock = threading.Lock()
_folder_cache_lock = threading.Lock()
_folder_cache = {}

def authenticate_google_drive():
    """
    المصادقة مع Google Drive بحيث المستخدم يختار حسابه
    ويحفظ التوكين علشان يستخدمه بعدين بدون تسجيل دخول جديد
    """
    with _token_lock:
        creds = None
        token_path = config.GOOGLE_TOKEN_PATH  # تخزين التوكين في ملف
        credentials_path = config.GOOGLE_CREDENTIALS_PATH  # ملف إعدادات Google API

        # التحقق لو كان التوكين محفوظ بالفعل
        if os.path.exists(token_path):
            creds = Credentials.from_authorized_user_file(token_path, SCOPES)

        # لو مفيش توكين أو التوكين انتهت صلاحيته
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
                creds = flow.run_local_server(port=0)

            # حفظ التوكين علشان المستخدم ما يحتاجش تسجيل دخول كل مرة
            with open(token_path, "w") as token_file:
                token_file.write(creds.to_json())

        # Direct uploads can time out on slower connections. Keep each API request
        # alive long enough for the resumable uploader to finish its current chunk.
        http = AuthorizedHttp(
            creds,
            http=httplib2.Http(timeout=_DRIVE_HTTP_TIMEOUT_SECONDS),
        )
        return build("drive", "v3", http=http, cache_discovery=False)


def switch_google_account():
    """
    يمسح التوكين المحفوظ حاليًا ويعيد فتح صفحة تسجيل الدخول، عشان المستخدم
    يقدر يختار حساب Google Drive مختلف. لو الملف مش موجود أصلًا، بترجع نفس
    نتيجة authenticate_google_drive() العادية (تسجيل دخول لأول مرة).
    """
    with _token_lock:
        token_path = config.GOOGLE_TOKEN_PATH
        if os.path.exists(token_path):
            os.remove(token_path)
    return authenticate_google_drive()


def find_folder(service, folder_name, parent_id=None):
    """ البحث عن مجلد بالاسم وإرجاع الـ ID إذا وجد """
    query = f"name='{folder_name}' and mimeType='application/vnd.google-apps.folder'"
    if parent_id:
        query += f" and '{parent_id}' in parents"

    results = service.files().list(q=query, fields="files(id, name, parents)").execute()
    folders = results.get('files', [])

    if folders:
        print(f"📂 العثور على المجلد: {folders[0]['name']} - ID: {folders[0]['id']}")
        return folders[0]['id']

    return None


def create_folder(service, folder_name, parent_folder_id=None):
    """ إنشاء مجلد جديد في Google Drive وضمان حفظه في My Drive """
    cache_key = (parent_folder_id or "root", folder_name)
    with _folder_cache_lock:
        cached_folder_id = _folder_cache.get(cache_key)
    if cached_folder_id:
        print(f"♻️ تم استخدام فولدر موجود من الكاش: {folder_name} - ID: {cached_folder_id}")
        return cached_folder_id

    folder_id = find_folder(service, folder_name, parent_folder_id)
    if folder_id:
        print(f'♻️ تم استخدام فولدر موجود: {folder_name} - ID: {folder_id}')
        with _folder_cache_lock:
            _folder_cache[cache_key] = folder_id
        return folder_id

    file_metadata = {
        'name': folder_name,
        'mimeType': 'application/vnd.google-apps.folder',
    }

    if parent_folder_id:
        file_metadata['parents'] = [parent_folder_id]  # إضافة الفولدر لمجلد رئيسي
    else:
        file_metadata['parents'] = ["root"]  # جعله في My Drive بشكل صريح

    folder = service.files().create(body=file_metadata, fields='id, name, parents').execute()

    print(f'🆕 تم إنشاء فولدر جديد: {folder["name"]} - ID: {folder["id"]}')
    folder_id = folder.get('id')
    with _folder_cache_lock:
        _folder_cache[cache_key] = folder_id
    return folder_id


import time

def list_folder_file_ids(service, folder_id):
    """يجلب ملفات الفولدر مرة واحدة بدل طلب API منفصل لكل ملف."""
    files_by_name = {}
    page_token = None
    while True:
        result = service.files().list(
            q=f"'{folder_id}' in parents and trashed=false",
            spaces="drive",
            fields="nextPageToken, files(id, name)",
            pageToken=page_token,
        ).execute()
        files_by_name.update({item["name"]: item["id"] for item in result.get("files", [])})
        page_token = result.get("nextPageToken")
        if not page_token:
            return files_by_name


def upload_file(service, file_path, folder_id, existing_files=None, max_retries=5, progress_callback=None):
    """رفع ملف إلى Google Drive داخل مجلد معين مع دعم الانقطاع ومنع التكرار"""

    file_name = os.path.basename(file_path)
    started_at = time.perf_counter()

    # 🧠 تحقق أولًا: هل الملف مرفوع بنفس الاسم في نفس المجلد؟
    if existing_files is None:
        existing_files = list_folder_file_ids(service, folder_id)

    if file_name in existing_files:
        print(f"📄 الملف {file_name} موجود بالفعل في المجلد. لن يتم رفعه مرة أخرى.")
        print(f"⏱️ زمن التحقق/التخطي: {time.perf_counter() - started_at:.2f} ث | {file_name}")
        return existing_files[file_name]

    # ✅ لو مش موجود، نبدأ الرفع
    file_metadata = {
        'name': file_name,
        'parents': [folder_id]
    }

    # Use the raw resumable protocol for large files. It avoids httplib2's
    # redirect handling and can continue from Drive's confirmed byte offset.
    if os.path.getsize(file_path) >= _DRIVE_UPLOAD_CHUNK_SIZE:
        credentials = getattr(service._http, "credentials", None)
        if credentials is None:
            raise RuntimeError("Drive credentials are unavailable for resumable upload")
        if not credentials.valid:
            credentials.refresh(Request())

        total_size = os.path.getsize(file_path)
        headers = {
            "Authorization": f"Bearer {credentials.token}",
            "Content-Type": "application/json; charset=UTF-8",
            "X-Upload-Content-Type": "application/pdf",
            "X-Upload-Content-Length": str(total_size),
        }
        session_key = os.path.abspath(file_path)
        sessions = {}
        if os.path.exists(_UPLOAD_SESSION_STATE_PATH):
            try:
                with open(_UPLOAD_SESSION_STATE_PATH, "r", encoding="utf-8") as state_file:
                    sessions = json.load(state_file)
            except (OSError, json.JSONDecodeError):
                sessions = {}

        saved_session = sessions.get(session_key, {})
        session_url = saved_session.get("url") if saved_session.get("size") == total_size else None
        if session_url:
            print(f"[DRIVE] Resuming saved upload session | {file_name}")
        else:
            start_response = requests.post(
                "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable",
                headers=headers,
                json=file_metadata,
                timeout=(30, _DRIVE_HTTP_TIMEOUT_SECONDS),
                allow_redirects=False,
            )
            session_url = start_response.headers.get("Location")
            if start_response.status_code not in (200, 201) or not session_url:
                raise RuntimeError(
                    f"Drive resumable session could not start: HTTP {start_response.status_code}"
                )
            sessions[session_key] = {"url": session_url, "size": total_size}
            with open(_UPLOAD_SESSION_STATE_PATH, "w", encoding="utf-8") as state_file:
                json.dump(sessions, state_file)
            print(f"[DRIVE] Resumable session started | {file_name}")
        confirmed_offset = 0
        probe = requests.put(
            session_url,
            headers={
                "Authorization": f"Bearer {credentials.token}",
                "Content-Length": "0",
                "Content-Range": f"bytes */{total_size}",
            },
            data=b"",
            timeout=(30, _DRIVE_HTTP_TIMEOUT_SECONDS),
            allow_redirects=False,
        )
        if probe.status_code == 308:
            match = re.search(r"\d+-(\d+)", probe.headers.get("Range", ""))
            confirmed_offset = int(match.group(1)) + 1 if match else 0
        elif probe.status_code in (200, 201):
            sessions.pop(session_key, None)
            with open(_UPLOAD_SESSION_STATE_PATH, "w", encoding="utf-8") as state_file:
                json.dump(sessions, state_file)
            existing_files[file_name] = probe.json()["id"]
            return probe.json()["id"]
        else:
            sessions.pop(session_key, None)
            with open(_UPLOAD_SESSION_STATE_PATH, "w", encoding="utf-8") as state_file:
                json.dump(sessions, state_file)
            raise RuntimeError(f"Drive upload session expired: HTTP {probe.status_code}")
        with open(file_path, "rb") as source_file:
            while confirmed_offset < total_size:
                source_file.seek(confirmed_offset)
                chunk = source_file.read(_DRIVE_UPLOAD_CHUNK_SIZE)
                chunk_end = confirmed_offset + len(chunk) - 1
                chunk_headers = {
                    "Authorization": f"Bearer {credentials.token}",
                    "Content-Length": str(len(chunk)),
                    "Content-Range": f"bytes {confirmed_offset}-{chunk_end}/{total_size}",
                }
                response = None
                for retry in range(1, max_retries + 1):
                    try:
                        response = requests.put(
                            session_url,
                            headers=chunk_headers,
                            data=chunk,
                            timeout=(30, _DRIVE_HTTP_TIMEOUT_SECONDS),
                            allow_redirects=False,
                        )
                        if response.status_code in (200, 201):
                            existing_files[file_name] = response.json()["id"]
                            sessions.pop(session_key, None)
                            with open(_UPLOAD_SESSION_STATE_PATH, "w", encoding="utf-8") as state_file:
                                json.dump(sessions, state_file)
                            print(f"✅ تم رفع الملف: {file_name} - ID: {response.json()['id']}")
                            return response.json()["id"]
                        if response.status_code == 308:
                            range_header = response.headers.get("Range", "")
                            match = re.search(r"\d+-(\d+)", range_header)
                            confirmed_offset = int(match.group(1)) + 1 if match else chunk_end + 1
                            percentage = int(confirmed_offset * 100 / total_size)
                            print(f"[DRIVE] Upload progress: {percentage}% | {file_name}")
                            if progress_callback:
                                progress_callback(percentage)
                            break
                        raise RuntimeError(f"Drive chunk upload failed: HTTP {response.status_code}")
                    except (requests.RequestException, OSError) as error:
                        # The server may have accepted the chunk before the
                        # response was lost. Ask Drive for the confirmed offset.
                        try:
                            probe = requests.put(
                                session_url,
                                headers={
                                    "Authorization": f"Bearer {credentials.token}",
                                    "Content-Length": "0",
                                    "Content-Range": f"bytes */{total_size}",
                                },
                                data=b"",
                                timeout=(30, _DRIVE_HTTP_TIMEOUT_SECONDS),
                                allow_redirects=False,
                            )
                            if probe.status_code == 308:
                                range_header = probe.headers.get("Range", "")
                                match = re.search(r"\d+-(\d+)", range_header)
                                if match:
                                    confirmed_offset = int(match.group(1)) + 1
                                    print(
                                        f"[DRIVE] Resumed at {int(confirmed_offset * 100 / total_size)}% | {file_name}"
                                    )
                                    break
                        except requests.RequestException:
                            pass
                        if retry == max_retries:
                            raise RuntimeError(
                                f"Upload chunk failed after {max_retries} attempts at "
                                f"{int(confirmed_offset * 100 / total_size)}%: {error}"
                            ) from error
                        time.sleep(min(2 * retry, 10))
                else:
                    raise RuntimeError("Upload chunk retry loop ended unexpectedly")
        raise RuntimeError("Drive resumable upload ended without a completion response")

    def upload_direct_with_long_timeout():
        """Fallback for networks that reject Google's resumable-session redirect."""
        direct_media = MediaFileUpload(file_path, resumable=False)
        return service.files().create(
            body=file_metadata,
            media_body=direct_media,
            fields="id",
        ).execute(num_retries=2)

    for retry in range(1, max_retries + 1):
        try:
            # Chunked upload prevents one slow large PDF from timing out as a
            # single write operation and lets Google's client retry each chunk.
            media = MediaFileUpload(
                file_path,
                resumable=True,
                chunksize=_DRIVE_UPLOAD_CHUNK_SIZE,
            )
            request = service.files().create(
                body=file_metadata, media_body=media, fields="id"
            )
            response = None
            while response is None:
                status, response = request.next_chunk(num_retries=2)
                if status:
                    print(
                        f"[DRIVE] Upload progress: {int(status.progress() * 100)}% | {file_name}"
                    )
            existing_files[file_name] = response["id"]
            print(f'✅ تم رفع الملف: {file_name} - ID: {response.get("id")}')
            print(f"⏱️ زمن رفع الملف: {time.perf_counter() - started_at:.2f} ث | {file_name}")
            return response["id"]
        except (HttpError, OSError, socket.error, socket.timeout) as e:
            print(f"⚠️ مشكلة في الاتصال: {e} - المحاولة رقم {retry}")
            if retry < max_retries:
                time.sleep(min(2 * retry, 8))
        except Exception as e:
            if "missing a Location" in str(e):
                print(
                    f"[DRIVE] Resumable redirect was rejected; using direct upload fallback | {file_name}"
                )
                try:
                    response = upload_direct_with_long_timeout()
                    existing_files[file_name] = response["id"]
                    print(f'✅ تم رفع الملف بالمسار الاحتياطي: {file_name} - ID: {response.get("id")}')
                    print(f"⏱️ زمن رفع الملف: {time.perf_counter() - started_at:.2f} ث | {file_name}")
                    return response["id"]
                except (HttpError, OSError, socket.error, socket.timeout) as fallback_error:
                    print(
                        f"⚠️ فشل مسار الرفع الاحتياطي: {fallback_error} - المحاولة رقم {retry}"
                    )
                    if retry < max_retries:
                        time.sleep(min(3 * retry, 12))
                    continue
            print(f"❌ خطأ غير متوقع: {e} - المحاولة رقم {retry}")
            if retry < max_retries:
                time.sleep(min(3 * retry, 10))
    raise RuntimeError(f"فشل رفع الملف بعد {max_retries} محاولات: {file_name}")


def is_link_locked(share_value):
    """نعم تعني قفل الرابط؛ لا أو الفارغ أو أي قيمة أخرى تعني رابطًا مفتوحًا."""
    return str(share_value).strip() == "نعم"


def make_folder_public(service, folder_id):
    """ جعل المجلد متاحًا للجميع """
    permissions = service.permissions().list(fileId=folder_id, fields="permissions(id,type,role)").execute()
    if any(item.get("type") == "anyone" and item.get("role") == "reader" for item in permissions.get("permissions", [])):
        return
    permission = {
        'type': 'anyone',
        'role': 'reader'
    }
    service.permissions().create(fileId=folder_id, body=permission).execute()
    print('🌍 تم جعل المجلد متاحًا للجميع.')


def make_folder_private(service, folder_id):
    """يلغي المشاركة العامة القديمة عندما تكون قيمة الشيت «نعم» (رابط مقفول)."""
    permissions = service.permissions().list(fileId=folder_id, fields="permissions(id,type)").execute()
    for permission in permissions.get("permissions", []):
        if permission.get("type") == "anyone":
            service.permissions().delete(fileId=folder_id, permissionId=permission["id"]).execute()
    print("🔒 تم قفل الرابط عن المشاركة العامة.")


def get_shareable_link(service, folder_id):
    """ الحصول على رابط المشاركة للمجلد """
    folder = service.files().get(fileId=folder_id, fields='webViewLink').execute()
    shareable_link = folder.get('webViewLink')
    print(f'🔗 رابط المجلد: {shareable_link}')
    return shareable_link


def upload_local_tree_and_verify(service, local_client_folder, client_folder_id, progress_callback=None):
    """يرفع الشجرة ثم يتأكد من Drive أن كل ملف محلي موجود قبل إرسال الرابط."""
    if not os.path.isdir(local_client_folder):
        raise FileNotFoundError(f"فولدر الطلب غير موجود: {local_client_folder}")

    folder_map = {}
    expected_files = {}
    for root, _, files in os.walk(local_client_folder):
        relative_path = os.path.relpath(root, local_client_folder).replace("\\", "/")
        if relative_path == ".":
            drive_folder_id = client_folder_id
        else:
            drive_folder_id = folder_map.get(relative_path)
            if drive_folder_id is None:
                drive_folder_id = create_folder(service, relative_path, client_folder_id)
                folder_map[relative_path] = drive_folder_id

        existing_files = list_folder_file_ids(service, drive_folder_id)
        expected_files.setdefault(drive_folder_id, set()).update(files)
        for file_name in files:
            upload_file(service, os.path.join(root, file_name), drive_folder_id, existing_files, progress_callback=progress_callback)

    # Drive قد يحتاج لحظة قصيرة لإظهار ملف تم رفعه للتو في نتائج البحث.
    for verification_try in range(1, 4):
        missing = []
        for folder_id, names in expected_files.items():
            remote_names = set(list_folder_file_ids(service, folder_id))
            missing.extend(sorted(names - remote_names))
        if not missing:
            print(f"✅ تم التحقق من اكتمال الرفع على Drive: {sum(map(len, expected_files.values()))} ملف.")
            return
        if verification_try < 3:
            time.sleep(1)

    raise RuntimeError(f"لم تظهر كل الملفات على Drive بعد الرفع: {', '.join(missing)}")


from concurrent.futures import ThreadPoolExecutor


def upload_order_files(client_code, client_folder_name, business_root_folder, work_folder_name, share_value, progress_callback=None):
    service = authenticate_google_drive()
    with _shared_folder_lock:
        clients_folder_id = create_folder(service, config.DRIVE_FOLDER_GENERAL_PRODUCTS)
    client_folder_id = create_folder(service, client_folder_name, clients_folder_id)

    local_client_folder = os.path.join(
        business_root_folder,
        work_folder_name,
        settings.get_orders_subdir(),
        client_folder_name
    )

    upload_completed = False
    try:
        upload_local_tree_and_verify(service, local_client_folder, client_folder_id, progress_callback)
        upload_completed = True

    except Exception as e:
        print(f"❌ حصل استثناء أثناء رفع الطلبات للعميل {client_code}: {e}")
    finally:
        try:
            if not upload_completed:
                print(f"🚫 لن يتم إرسال رابط العميل {client_code} لأن التحقق من الرفع لم يكتمل.")
                return None
            if is_link_locked(share_value):
                make_folder_private(service, client_folder_id)
            else:
                make_folder_public(service, client_folder_id)

            return get_shareable_link(service, client_folder_id)

        except Exception as e:
            print(f"⚠️ فشل في ضبط إعدادات المشاركة أو جلب الرابط: {e}")
            return None

# ⚠️ DEPRECATED — شغل 2024 اتوقف، الدالة دي مش بتتنده من الواجهة تاني
def upload_order_files_24(client_code, client_folder_name, business_root_folder, share_value):
    service = authenticate_google_drive()
    clients_folder_id = create_folder(service, config.DRIVE_FOLDER_OLD_WORK)
    client_folder_id = create_folder(service, client_folder_name, clients_folder_id)

    local_client_folder = os.path.join(
        business_root_folder,
        config.ORDERS_SUBPATH_2024,
        client_folder_name
    )

    try:
        if os.path.exists(local_client_folder):
            folder_map = {}

            for root, _, files in os.walk(local_client_folder):
                relative_path = os.path.relpath(root, local_client_folder).replace("\\", "/")

                if relative_path == ".":
                    drive_folder_id = client_folder_id
                else:
                    if relative_path in folder_map:
                        drive_folder_id = folder_map[relative_path]
                    else:
                        drive_folder_id = create_folder(service, relative_path, client_folder_id)
                        folder_map[relative_path] = drive_folder_id

                # ✅ رفع الملفات واحد واحد
                for file_name in files:
                    file_path = os.path.join(root, file_name)
                    try:
                        upload_file(service, file_path, drive_folder_id)
                        print(f"✅ تم رفع {file_path}")
                    except Exception as e:
                        print(f"⚠️ خطأ أثناء رفع {file_path}: {e}")

    except Exception as e:
        print(f"❌ حصل استثناء أثناء رفع الطلبات للعميل {client_code}: {e}")

    finally:
        try:
            if share_value == "نعم":  # ✅ الشرط من العمود
                make_folder_public(service, client_folder_id)

            return get_shareable_link(service, client_folder_id)

        except Exception as e:
            print(f"⚠️ فشل في ضبط إعدادات المشاركة أو جلب الرابط: {e}")
            return None

def upload_order_files_logo(client_code, client_folder_name, business_root_folder, work_folder_name, share_value, progress_callback=None):
    service = authenticate_google_drive()
    with _shared_folder_lock:
        clients_folder_id = create_folder(service, config.DRIVE_FOLDER_GENERAL_PRODUCTS)
    # طلبات اللوجو تتبع نفس هيكل رفع الطلبات العادية على Drive.
    client_folder_id = create_folder(service, client_folder_name, clients_folder_id)

    local_client_folder = os.path.join(
        business_root_folder,
        work_folder_name,
        settings.get_logo_orders_subdir(),
        client_folder_name
    )

    upload_completed = False
    try:
        upload_local_tree_and_verify(service, local_client_folder, client_folder_id, progress_callback)
        upload_completed = True

    except Exception as e:
        print(f"❌ حصل استثناء أثناء رفع الطلبات للعميل {client_code}: {e}")

    finally:
        try:
            if not upload_completed:
                print(f"🚫 لن يتم إرسال رابط طلب اللوجو للعميل {client_code} لأن التحقق من الرفع لم يكتمل.")
                return None
            if is_link_locked(share_value):
                make_folder_private(service, client_folder_id)
            else:
                make_folder_public(service, client_folder_id)

            return get_shareable_link(service, client_folder_id)

        except Exception as e:
            print(f"⚠️ فشل في ضبط إعدادات المشاركة أو جلب الرابط: {e}")
            return None

# ⚠️ DEPRECATED — شغل 2024 اتوقف، الدالة دي مش بتتنده من الواجهة تاني
def upload_order_files_logo_24(client_code, client_folder_name, business_root_folder, share_value):
    service = authenticate_google_drive()
    clients_folder_id = create_folder(service, config.DRIVE_FOLDER_OLD_WORK)
    client_folder_id = create_folder(service, client_folder_name, clients_folder_id)

    local_client_folder = os.path.join(
        business_root_folder,
        config.LOGO_ORDERS_SUBPATH_2024,
        client_folder_name
    )

    try:
        if os.path.exists(local_client_folder):
            folder_map = {}

            for root, _, files in os.walk(local_client_folder):
                relative_path = os.path.relpath(root, local_client_folder).replace("\\", "/")

                if relative_path == ".":
                    drive_folder_id = client_folder_id
                else:
                    if relative_path in folder_map:
                        drive_folder_id = folder_map[relative_path]
                    else:
                        drive_folder_id = create_folder(service, relative_path, client_folder_id)
                        folder_map[relative_path] = drive_folder_id

                # ✅ رفع الملفات بالتسلسل
                for file_name in files:
                    file_path = os.path.join(root, file_name)
                    try:
                        upload_file(service, file_path, drive_folder_id)
                        print(f"✅ تم رفع {file_path}")
                    except Exception as e:
                        print(f"⚠️ خطأ أثناء رفع {file_path}: {e}")

    except Exception as e:
        print(f"❌ حصل استثناء أثناء رفع الطلبات للعميل {client_code}: {e}")

    finally:
        try:
            if share_value == "نعم":  # ✅ الشرط من العمود
                make_folder_public(service, client_folder_id)

            return get_shareable_link(service, client_folder_id)

        except Exception as e:
            print(f"⚠️ فشل في ضبط إعدادات المشاركة أو جلب الرابط: {e}")
            return None


def open_link(event):
    webbrowser.open(event.widget.cget("text"))

# 🔹 دالة معالجة الطلبات
def get_folder_id(service, folder_name, parent_folder_id=None):
    """ البحث عن فولدر بالاسم داخل Google Drive وإرجاع ID إذا كان موجودًا """
    query = f"name='{folder_name}' and mimeType='application/vnd.google-apps.folder'"
    if parent_folder_id:
        query += f" and '{parent_folder_id}' in parents"

    results = service.files().list(q=query, spaces="drive", fields="files(id)").execute()
    folders = results.get("files", [])

    return folders[0]['id'] if folders else None


