"""Small, shared display rules used by every WhatsApp workflow."""

import re


_TITLE = re.compile(r"^(?:أ|د|م)\.$")


def short_teacher_name(value):
    """Return one first name, keeping an existing Arabic professional title."""
    parts = str(value or "").strip().split()
    if not parts:
        return "أ."

    if _TITLE.fullmatch(parts[0]):
        title = parts.pop(0)
    else:
        title = "أ."
    return title if not parts else f"{title} {parts[0]}"
