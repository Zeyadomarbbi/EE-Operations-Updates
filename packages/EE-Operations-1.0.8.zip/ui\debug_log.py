"""
تقاط مخرجات الطرفية (كل print() في البرنامج) في بفر مشترك تقدر الواجهة تعرضه
حيّ في تاب "السجل التقني" المحمي بكلمة سر، من غير ما نلغي التوجيه الأصلي
(app_log.txt وقت التشغيل عن طريق run_app.bat).
"""
import sys
import threading

_lock = threading.Lock()
_buffer = []
_MAX_CHARS = 400_000  # سقف تقريبي عشان الذاكرة متكبرش من غير حدود لو البرنامج فضل شغال ساعات


class _TeeStream:
    def __init__(self, original):
        self._original = original

    def write(self, text):
        try:
            self._original.write(text)
        except Exception:
            pass
        if text:
            with _lock:
                _buffer.append(text)
                total = sum(len(s) for s in _buffer)
                while total > _MAX_CHARS and len(_buffer) > 1:
                    total -= len(_buffer.pop(0))
        return len(text)

    def flush(self):
        try:
            self._original.flush()
        except Exception:
            pass

    def isatty(self):
        return False


def install():
    """تتنده مرة واحدة بس، أول ما البرنامج يشتغل (بعد ضبط UTF-8)."""
    sys.stdout = _TeeStream(sys.stdout)
    sys.stderr = _TeeStream(sys.stderr)


def get_full_text():
    with _lock:
        return "".join(_buffer)


def clear():
    with _lock:
        _buffer.clear()
