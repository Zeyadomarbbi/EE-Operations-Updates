"""Central Command Center design tokens and Qt stylesheet."""

COLORS = {
    "bg": "#F4F6F5", "surface": "#FFFFFF", "surface_alt": "#EEF2F1",
    "sidebar": "#10252D", "sidebar_alt": "#18343D", "primary": "#126B72",
    "primary_hover": "#0F5A60", "text": "#172328", "muted": "#607077",
    "border": "#DCE3E1", "success": "#2D8060", "warning": "#B5792A",
    "danger": "#C4524C", "info": "#287BA0",
}


def stylesheet(theme="light"):
    c = COLORS.copy()
    if theme == "dark":
        c.update({"bg": "#162126", "surface": "#203036", "surface_alt": "#293B42", "text": "#E6EFEE", "muted": "#AEC0C1", "border": "#3A5054", "sidebar": "#0D1A1F", "sidebar_alt": "#173139"})
    return f"""
    * {{ font-family: 'Segoe UI Variable', 'Segoe UI'; color: {c['text']}; }}
    QMainWindow, QWidget#workspace {{ background: {c['bg']}; }}
    QFrame#sidebar {{ background: {c['sidebar']}; }}
    QFrame#sidebar QLabel {{ color: #DDE8EA; }}
    QPushButton#nav {{ text-align: right; padding: 10px 12px; border: 0; border-radius: 7px; color: #C9D7DA; background: transparent; font-size: 13px; }}
    QPushButton#nav:hover {{ background: {c['sidebar_alt']}; color: white; }}
    QPushButton#nav[active='true'] {{ background: #1D4650; color: white; border-right: 3px solid #55B8B7; font-weight: 600; }}
    QFrame#card {{ background: {c['surface']}; border: 1px solid {c['border']}; border-radius: 10px; }}
    QFrame#hero {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0F5960, stop:1 #17313B); border: 0; border-radius: 16px; }}
    QLabel#heroTitle {{ color: white; font-size: 30px; font-weight: 700; }}
    QLabel#heroText {{ color: #D7ECEC; font-size: 14px; }}
    QLabel#brand {{ color: white; font-size: 22px; font-weight: 700; }}
    QFrame#topbar {{ background: {c['surface']}; border-bottom: 1px solid {c['border']}; }}
    QLabel#pageTitle {{ font-size: 24px; font-weight: 600; }}
    QLabel#pageSubtitle, QLabel#muted {{ color: {c['muted']}; font-size: 12px; }}
    QLabel#sectionTitle {{ font-size: 16px; font-weight: 600; }}
    QLabel#technical {{ font-family: Consolas; color: {c['muted']}; font-size: 11px; }}
    QPushButton {{ min-height: 38px; padding: 0 14px; border-radius: 7px; border: 1px solid {c['border']}; background: {c['surface']}; font-size: 13px; }}
    QPushButton:hover {{ border-color: #9FB4B4; background: #F8FAF9; }}
    QPushButton:disabled {{ color: #98A4A7; background: #EDF0EF; border-color: #E3E8E6; }}
    QPushButton#primary {{ color: white; background: {c['primary']}; border-color: {c['primary']}; min-height: 44px; font-weight: 600; }}
    QPushButton#primary:hover {{ background: {c['primary_hover']}; }}
    QPushButton#warning {{ color: {c['warning']}; border-color: #E4C990; background: #FFF9ED; }}
    QPushButton#success {{ color: {c['success']}; border-color: #A9D6C0; background: #F2FAF5; }}
    QLineEdit, QTextEdit, QComboBox {{ background: {c['surface']}; border: 1px solid {c['border']}; border-radius: 7px; padding: 8px 10px; selection-background-color: #BFE1E0; }}
    QLineEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 2px solid #17828B; }}
    QProgressBar {{ border: 0; border-radius: 5px; background: #E7ECEA; height: 9px; text-align: center; }}
    QProgressBar::chunk {{ background: {c['primary']}; border-radius: 5px; }}
    QTableWidget {{ background: white; border: 1px solid {c['border']}; border-radius: 8px; gridline-color: #EDF1F0; selection-background-color: #E5F2F2; selection-color: {c['text']}; }}
    QHeaderView::section {{ background: {c['surface_alt']}; border: 0; border-bottom: 1px solid {c['border']}; padding: 9px; color: {c['muted']}; font-weight: 600; }}
    QScrollBar:vertical {{ width: 10px; background: transparent; }}
    QScrollBar::handle:vertical {{ background: #C9D2D0; border-radius: 5px; min-height: 28px; }}
    """
