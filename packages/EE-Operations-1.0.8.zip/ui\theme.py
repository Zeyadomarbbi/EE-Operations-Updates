"""
Design tokens مركزية للواجهة كلها (مسافات، خطوط، ألوان الحالة، أسماء الثيمات).
أي حاجة بصرية متكررة (Card, Sidebar, أزرار...) لازم تسحب قيمها من هنا بدل
ما تكرر أرقام/ألوان خام جوه كل ملف.
"""

# مقاسات المسافات (بالبكسل) — نفس الـ scale المتدرج المستخدم في أنظمة تصميم حديثة
SPACE_XS = 4
SPACE_SM = 8
SPACE_MD = 12
SPACE_BASE = 16
SPACE_LG = 20
SPACE_XL = 24
SPACE_2XL = 32
SPACE_3XL = 40

# الخط: Segoe UI متوفر افتراضيًا على ويندوز وبيدعم العربي كويس
FONT_FAMILY = "Segoe UI"

FONT_TITLE = (FONT_FAMILY, 20, "bold")
FONT_SECTION = (FONT_FAMILY, 13, "bold")
FONT_BODY = (FONT_FAMILY, 11)
FONT_BODY_BOLD = (FONT_FAMILY, 11, "bold")
FONT_SMALL = (FONT_FAMILY, 9)
FONT_MONO = ("Consolas", 10)

SIDEBAR_WIDTH = 216

# CommandFlow semantic palette. Keep these names stable so pages never need
# to scatter raw color values through their layout code.
COLOR_BG = "#F6F7F4"
COLOR_SURFACE = "#FFFFFF"
COLOR_SURFACE_ALT = "#F0F3F1"
COLOR_SIDEBAR = "#102A36"
COLOR_PRIMARY = "#146C75"
COLOR_PRIMARY_HOVER = "#105B63"
COLOR_TEXT = "#182329"
COLOR_TEXT_MUTED = "#65747A"
COLOR_BORDER = "#DDE4E2"
COLOR_SUCCESS = "#25835D"
COLOR_INFO = "#247BA0"
COLOR_WARNING = "#B7791F"
COLOR_DANGER = "#C5534E"

# اسم ثيم ttkbootstrap لكل وضع مظهر — الداكن هو اللي كان مستخدم من الأول
THEME_NAMES = {
    "dark": "superhero",
    "light": "bootstrap-light",
}

# ألوان الحالة (نفس المفهوم في كل الثيمات: نجاح/تحذير/خطأ/معلومة) — بنسحب
# القيمة الفعلية من bootstyle الجاهز في ttkbootstrap عشان تفضل متسقة مع الثيم الحالي
STATUS_BOOTSTYLE = {
    "ready": "secondary",
    "processing": "info",
    "completed": "success",
    "failed": "danger",
    "warning": "warning",
}

STATUS_LABEL_AR = {
    "ready": "جاهز",
    "processing": "جاري التنفيذ",
    "completed": "تم",
    "failed": "فشل",
    "warning": "تنبيه",
}


def apply_card_style(style):
    """ستايل الـ Card مسجّل باسم ثابت (Card.TFrame) عشان أي Card اتبنت قبل كده
    تتلوّن تلقائيًا لوحدها لما نبدّل الثيم، من غير ما نحتاج نمرّ عليها واحدة واحدة."""
    style.configure(
        "Card.TFrame",
        background=COLOR_SURFACE,
        bordercolor=COLOR_BORDER,
        relief="solid",
        borderwidth=1,
    )
    style.configure("CardBody.TFrame", background=COLOR_SURFACE)
    style.configure("App.TFrame", background=COLOR_BG)
    style.configure("Context.TFrame", background=COLOR_SURFACE_ALT)
    style.configure("Sidebar.TFrame", background=COLOR_SIDEBAR)


def apply_base_style(style):
    """تطبيق الخط الموحّد على كل عناصر ttk، بيتنده مرة عند بداية التطبيق وبعد أي تبديل ثيم."""
    style.configure(".", font=FONT_BODY)
    style.configure("TButton", font=FONT_BODY)
    style.configure("TLabel", font=FONT_BODY)
    style.configure("TEntry", font=FONT_BODY)
    style.configure("TCombobox", font=FONT_BODY)
    style.configure("Treeview", font=FONT_BODY, rowheight=28)
    style.configure("Treeview.Heading", font=FONT_BODY_BOLD)

    style.configure("PageTitle.TLabel", font=FONT_TITLE, foreground=COLOR_TEXT, background=COLOR_BG)
    style.configure("PageSubtitle.TLabel", font=FONT_BODY, foreground=COLOR_TEXT_MUTED, background=COLOR_BG)
    style.configure("SectionTitle.TLabel", font=FONT_SECTION)
    style.configure("Small.TLabel", font=FONT_SMALL, foreground=COLOR_TEXT_MUTED)
    style.configure("Mono.TLabel", font=FONT_MONO)
    style.configure("EmptyStateIcon.TLabel", font=(FONT_FAMILY, 30), foreground=COLOR_PRIMARY)
    style.configure("ContextTitle.TLabel", font=FONT_BODY_BOLD, foreground=COLOR_TEXT, background=COLOR_SURFACE_ALT)
    style.configure("ContextPath.TLabel", font=FONT_MONO, foreground=COLOR_PRIMARY, background=COLOR_SURFACE_ALT)
    style.configure("StatusHeading.TLabel", font=FONT_BODY_BOLD, foreground=COLOR_TEXT)
    style.configure("Treeview", rowheight=34, fieldbackground=COLOR_SURFACE, background=COLOR_SURFACE)
    style.configure("Treeview.Heading", background=COLOR_SURFACE_ALT, foreground=COLOR_TEXT, relief="flat")

    apply_card_style(style)


def set_app_theme(root, style, theme_key):
    """تبديل الثيم بالكامل (فاتح/غامق) في وقت التشغيل، وإعادة تطبيق الخطوط والـ Card بعدها."""
    theme_name = THEME_NAMES.get(theme_key, THEME_NAMES["dark"])
    style.theme_use(theme_name)
    apply_base_style(style)
    return theme_name
