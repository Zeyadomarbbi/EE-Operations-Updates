import glob
from tkinter import filedialog, ttk
import tkinter.messagebox as msgbox
from PyPDF2 import PdfReader, PdfWriter
import fitz
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from PIL import Image
import cv2
import numpy as np
import sys
import win32com.client
import pythoncom
from reportlab.lib.pagesizes import A4
import win32com.client
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures
import pandas as pd
import concurrent.futures
import threading
import time
import tempfile
import shutil
import tkinter as tk
from tkinter import messagebox, filedialog
import win32com.client
import os
import tkinter.messagebox as msgbox
import pandas as pd
import random
import urllib.parse
import urllib.parse
import time
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from tkinter import filedialog, messagebox
import uuid
from datetime import datetime

from drive import upload_order_files, open_link, upload_order_files_24, upload_order_files_logo, upload_order_files_logo_24
import web_driver
from web_driver import initialize_driver
from web_driver import wait_for_whatsapp_login
import config
import settings
import run_history
from name_format import short_teacher_name


# upload files
# ⬅️ حالة منفصلة لكل تاب (عادي/لوجو) عشان يتشغلوا مع بعض من غير ما يتعارضوا
selected_folder = ""        # مجلد قوالب تاب "الطلبات"
excel_file = None           # ملف إكسل تاب "الطلبات"
selected_folder_logo = ""   # مجلد قوالب تاب "الشعار"
excel_file_logo = None      # ملف إكسل تاب "الشعار"

# أتمتة Word (COM) مش مصممة أصلاً تستحمل عدد كبير من النسخ الشغالة في نفس اللحظة
# (حتى على أجهزة نضيفة، مش بس عندك). قفلناها على 1 مؤقتًا وقت ما كنا بندوّر على
# سبب "Command failed" المستمر، ولقينا إن السبب الأرجح كان برنامج حماية على
# مستوى المؤسسة (Defender for Endpoint) مش التزامن نفسه. فبنرجعها لـ 4 - رقم
# معقول بيسرّع الشغل كتير عن نسخة واحدة، من غير ما نضغط على Word بعدد كبير أوي
# (زي الـ 10 الأصليين) لأن ده كان بيسبب فشل متكرر حتى قبل مشكلة الحماية أصلاً.
# لو المشكلة رجعت تظهر، إنزل بيها لـ 2 أو 1 تاني.
# الاستقرار هنا أهم من السرعة: ملفات Word الكبيرة أو اللي فيها Shapes كتير كانت
# بتقع في "Command failed" بشكل متكرر مع التوازي. نخلي نسخة Word واحدة فقط شغالة
# في نفس اللحظة لحد ما دورة التحويل تستقر بالكامل.
_word_concurrency_limit = threading.Semaphore(10)
_client_parallelism = 10
_order_parallelism = 10


# ==========================================================================
# تنسيق الإغلاق التلقائي بين تاب "الطلبات" و"الشعار": لو الاتنين شغالين مع
# بعض واختار حد منهم أوبشن "إغلاق الجهاز تلقائيًا"، الجهاز ميتقفلش غير لما
# الشغلانتين (مش بس اللي طلب الإغلاق) يخلصوا خالص.
# ==========================================================================
_shutdown_coord_lock = threading.Lock()
_active_jobs_count = 0
_shutdown_requested = False
_failed_orders_lock = threading.Lock()
_failed_orders_by_mode = {"normal": pd.DataFrame(), "logo": pd.DataFrame()}
_pause_lock = threading.Lock()
_pause_requested = {"normal": False, "logo": False, "retry": False}


def request_pause(mode):
    with _pause_lock:
        _pause_requested[mode] = True
    print(f"[RUN] Pause requested for {mode}; waiting for the next safe point.")


def resume_run(mode):
    with _pause_lock:
        _pause_requested[mode] = False
    print(f"[RUN] Resume requested for {mode}.")


def wait_if_paused(mode, run_id=None):
    """Never interrupt Word or an active upload; wait before the next unit of work."""
    was_paused = False
    while True:
        with _pause_lock:
            paused = _pause_requested.get(mode, False)
        if not paused:
            if was_paused and run_id:
                run_history.update(run_id, status="running", stage="Resumed")
            return
        if run_id:
            run_history.update(run_id, status="paused", stage="Paused at a safe point")
        was_paused = True
        time.sleep(0.35)


def ui_after(widget, callback):
    try:
        widget.after(0, callback)
    except Exception:
        pass


def ui_destroy(widget):
    ui_after(widget, lambda: widget.winfo_exists() and widget.destroy())


def ui_showinfo(widget, title, message):
    ui_after(widget, lambda: messagebox.showinfo(title, message))


def ui_showerror(widget, title, message):
    ui_after(widget, lambda: messagebox.showerror(title, message))


def clear_failed_orders(mode):
    with _failed_orders_lock:
        _failed_orders_by_mode[mode] = pd.DataFrame()


def save_failed_orders(mode, failed_rows):
    with _failed_orders_lock:
        _failed_orders_by_mode[mode] = (
            pd.concat(failed_rows, ignore_index=True) if failed_rows else pd.DataFrame()
        )
        return len(_failed_orders_by_mode[mode])


def has_failed_orders(mode):
    """Return whether the current run produced rows eligible for failure export."""
    with _failed_orders_lock:
        return not _failed_orders_by_mode.get(mode, pd.DataFrame()).empty


def export_failed_orders(mode):
    """ينشئ على الديسكتوب شيتًا جديدًا بالصفوف التي لم تكتمل فقط."""
    with _failed_orders_lock:
        failed_orders = _failed_orders_by_mode.get(mode, pd.DataFrame()).copy()
    if failed_orders.empty:
        return None

    desktop = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")), "Desktop")
    os.makedirs(desktop, exist_ok=True)
    label = "طلبات_اللوجو_غير_المكتملة" if mode == "logo" else "طلبات_غير_المكتملة"
    file_path = os.path.join(desktop, f"{label}_{datetime.now():%Y-%m-%d_%H-%M-%S}.xlsx")
    failed_orders.to_excel(file_path, index=False)
    print(f"📋 تم حفظ شيت الطلبات غير المكتملة: {file_path}")
    return file_path


def ui_render_links_summary(container, all_links, sent_messages_count, failed_numbers):
    def render():
        if not container.winfo_exists():
            return
        for widget in container.winfo_children():
            widget.destroy()

        summary_text = f"📢 **ملخص الإرسال** 📢\n✅ تم إرسال {sent_messages_count} رسالة بنجاح.\n"
        if failed_numbers:
            summary_text += f"❌ لم يتم إرسال الرسائل إلى {len(failed_numbers)} رقم:\n"
            summary_text += "\n".join([f"   - {num}" for num in failed_numbers])
        else:
            summary_text += "🎉 تم إرسال جميع الرسائل بنجاح! 🚀"

        summary_label = tk.Label(
            container,
            text=summary_text,
            font=("Arial", 11),
            justify="left",
            fg="black"
        )
        summary_label.pack(anchor="w", padx=5, pady=10)

        for link in all_links:
            link_label = tk.Label(
                container, text=link, fg="blue", cursor="hand2", font=("Arial", 10, "underline")
            )
            link_label.pack(anchor="w", padx=5, pady=2)
            link_label.bind("<Button-1>", open_link)

    ui_after(container, render)


def _job_started(shutdown_after):
    global _active_jobs_count, _shutdown_requested
    with _shutdown_coord_lock:
        _active_jobs_count += 1
        if shutdown_after:
            _shutdown_requested = True


def _job_finished():
    global _active_jobs_count, _shutdown_requested
    with _shutdown_coord_lock:
        _active_jobs_count = max(0, _active_jobs_count - 1)
        if _active_jobs_count == 0 and _shutdown_requested:
            _shutdown_requested = False
            # A requested shutdown must never hide the only copy of failed rows.
            for mode in ("normal", "logo"):
                try:
                    export_failed_orders(mode)
                except Exception as exc:
                    print(f"[RUN] Could not export failed {mode} rows before shutdown: {exc}")
            print("🔌 كل الشغلانات خلصت وتم طلب إغلاق الجهاز — جاري الإغلاق...")
            os.system("shutdown /s /t 0")

def upload_excel(mode="normal"):
    global excel_file, excel_file_logo  # ⬅️ جعل المتغير جلوبال حتى يكون متاحًا في جميع الدوال
    file_path = filedialog.askopenfilename(title="اختر ملف الإكسل", filetypes=[("Excel files", "*.xlsx;*.xls")])

    if file_path:
        # 🔍 التأكد أن الملف فعلاً من نوع Excel
        if not file_path.endswith((".xlsx", ".xls")):
            messagebox.showerror("خطأ", "⚠️ الملف الذي تم رفعه ليس ملف Excel! الرجاء اختيار ملف بامتداد .xlsx أو .xls")
            return  # ⬅️ الخروج من الدالة وعدم تخزين الملف

        if mode == "logo":
            excel_file_logo = file_path
        else:
            excel_file = file_path
        print(f"📁 تم تحميل الملف بنجاح: {file_path}")

def get_excel_file(mode="normal"):
    return excel_file_logo if mode == "logo" else excel_file

def get_selected_folder(mode="normal"):
    return selected_folder_logo if mode == "logo" else selected_folder

def upload_folder(mode="normal"):
    global selected_folder, selected_folder_logo
    folder_path = filedialog.askdirectory(title="اختر مجلد الملفات الأصلية")

    if folder_path:
        # البحث في المجلد وجميع المجلدات الفرعية عن ملفات وورد
        word_files = []
        for root, dirs, files in os.walk(folder_path):
            word_files.extend([f for f in files if f.endswith(('.docx', '.doc'))])

        if not word_files:  # إذا لم يتم العثور على أي ملفات وورد
            messagebox.showerror("خطأ", "⚠️ المجلد لا يحتوي على أي ملفات وورد ")
            return  # إيقاف التنفيذ

        if mode == "logo":
            selected_folder_logo = folder_path
        else:
            selected_folder = folder_path

# funcs for edit
def format_code(code):
    try:
        return str(int(float(code)))
    except ValueError:
        return str(code)


def format_duration(seconds):
    return f"{seconds:.2f} ث"


def log_timing(stage_name, started_at, extra_info=""):
    elapsed = time.perf_counter() - started_at
    suffix = f" | {extra_info}" if extra_info else ""
    print(f"⏱️ {stage_name}: {format_duration(elapsed)}{suffix}")


def file_exists_with_size(file_path):
    try:
        return os.path.exists(file_path) and os.path.getsize(file_path) > 0
    except OSError:
        return False

# pass
def add_password_to_pdf(pdf_path, password):
    try:
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        writer.encrypt(password)

        protected_pdf_path = pdf_path.replace(".pdf", "_protected.pdf")
        with open(protected_pdf_path, "wb") as f:
            writer.write(f)
        os.replace(protected_pdf_path, pdf_path)
        print(f"تمت إضافة كلمة المرور إلى الملف: {pdf_path}")
    except Exception as e:
        print(f"خطأ أثناء حماية ملف PDF {pdf_path}: {e}")

def generate_password(client_code, work_folder_name):
    client_code = format_code(client_code)
    padded_client_code = str(client_code).zfill(5)
    year_suffix = settings.get_password_year_suffix(work_folder_name) or ""
    return f"{config.PASSWORD_PREFIX}{padded_client_code}{year_suffix}"

# phone number
def clean_phone_number(phone_number):
    if pd.isna(phone_number):
        return ""
    numbers = str(phone_number).split('-')
    cleaned_numbers = []
    for number in numbers:
        try:
            number = str(int(float(number.strip())))
            if not number.startswith("0"):
                number = "0" + number
            cleaned_numbers.append(number)
        except ValueError:
            print(f"خطأ في رقم الهاتف: {number}")
    return " - ".join(cleaned_numbers)

# imgs
def convert_pdf_to_images(pdf_path, zoom=5):  # ⬅️ رفع دقة الصور
    """تحويل PDF إلى صور بجودة عالية."""
    doc = fitz.open(pdf_path)
    img_paths = []

    for i, page in enumerate(doc):
        matrix = fitz.Matrix(zoom, zoom)  # ⬅️ زيادة الدقة أكثر
        pix = page.get_pixmap(matrix=matrix)

        img_path = pdf_path.replace(".pdf", f"_page_{i + 1}.png")
        pix.save(img_path, "png")  # ⬅️ حفظ كصورة PNG عالية الجودة
        img_paths.append(img_path)

    return img_paths

def images_to_pdf(img_paths, output_pdf):
    """تحويل الصور إلى PDF مع الحفاظ على أبعاد A4 بدون تشوه."""
    c = canvas.Canvas(output_pdf, pagesize=A4)
    width, height = A4  # ⬅️ الحصول على مقاسات A4 الحقيقية

    for img_path in img_paths:
        img = Image.open(img_path)
        img = img.convert("RGB")

        # 🔹 ضبط الصورة بحيث تحافظ على أبعادها الأصلية داخل A4 بدون تشوه
        img.thumbnail((width, height), Image.LANCZOS)

        # حساب الإحداثيات لوضع الصورة في منتصف الصفحة
        x_offset = (width - img.width) / 2
        y_offset = (height - img.height) / 2

        c.drawImage(img_path, x_offset, y_offset, img.width, img.height)
        c.showPage()

    c.save()

def wait_for_saved_pdf(pdf_path, timeout=45):
    """
    Word بيحفظ الـ PDF بكتابة ملف مؤقت (msoXXXX.tmp) وبعدين يعيد تسميته للاسم
    النهائي. مع الملفات الأكبر/الأعقد، ممكن doc.SaveAs()/doc.Close() يرجعوا
    للكود قبل ما إعادة التسمية دي تخلص فعليًا، فبنستنى شوية بدل ما نفترض إن
    الملف موجود فورًا (اكتشفناها: ملف .tmp فاضل معلّق والـ pdf مش موجود).
    """
    pdf_path = os.path.abspath(pdf_path)
    deadline = time.time() + timeout
    while time.time() < deadline:
        if file_exists_with_size(pdf_path):
            return True
        time.sleep(0.2)
    return file_exists_with_size(pdf_path)


def export_word_to_pdf(doc, output_pdf):
    """
    تصدير PDF بطريقة Word الأنسب. ExportAsFixedFormat عادةً أثبت من SaveAs(FileFormat=17)
    مع المستندات المعقدة، ونسيب SaveAs كخطة بديلة لو احتجناها.
    """
    output_pdf = os.path.abspath(output_pdf)
    try:
        doc.ExportAsFixedFormat(output_pdf, 17)
    except Exception:
        doc.SaveAs(output_pdf, FileFormat=17)


def finalize_pdf_output(pdf_path, add_password=False, password=None, protect_as_images=True):
    wait_started_at = time.perf_counter()
    pdf_ready = wait_for_saved_pdf(pdf_path, timeout=20)
    if not pdf_ready:
        if not file_exists_with_size(pdf_path):
            raise FileNotFoundError(f"لم يظهر ملف PDF على القرص: {pdf_path}")
        print(f"⚠️ لم أتمكن من تأكيد ظهور الـ PDF فورًا على القرص، لكن الملف موجود وسأكمل: {pdf_path}")
    log_timing("ظهور ملف PDF", wait_started_at, os.path.basename(pdf_path))

    post_process_started_at = time.perf_counter()
    last_error = None
    for attempt in range(1, 4):
        try:
            if protect_as_images:
                process_pdf_as_images(pdf_path)
            if add_password:
                add_password_to_pdf(pdf_path, password)
            log_timing("المعالجة النهائية للـ PDF", post_process_started_at, os.path.basename(pdf_path))
            return
        except Exception as e:
            last_error = e
            if file_exists_with_size(pdf_path) and attempt == 3:
                print(f"⚠️ فشلت المعالجة النهائية لكن ملف الـ PDF النهائي موجود، سأكمل بدون إعادة محاولة: {pdf_path} | {e}")
                return
            if attempt < 3:
                print(f"⚠️ تعذرت المعالجة النهائية للـ PDF (محاولة {attempt}/3)، سأعيد المحاولة: {e}")
                time.sleep(0.8 * attempt)
    raise last_error

def process_pdf_as_images(pdf_path):
    """تحويل PDF إلى صور ثم إعادة تجميعها في PDF مع تحسين الجودة."""
    if not file_exists_with_size(pdf_path):
        raise FileNotFoundError(f"ملف الـ PDF غير موجود أو حجمه صفر قبل معالجته: {pdf_path}")
    img_paths = convert_pdf_to_images(pdf_path, zoom=3)  # ⬅️ زيادة جودة التحويل
    img_pdf_path = pdf_path.replace(".pdf", "_image.pdf")

    images_to_pdf(img_paths, img_pdf_path)

    # حذف الصور المؤقتة
    for img_path in img_paths:
        os.remove(img_path)

    # استبدال الـ PDF الأصلي بالـ PDF الجديد
    os.replace(img_pdf_path, pdf_path)

business_root_folder = None

# طلبات (شغل السنة الحالية)
def modify_and_protect_templates(client_code, order_codes, file_code, teacher_name, phone_number, water_mark, logo_path, note_name, open_link, business_root_folder, work_folder_name, word, add_password=True, protect_as_images=True, templates_root=None):
    global selected_folder
    templates_root = templates_root or selected_folder
    if not templates_root:
        print("⚠️ لم يتم اختيار مجلد القوالب الأصلية!")
        return

    file_code = format_code(file_code)
    templates_folder = os.path.join(templates_root, file_code)
    print("تم فتح ملف كوده", templates_folder)

    base_path = os.path.join(business_root_folder, work_folder_name, settings.get_orders_subdir())
    client_folder = os.path.join(base_path, "_".join(order_codes))
    file_folder = os.path.join(client_folder, file_code)
    os.makedirs(file_folder, exist_ok=True)

    word_files = glob.glob(os.path.join(templates_folder, "*.docx"))
    if not word_files:
        print(f"⚠️ لا توجد ملفات وورد في المجلد {templates_folder}")
        return

    print(f"📄 تم العثور على {len(word_files)} ملف وورد في المجلد:")
    for file in word_files:
        print(f"  - {os.path.basename(file)}")

    phone_number = clean_phone_number(phone_number)
    password = generate_password(client_code, work_folder_name)

    processed_files = []
    # ثريد الـ ThreadPoolExecutor ده جديد ومفيش فيه تهيئة COM تلقائية، فلازم نعمل
    # CoInitialize هنا وإلا win32com ممكن يرمي "CoInitialize has not been called"
    # أو يتصرف بشكل غير مستقر (اكتشفناها بالاختبار المباشر)
    pythoncom.CoInitialize()
    try:
        threads = []
        # 🔁 أتمتة Word أحيانًا بتفشل بخطأ عابر ("Command failed") لو كذا نسخة Word
        # شغالة في نفس اللحظة. بدل ما نخسر الملف من أول فشل عابر، بنرجّعه لآخر
        # الطابور ونعيد محاولته لحد 3 مرات قبل ما نستسلم فعلًا (شوف نهاية except تحت)
        file_queue = list(word_files)
        file_attempts = {}
        while file_queue:
            specific_file = file_queue.pop(0)
            word = None
            doc = None
            temp_file_path = None
            semaphore_acquired = False
            try:
                template_path = os.path.normpath(specific_file)
                if os.path.basename(template_path).startswith("~$"):
                    continue  # تخطي ملفات Word المؤقتة

                if not os.path.exists(template_path):
                    print(f"⚠️ الملف غير موجود، سيتم تخطيه: {template_path}")
                    continue

                temp_dir = tempfile.gettempdir()
                thread_temp_dir = os.path.join(temp_dir, f"thread_{threading.get_ident()}")
                os.makedirs(thread_temp_dir, exist_ok=True)

                # 🟢 إنشاء نسخة فريدة من الملف لكل ثريد
                # temp_file_path = os.path.join(thread_temp_dir, os.path.basename(template_path))
                # shutil.copy2(template_path, temp_file_path)
                #
                # print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")
                orig_name, ext = os.path.splitext(os.path.basename(template_path))
                unique_suffix = uuid.uuid4().hex  # بيطلع رقم/كود عشوائي وفريد
                temp_file_name = f"{orig_name}__{unique_suffix}{ext}"

                temp_file_path = os.path.join(thread_temp_dir, temp_file_name)
                shutil.copy2(template_path, temp_file_path)

                print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")

                file_name = os.path.basename(template_path).replace(".docx", "")
                #note_name = file_name
                output_pdf = os.path.join(file_folder, f"{order_codes[0]}_{file_code}_{file_name}_{teacher_name}.pdf")

                _word_concurrency_limit.acquire()
                semaphore_acquired = True
                word = win32com.client.DispatchEx("Word.Application")
                word.Visible = False

                print(f"📂 فتح الملف: {temp_file_path}")
                doc = word.Documents.Open(temp_file_path)  # ✅ فتح النسخة المؤقتة بدلاً من الأصل

                teacher_prefix = teacher_name if teacher_name.startswith(("د.", "أ.")) else f"أ. {teacher_name}"

                # تعديل النصوص داخل الأشكال (Shapes)
                for shape in doc.Shapes:
                    if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                        text = shape.TextFrame.TextRange.Text
                        page_number = shape.Anchor.Information(3)
                        text = text.replace("{اسم المعلم}", teacher_prefix)
                        text = text.replace("{اسم المذكرة}", note_name)
                        text = text.replace("{رقم الهاتف}", phone_number)
                        #text = text.replace("{العلامة المائية}", water_mark)
                        shape.TextFrame.TextRange.Text = text

                        if "{الشعار}" in text:
                            logo_path = str(logo_path).strip() if pd.notna(logo_path) else ""
                            if logo_path and os.path.exists(logo_path):
                                try:
                                    transparent_logo_path = config.TRANSPARENT_LOGO_TEMP_PATH
                                    img = cv2.imread(logo_path, cv2.IMREAD_UNCHANGED)

                                    if img.shape[-1] == 3:
                                        img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)

                                    alpha = img[:, :, 3]
                                    alpha = cv2.multiply(alpha, 0.75)
                                    img[:, :, 3] = np.clip(alpha, 0, 255).astype(np.uint8)

                                    h, w = alpha.shape
                                    gradient = np.linspace(.5, 1, w, dtype=np.float32)
                                    gradient = np.tile(gradient, (h, 1))
                                    img[:, :, 3] = (img[:, :, 3] * gradient).astype(np.uint8)

                                    cv2.imwrite(transparent_logo_path, img)

                                    width = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)
                                    height = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)

                                     # 🔥 حذف النص {الشعار} قبل إضافة الصورة

                                    new_shape = doc.Shapes.AddPicture(transparent_logo_path , False,True, shape.Left + 10,  shape.Top + 30, width, height )
                                    shape.Delete()
                                    print(f"✅ Transparency applied based on brightness")
                                    print(f"تم حذف النص واستبداله بالصورة في الصفحة {page_number}")

                                    os.remove(transparent_logo_path)

                                except Exception as e:
                                    print(f"⚠️ حدث خطأ أثناء إضافة الشعار: {e}")

                            else:
                                # إذا لم يكن هناك مسار صالح، حذف النص فقط
                                text = text.replace("{الشعار}", "")
                                shape.TextFrame.TextRange.Text = text
                                print(f"⚠️ لم يتم العثور على صورة الشعار في الصفحة {page_number}، تم حذف النص فقط!")

                        if "{العلامة المائية}" in text:
                            water_mark = str(water_mark).strip() if pd.notna(
                                water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                            # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                            if not water_mark:
                                teacher_name = str(teacher_name).strip()
                                if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                    watermark_text = f"أ. {teacher_name}"
                                else:
                                    watermark_text = teacher_name

                            # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                            shape.TextFrame.TextRange.Text = water_mark
                            print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")


                for section in doc.Sections:
                    header = section.Headers(1)
                    for shape in header.Shapes:
                        if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                            text = shape.TextFrame.TextRange.Text
                            text = text.replace("{اسم المعلم}", teacher_prefix)
                            text = text.replace("{اسم المذكرة}", note_name)
                            text = text.replace("{رقم الهاتف}", phone_number)
                            #text = text.replace("{العلامة المائية}", water_mark)
                            shape.TextFrame.TextRange.Text = text

                            if "{الشعار}" in text:
                                logo_path = str(logo_path).strip() if pd.notna(logo_path) else ""
                                if logo_path and os.path.exists(logo_path):
                                    try:
                                        transparent_logo_path = config.TRANSPARENT_LOGO_TEMP_PATH
                                        img = cv2.imread(logo_path, cv2.IMREAD_UNCHANGED)

                                        if img.shape[-1] == 3:
                                            img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)

                                        alpha = img[:, :, 3]
                                        alpha = cv2.multiply(alpha, 0.5)
                                        img[:, :, 3] = alpha

                                        h, w = alpha.shape
                                        gradient = np.linspace(0, 1, w, dtype=np.float32)
                                        gradient = np.tile(gradient, (h, 1))
                                        img[:, :, 3] = (img[:, :, 3] * gradient).astype(np.uint8)

                                        cv2.imwrite(transparent_logo_path, img)

                                        width = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)
                                        height = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)

                                        # 🔥 حذف النص {الشعار} قبل إضافة الصورة

                                        new_shape = doc.Shapes.AddPicture(transparent_logo_path, False, True, shape.Left - 10,
                                                                          shape.Top + 10 , width, height)
                                        shape.Delete()
                                        print(f"✅ Transparency applied based on brightness")
                                        print(f"تم حذف النص واستبداله بالصورة في الصفحة {page_number}")

                                        os.remove(transparent_logo_path)

                                    except Exception as e:
                                        print(f"⚠️ حدث خطأ أثناء إضافة الشعار: {e}")

                                else:
                                    # إذا لم يكن هناك مسار صالح، حذف النص فقط
                                    text = text.replace("{الشعار}", "")
                                    shape.TextFrame.TextRange.Text = text
                                    print(f"⚠️ لم يتم العثور على صورة الشعار في الصفحة {page_number}، تم حذف النص فقط!")

                            if "{العلامة المائية}" in text:
                                water_mark = str(water_mark).strip() if pd.notna(
                                    water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                                # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                                if not water_mark:
                                    teacher_name = str(teacher_name).strip()
                                    if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                        water_mark = f"أ. {teacher_name}"
                                    else:
                                        water_mark = teacher_name

                                # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                                shape.TextFrame.TextRange.Text = water_mark
                                print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")

            # تعديل النصوص داخل محتوى المستند
                content_text = doc.Content.Text

                # حفظ المستند كملف PDF
                export_started_at = time.perf_counter()
                export_started_at = time.perf_counter()
                export_word_to_pdf(doc, output_pdf)
                log_timing("تصدير Word إلى PDF", export_started_at, os.path.basename(output_pdf))
                log_timing("تصدير Word إلى PDF", export_started_at, os.path.basename(output_pdf))
                doc.Close(SaveChanges=0)
                print(f"✅ تم إغلاق الملف : {output_pdf}")
                # ✅ نقفل نسخة Word دي هنا (جوه القفل _word_concurrency_limit، يعني
                # مضمون إن معدش نسخة Word تانية شغالة في نفس اللحظة) قبل ما نسيب
                # القفل، عشان نضمن إن معاش أكتر من نسخة Word حية في نفس اللحظة
                # خالص - ده اللي كان بيسبب "Command failed"/"operation is canceled"
                # حتى لو معظم الوقت نسخة واحدة بس هي اللي بتتعامل مع الملفات فعليًا
                try:
                    word.Quit()
                except Exception:
                    pass
                # مهلة صغيرة قبل ما نسيب القفل: word.Quit() بيرجع للكود فورًا بس
                # عملية WINWORD.exe ممكن تاخد لحظة زيادة تقفل فعليًا على مستوى
                # الويندوز. لو النسخة الجاية بدأت قبل ما دي تقفل خالص، بيحصل تصادم
                time.sleep(0.2)
                _word_concurrency_limit.release()
                semaphore_acquired = False
                # نتحقق من وجود الـ PDF بعد ما Word يقفل فعلًا، مش قبله.
                finalize_pdf_output(output_pdf, add_password=add_password, password=password, protect_as_images=protect_as_images)

                print(f"✅ تم إنشاء الملف بنجاح: {output_pdf}")
                processed_files.append(output_pdf)
                os.remove(temp_file_path)
                print(f"🗑️ تم حذف النسخة المؤقتة: {temp_file_path}")

                #msgbox.showinfo("نجاح", f"تم إنشاء الملف وحفظه بنجاح:\n{output_pdf}")

            except Exception as e:
                recovered_pdf = False
                if 'output_pdf' in locals() and file_exists_with_size(output_pdf):
                    try:
                        print(f"⚠️ حدث خطأ بعد إنشاء PDF على الأغلب، سأحاول إنقاذ الملف الموجود بدل إعادته من الصفر: {output_pdf}")
                        finalize_pdf_output(output_pdf, add_password=add_password, password=password, protect_as_images=protect_as_images)
                        if output_pdf not in processed_files:
                            processed_files.append(output_pdf)
                        recovered_pdf = True
                    except Exception as recovery_error:
                        print(f"⚠️ فشل إنقاذ ملف الـ PDF الموجود: {recovery_error}")

                # حتى في حالة الفشل، لازم نقفل نسخة Word دي هنا (جوه القفل) قبل
                # ما نسيبه، عشان معاش نسخة معلّقة تفضل حية وتتصادم مع اللي بعدها
                try:
                    if doc is not None:
                        doc.Close(SaveChanges=0)
                except Exception:
                    pass
                try:
                    if word is not None:
                        word.Quit()
                except Exception:
                    pass
                if word is not None:
                    time.sleep(0.2)
                if semaphore_acquired:
                    _word_concurrency_limit.release()
                    semaphore_acquired = False

                # لازم نمسح النسخة المؤقتة من الملف الفاشل، وإلا هتفضل متراكمة في
                # Temp مع كل محاولة فاشلة وممكن تملي القرص (حصل بالفعل)
                try:
                    if temp_file_path and os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
                except Exception:
                    pass

                if recovered_pdf:
                    print(f"✅ تم الاحتفاظ بملف PDF الموجود رغم الخطأ العارض: {output_pdf}")
                    continue

                attempts_so_far = file_attempts.get(specific_file, 0) + 1
                file_attempts[specific_file] = attempts_so_far
                if attempts_so_far < 6:
                    print(f"⚠️ خطأ أثناء معالجة الملف {template_path} (محاولة {attempts_so_far}/6)، هيتعاد المحاولة: {e}")
                    time.sleep(2)
                    file_queue.append(specific_file)
                else:
                    print(f"⚠️ خطأ أثناء معالجة الملف {template_path} بعد 6 محاولات: {e}")
    finally:
        print("Done")
        pythoncom.CoUninitialize()
    return processed_files

def process_orders(tabs, frame_upload, links_container, frame_links, work_folder_name, add_password=True, shutdown_after=False, progress_callback=None, auto_export_failed=False, failed_orders_callback=None, local_only=False, protect_as_images=True, upload_workers=1, source_excel=None, templates_root=None, run_mode="normal"):
    try:
        # لوحة التقدّم الحقيقية بقت في الواجهة الجديدة (progress_callback)، فالليبل ده
        # بيتعمله بس عشان process_grouped_data لسه محتاجاه كمتغير يقفله في النهاية (finally)
        loading_label = tk.Label(frame_upload, text="جاري معالجة الطلبات...")

        # مسح أي روابط قديمة من الواجهة
        for widget in links_container.winfo_children():
            widget.destroy()

        if not work_folder_name:
            msgbox.showerror("خطأ", "يرجى اختيار فولدر الشغل من القايمة قبل المتابعة!")
            return

        source_excel = source_excel or excel_file
        templates_root = templates_root or selected_folder
        if not source_excel or not os.path.exists(source_excel):
            msgbox.showerror("خطأ", "يرجى اختيار ملف Excel قبل المتابعة!")
            return

        if not templates_root or not os.path.exists(templates_root):
            msgbox.showerror("خطأ", "يرجى اختيار مجلد القوالب قبل المتابعة!")
            return

        # 🟢 تشغيل المعالجة في ثريد منفصل (مش على نفس ثريد الواجهة) عشان الواجهة
        # تفضل مستجيبة، ولو تاب "الشعار" شغال في نفس الوقت يقدر يبدأ من غير ما يستنى ده يخلص
        clear_failed_orders(run_mode)
        if failed_orders_callback:
            failed_orders_callback(0)
        run = run_history.create(
            run_mode, work_folder_name, business_root_folder or settings.get_business_root_folder(),
            source_excel, local_only,
        )
        # The snapshot lets delivery-only retry work even if the original sheet changes later.
        shutil.copy2(source_excel, run["snapshot"])
        _job_started(shutdown_after)
        threading.Thread(
            target=process_grouped_data,
            args=(loading_label, tabs, frame_links, links_container, work_folder_name, add_password, shutdown_after, progress_callback, auto_export_failed, failed_orders_callback, local_only, run["id"], protect_as_images, upload_workers, source_excel, templates_root, run_mode),
            daemon=True
        ).start()

    except Exception as e:
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")

def close_word():
    print("ℹ️ تم تجاوز الإغلاق العام لـ Word حفاظًا على أي ملفات Word مفتوحة خارج التطبيق.")


def build_teacher_whatsapp_message(teacher_name, teacher_rows, work_folder_name, add_password):
    first_name = short_teacher_name(teacher_name)

    link_passwords = {}
    for _, row in teacher_rows.iterrows():
        link = str(row['الرابط']).strip()
        if not link:
            continue
        if link not in link_passwords:
            if add_password:
                client_code = str(row['كود العميل']).strip().zfill(5)
                link_passwords[link] = generate_password(client_code, work_folder_name)
            else:
                link_passwords[link] = None

    links_text = ""
    for link, password in link_passwords.items():
        links_text += f"{link}\n"
        if password:
            links_text += f"كلمة السر: {password}\n\n"
        else:
            links_text += "\n"

    template_values = {
        "الاسم": first_name,
        "الروابط": links_text.strip(),
        "رابط الجروب": config.WHATSAPP_GROUP_INVITE_LINK,
    }
    # أي متغير باسم عمود من الإكسل يجمع القيم المختلفة للمدرس بدل فقدان طلباته الأخرى.
    for column in teacher_rows.columns:
        values = []
        for raw_value in teacher_rows[column]:
            if pd.isna(raw_value):
                continue
            value = str(raw_value).strip()
            if value and value not in values:
                values.append(value)
        template_values[str(column).strip()] = "\n".join(values)

    message = settings.get_teacher_whatsapp_template()
    # The placeholder now owns its title, so old templates like "أ. {الاسم}"
    # remain compatible without producing a duplicated title.
    for title in ("أ.", "د.", "م."):
        message = message.replace(f"{title} {{الاسم}}", "{الاسم}")
    for placeholder, value in template_values.items():
        message = message.replace(f"{{{placeholder}}}", value)
    return message


def validate_delivery_data(data):
    """يوقف التنفيذ برسالة واضحة قبل إرسال ملفات لشخص أو بصلاحية غير مقصودة."""
    required_columns = {"كود العميل", "كود الطلب", "كود الملف", "اسم المعلم", "رقم الواتس"}
    missing_columns = sorted(required_columns - set(data.columns))
    if missing_columns:
        raise ValueError(f"أعمدة مطلوبة غير موجودة في الشيت: {', '.join(missing_columns)}")

    for client_code, client_rows in data.groupby("كود العميل"):
        open_values = {
            str(value).strip()
            for value in client_rows["فتح الملف"]
            if pd.notna(value) and str(value).strip()
        }
        if len(open_values) > 1:
            raise ValueError(f"العميل {client_code} لديه أكثر من قيمة في عمود فتح الملف: {', '.join(sorted(open_values))}")

    for teacher_name, teacher_rows in data.groupby("اسم المعلم"):
        whatsapp_numbers = {
            str(value).strip().split(".")[0]
            for value in teacher_rows["رقم الواتس"]
            if pd.notna(value) and str(value).strip()
        }
        if len(whatsapp_numbers) > 1:
            raise ValueError(f"المعلم {teacher_name} لديه أكثر من رقم واتساب في نفس الشيت.")


def prepare_delivery_data(data):
    """يوحّد الأعمدة الاختيارية قبل التحقق حتى لا يوقف غيابها الطلبات."""
    data.columns = data.columns.str.strip()
    if "فتح الملف" not in data.columns:
        # الفارغ يعني رابط مفتوح، حسب قاعدة العمل المتفق عليها.
        data["فتح الملف"] = ""
        print("[INFO] Optional open-link column is missing; public links will be used.")
    return data

def process_client(client_code, client_orders, business_root_folder, work_folder_name, loading_label, tabs, frame_links, links_container, data, links_list, add_password=True, protect_as_images=True, templates_root=None):
    def process_order(order_code, order_rows):
        order_succeeded = True
        order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in order_rows.iterrows()))
        for _, row in order_rows.iterrows():
            file_code = str(row["كود الملف"]).strip()
            try:
                output_pdfs = modify_and_protect_templates(
                    client_code=client_code,
                    order_codes=order_codes,
                    file_code=file_code,
                    teacher_name=row["اسم المعلم"],
                    note_name=row["اسم المذكرة"],
                    phone_number=row["رقم الهاتف"],
                    water_mark=row["العلامة المائية"],
                    logo_path=row["الشعار"],
                    open_link=row["فتح الملف"],
                    business_root_folder=business_root_folder,
                    work_folder_name=work_folder_name,
                    word=None,
                    add_password=add_password,
                    protect_as_images=protect_as_images,
                    templates_root=templates_root,
                )

                if output_pdfs:
                    print(f"✅ تم إنشاء {len(output_pdfs)} ملف PDF للملف {file_code} في الطلب {order_code} بنجاح!")
                else:
                    print(f"⚠️ لم يتم إنشاء أي ملفات PDF للملف {file_code} في الطلب {order_code}.")
                    order_succeeded = False
            except Exception as e:
                print(f"❌ خطأ في معالجة الملف {file_code} في الطلب {order_code}: {e}")
                order_succeeded = False
        return order_succeeded

    grouped_orders = list(client_orders.groupby("كود الطلب", sort=False))
    with concurrent.futures.ThreadPoolExecutor(max_workers=_order_parallelism) as order_executor:
        order_futures = [
            order_executor.submit(process_order, order_code, order_rows.copy())
            for order_code, order_rows in grouped_orders
        ]
        return all(future.result() for future in order_futures)

    # راجع process_grouped_data: الرفع على درايف بقى بيحصل هناك فور ما العميل ده يخلص معالجة، مش هنا

def process_grouped_data(loading_label, tabs, frame_links, links_container, work_folder_name, add_password=True, shutdown_after=False, progress_callback=None, auto_export_failed=False, failed_orders_callback=None, local_only=False, run_id=None, protect_as_images=True, upload_workers=1, source_excel=None, templates_root=None, pause_mode="normal"):
    try:
        links_list = []
        global business_root_folder
        if business_root_folder is None:
            business_root_folder = settings.get_business_root_folder()

        # 🟢 كل عميل بيترفع على درايف فور ما تخلص معالجته، وفور ما آخر عميل لمعلم معيّن يخلص رفع
        # بيتبعت له رسالة الواتساب على طول (من غير ما نستنى باقي المعلمين/العملاء يخلصوا كمان)
        # القيم دي متراكمة عبر كل الباصات (لو الشيت اتزود فيه صفوف جديدة أثناء الشغل)
        all_links = []
        state_lock = threading.Lock()
        sent_messages_count = [0]
        failed_numbers = []
        teachers_with_failed_clients = set()
        failed_rows = []

        # مفاتيح الصفوف اللي اتعالجت خلاص (كود العميل، كود الطلب، كود الملف) - عشان
        # لما نعيد قراءة الشيت بعد ما نخلص، نقدر نميّز صف جديد اتضاف فعلاً عن صف
        # قديم فشل (الفاشل معدش نعيد محاولته تاني هنا، بس منضيعش الوقت في لوب لا نهائي)
        known_keys = set()
        pass_number = 0
        idle_scans = 0

        while True:
            pass_number += 1
            data = pd.read_excel(source_excel or excel_file)
            data = prepare_delivery_data(data)
            validate_delivery_data(data)

            # لو عمود "الرابط" فاضي في ملف الإكسل، بانداز بيفترضه float64 (NaN)، وبعدين
            # كتابة رابط (نص) فيه بترمي ValueError. نجبره يبقى object من الأول عشان
            # يقبل نصوص، بدل ما نستنى العميل يخلص رفعه ونكتشف المشكلة وقتها
            if "الرابط" not in data.columns:
                data["الرابط"] = None
            data["الرابط"] = data["الرابط"].astype("object")

            # الرابط يكتبه التطبيق بنفسه؛ لا نضعه في البصمة حتى لا يعيد الطلب بعد الحفظ.
            # أما تعديل أي بيانات أخرى في الصف فينشئ بصمة جديدة ويسمح بإعادة المحاولة.
            key_columns = [column for column in data.columns if column not in {"الرابط", "_row_key"}]
            row_keys = [
                tuple("" if pd.isna(value) else str(value).strip() for value in row)
                for row in data[key_columns].itertuples(index=False, name=None)
            ]
            data["_row_key"] = row_keys
            new_rows = data[~data["_row_key"].isin(known_keys)].drop(columns=["_row_key"])

            if pass_number == 1:
                print("تمت قراءة البيانات بنجاح!")
            elif new_rows.empty:
                # Keep the job alive briefly after a batch: rows saved while it was
                # running are picked up without asking the operator to restart.
                idle_scans += 1
                if idle_scans >= 3:
                    print("✅ لم تتم إضافة صفوف جديدة خلال فترة المراجعة - خلصنا.")
                    break
                print("⏳ ننتظر صفوفًا جديدة في الشيت قبل الإنهاء...")
                time.sleep(5)
                continue
            else:
                idle_scans = 0
                print(f"🔁 لقينا {len(new_rows)} صف جديد اتضاف على الشيت بعد ما بدأنا، هنعالجهم كمان")

            known_keys.update(row_keys)
            grouped_data = new_rows.groupby("كود العميل", sort=False)

            # تجهيز مسبق: كام عميل باقي لكل معلم، عشان نعرف امتى نبعت رسالة المعلم (لما يخلصوا كلهم)
            teacher_of_client = {}
            teacher_remaining = {}
            for client_code, client_orders in grouped_data:
                teacher_name = str(client_orders["اسم المعلم"].iloc[0]).strip()
                teacher_of_client[client_code] = teacher_name
                teacher_remaining[teacher_name] = teacher_remaining.get(teacher_name, 0) + 1

            total_clients = len(teacher_of_client)
            completed_clients = [0]
            upload_gate = threading.BoundedSemaphore(max(1, int(upload_workers)))
            if progress_callback:
                try:
                    progress_callback(0, total_clients)
                except Exception as e:
                    print(f"⚠️ خطأ في progress_callback: {e}")

            def send_whatsapp_for_teacher(teacher_name):
                """بتتنده أول ما كل عملاء المعلم ده يخلصوا رفع، وبتبعت له رسالة واحدة فيها كل روابطه"""
                teacher_rows = data[
                    (data['اسم المعلم'].astype(str).str.strip() == teacher_name)
                    & pd.notna(data['الرابط']) & data['الرابط'].astype(str).str.strip().ne('')
                ]
                if teacher_rows.empty:
                    return  # كل عملاء المعلم ده فشل رفعهم، مفيش حاجة نبعتها

                full_number = None
                try:
                    whatsapp_ready_started_at = time.perf_counter()
                    driver = web_driver.ensure_whatsapp_ready()
                    if driver is None:
                        print("⚠️ تعذر تشغيل المتصفح! تأكد من أن msedgedriver.exe موجود.")
                        with state_lock:
                            failed_numbers.append(teacher_name)
                        return
                    log_timing("تجهيز واتساب للمعلم", whatsapp_ready_started_at, teacher_name)
                    message = build_teacher_whatsapp_message(teacher_name, teacher_rows, work_folder_name, add_password)

                    raw_number = teacher_rows.iloc[0]['رقم الواتس']
                    number = str(raw_number).strip().split('.')[0]  # دايمًا String

                    # ✅ تنسيق الرقم
                    if number.startswith("0"):
                        full_number = config.EGYPT_COUNTRY_CODE + number[1:]
                    elif not number.startswith("+"):
                        full_number = config.EGYPT_COUNTRY_CODE + number
                    else:
                        full_number = number

                    if not full_number[1:].isdigit():
                        print(f"❌ الرقم غير صالح: {full_number}")
                        with state_lock:
                            failed_numbers.append(full_number)
                        return

                    print(f"📞 الرقم بعد التعديل: {full_number}")

                    encoded_message = urllib.parse.quote(message)
                    whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"
                    whatsapp_send_started_at = time.perf_counter()
                    driver.get(whatsapp_url)
                    was_unread = web_driver.current_chat_is_unread(driver)
                    print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")

                    # ✅ البحث عن زر الإرسال
                    try:
                        web_driver.send_current_whatsapp_message(driver)
                        if was_unread:
                            web_driver.restore_current_chat_unread(driver)
                        with state_lock:
                            sent_messages_count[0] += 1
                        print(f"✅ تم إرسال الرسالة إلى {full_number}")
                        log_timing("إرسال واتساب", whatsapp_send_started_at, full_number)
                        time.sleep(settings.get_whatsapp_delay_seconds())
                    except TimeoutException:
                        print(f"🚫 الرقم {full_number} غير مسجل على واتساب أو زر الإرسال غير متاح.")
                        with state_lock:
                            failed_numbers.append(full_number)

                except Exception as e:
                    print(f"❌ فشل الإرسال للمعلم {teacher_name}. الخطأ: {str(e)}")
                    with state_lock:
                        failed_numbers.append(full_number or teacher_name)

            def process_client_only(client_code, client_orders):
                wait_if_paused(pause_mode, run_id)
                order_codes = sorted({str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()})
                order_label = "، ".join(order_codes)
                if run_id:
                    run_history.update(run_id, stage=f"Closing orders in parallel (max 10): {order_label}")
                    run_history.add_detail(run_id, f"Closing batch (parallel max 10) | orders {order_label}")
                client_started_at = time.perf_counter()
                if progress_callback:
                    progress_callback(completed_clients[0], total_clients, f"تقفيل متوازي حتى 10 طلبات: {order_label}")
                conversion_succeeded = process_client(client_code, client_orders, business_root_folder, work_folder_name, loading_label, tabs, frame_links, links_container, data, links_list, add_password, protect_as_images, templates_root)
                link = None
                if conversion_succeeded and not local_only:
                    # False means Drive was attempted and did not verify; do not run it twice.
                    link = False
                    client_folder_name = "_".join(order_codes)
                    raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
                    share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
                    if run_id:
                        run_history.update(run_id, stage=f"Uploading order {client_folder_name}")
                        run_history.add_detail(run_id, f"Drive upload started | order {client_folder_name}")
                    if progress_callback:
                        progress_callback(completed_clients[0], total_clients, f"رفع متوازي على Drive: {client_folder_name}")
                    with upload_gate:
                        link = upload_order_files(client_code, client_folder_name, business_root_folder, work_folder_name, share_value)
                    if run_id and link:
                        run_history.add_detail(run_id, f"Drive verified | order {client_folder_name}")
                return client_code, client_orders.copy(), client_started_at, conversion_succeeded, link

            with concurrent.futures.ThreadPoolExecutor(max_workers=_client_parallelism) as executor:
                futures = {
                    executor.submit(process_client_only, client_code, client_orders): (client_code, client_orders.copy())
                    for client_code, client_orders in grouped_data
                }
                for future in concurrent.futures.as_completed(futures):
                    fallback_client_code, fallback_client_orders = futures[future]
                    try:
                        client_code, client_orders, client_started_at, conversion_succeeded, preuploaded_link = future.result()
                    except Exception as e:
                        client_code, client_orders = fallback_client_code, fallback_client_orders
                        client_started_at = time.perf_counter()
                        conversion_succeeded = False
                        preuploaded_link = None
                        print(f"❌ خطأ في تقفيل العميل {client_code}: {e}")

                    raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
                    share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
                    order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))
                    client_folder_name = "_".join(order_codes)

                    shareable_link = preuploaded_link
                    failure_reason = None
                    if conversion_succeeded and local_only:
                        # PDFs are complete locally and intentionally await the delivery-only tab.
                        shareable_link = "LOCAL_ONLY"
                        print(f"[RUN] Local-only completed: {client_folder_name}")
                    elif conversion_succeeded and shareable_link is None:
                        wait_if_paused(pause_mode, run_id)
                        if run_id:
                            run_history.update(run_id, stage=f"Uploading order {client_folder_name}")
                            run_history.add_detail(run_id, f"Drive upload started | order {client_folder_name}")
                        if progress_callback:
                            progress_callback(completed_clients[0], total_clients, f"رفع طلب {client_folder_name} على Drive")
                        shareable_link = upload_order_files(
                            client_code, client_folder_name, business_root_folder, work_folder_name, share_value,
                            progress_callback=lambda percentage: progress_callback(
                                completed_clients[0], total_clients,
                                f"رفع طلب {client_folder_name} على Drive: {percentage}%",
                            ) if progress_callback else None,
                        )
                        if not shareable_link:
                            failure_reason = "فشل رفع الملفات أو التحقق من اكتمالها على Google Drive"
                        elif run_id:
                            run_history.add_detail(run_id, f"Drive verified | order {client_folder_name}")
                    else:
                        print(f"🚫 لن يتم رفع أو إرسال الطلب {client_folder_name} لأن تحويل ملفاته لم يكتمل.")
                        failure_reason = "فشل تحويل ملف Word أو إنشاء PDF بعد كل المحاولات"

                    teacher_name = teacher_of_client[client_code]
                    fire_teacher_message = False
                    with state_lock:
                        if shareable_link and shareable_link != "LOCAL_ONLY":
                            data.loc[client_orders.index, "الرابط"] = shareable_link
                            all_links.append(shareable_link)
                        elif shareable_link == "LOCAL_ONLY":
                            # Do not send WhatsApp or mark a Drive link for local-only jobs.
                            pass
                        else:
                            teachers_with_failed_clients.add(teacher_name)
                            failed_client_rows = client_orders.copy()
                            failed_client_rows["سبب الفشل"] = failure_reason or "لم يكتمل الطلب"
                            failed_rows.append(failed_client_rows)
                        teacher_remaining[teacher_name] -= 1
                        if teacher_remaining[teacher_name] == 0 and not local_only and teacher_name not in teachers_with_failed_clients:
                            fire_teacher_message = True
                        elif teacher_remaining[teacher_name] == 0:
                            print(f"🚫 لن يتم إرسال رسالة للمعلم {teacher_name} لأن أحد طلباته لم يكتمل.")
                        completed_clients[0] += 1
                        done_count = completed_clients[0]

                    if progress_callback:
                        try:
                            progress_callback(done_count, total_clients)
                        except Exception as e:
                            print(f"⚠️ خطأ في progress_callback: {e}")

                    if fire_teacher_message:
                        if run_id:
                            run_history.update(run_id, stage=f"Sending WhatsApp to {teacher_name}")
                            run_history.add_detail(run_id, f"WhatsApp sending | orders for {teacher_name}")
                        if progress_callback:
                            progress_callback(done_count, total_clients, f"إرسال واتساب للمعلم {teacher_name}")
                        with web_driver.driver_lock:
                            send_whatsapp_for_teacher(teacher_name)
                        if run_id:
                            run_history.add_detail(run_id, f"WhatsApp confirmed | orders for {teacher_name}")
                    log_timing("زمن معالجة العميل", client_started_at, str(client_code))

            # تحديث الملف والواجهة
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                temp_path = tmp.name
            data.drop(columns=["_row_key"], errors="ignore").to_excel(temp_path, index=False)
            shutil.move(temp_path, source_excel or excel_file)
            if run_id:
                shutil.copy2(source_excel or excel_file, run_history.get(run_id)["snapshot"])

        failed_orders_count = save_failed_orders(pause_mode, failed_rows)
        if auto_export_failed and failed_orders_count:
            export_failed_orders(pause_mode)
        if failed_orders_callback:
            ui_after(loading_label, lambda count=failed_orders_count: failed_orders_callback(count))

        sent_messages_count = sent_messages_count[0]
        ui_render_links_summary(links_container, all_links, sent_messages_count, failed_numbers)
        if run_id:
            run_history.update(run_id, status="local_complete" if local_only else "completed", stage="Completed")
        print("✅ تم الانتهاء من معالجة جميع العملاء!")
        tabs.select(frame_links)

    except Exception as e:
        if run_id:
            run_history.update(run_id, status="failed", stage="Failed", details=str(e))
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")
        ui_showerror(loading_label, "خطأ", f"⚠️ حدث خطأ أثناء معالجة الطلبات:\n{e}")

    finally:
        # نقفل كل نسخ Word المتبقية دفعة واحدة هنا (بعد ما الدفعة كلها خلصت)،
        # مش أثناء المعالجة لكل ملف لوحده - ده كان بيسبب تصادم "Command failed"
        close_word()
        ui_destroy(loading_label)
        _job_finished()


# ==============================================================================
# ⚠️ DEPRECATED — شغل 2024 اتوقف. الكود ده مش متنده من الواجهة (gui.py) تاني،
# وسايبينه هنا للرجوع له بس لو احتجناه، مش لازم يتحدث أو يتعدل.
# ==============================================================================
# 2024
def generate_password_24(client_code):
    client_code = format_code(client_code)
    padded_client_code = str(client_code).zfill(5)
    return f"{config.PASSWORD_PREFIX}{padded_client_code}{config.PASSWORD_YEAR_SUFFIX_2024}"

def modify_2024(client_code, order_codes, file_code, teacher_name, phone_number, water_mark, logo_path, note_name,open_link, business_root_folder, word):
    global selected_folder
    if not selected_folder:
        print("⚠️ لم يتم اختيار مجلد القوالب الأصلية!")
        messagebox.showerror("خطأ", "لم يتم اختيار مجلد القوالب الأصلية")
        #msgbox.showinfo("خطأ", "لم يتم اختيار مجلد القوالب الأصلية")
        return

    file_code = format_code(file_code)
    templates_folder = os.path.join(selected_folder, file_code)
    print("تم فتح ملف كوده", templates_folder)

    base_path = os.path.join(business_root_folder, config.ORDERS_SUBPATH_2024)
    client_folder = os.path.join(base_path, "_".join(order_codes))
    file_folder = os.path.join(client_folder, file_code)
    os.makedirs(file_folder, exist_ok=True)

    word_files = glob.glob(os.path.join(templates_folder, "*.docx"))
    if not word_files:
        print(f"⚠️ لا توجد ملفات وورد في المجلد {templates_folder}")
        messagebox.showerror("خطأ", f"⚠️ لا توجد ملفات وورد في المجلد {templates_folder}")
        return

    print(f"📄 تم العثور على {len(word_files)} ملف وورد في المجلد:")
    for file in word_files:
        print(f"  - {os.path.basename(file)}")

    phone_number = clean_phone_number(phone_number)
    password = generate_password_24(client_code)

    processed_files = []

    try:
        threads = []
        for specific_file in word_files:
            try:
                template_path = os.path.normpath(specific_file)
                if os.path.basename(template_path).startswith("~$"):
                    continue  # تخطي ملفات Word المؤقتة

                if not os.path.exists(template_path):
                    print(f"⚠️ الملف غير موجود، سيتم تخطيه: {template_path}")
                    continue

                temp_dir = tempfile.gettempdir()
                thread_temp_dir = os.path.join(temp_dir, f"thread_{threading.get_ident()}")
                os.makedirs(thread_temp_dir, exist_ok=True)

                # 🟢 إنشاء نسخة فريدة من الملف لكل ثريد
                # temp_file_path = os.path.join(thread_temp_dir, os.path.basename(template_path))
                # shutil.copy2(template_path, temp_file_path)
                #
                # print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")

                orig_name, ext = os.path.splitext(os.path.basename(template_path))
                unique_suffix = uuid.uuid4().hex  # بيطلع رقم/كود عشوائي وفريد
                temp_file_name = f"{orig_name}__{unique_suffix}{ext}"

                temp_file_path = os.path.join(thread_temp_dir, temp_file_name)
                shutil.copy2(template_path, temp_file_path)

                print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")

                file_name = os.path.basename(template_path).replace(".docx", "")
                #note_name = file_name
                output_pdf = os.path.join(file_folder, f"{order_codes[0]}_{file_code}_{file_name}_{teacher_name}.pdf")

                word = win32com.client.DispatchEx("Word.Application")
                word.Visible = False

                print(f"📂 فتح الملف: {temp_file_path}")
                doc = word.Documents.Open(temp_file_path)  # ✅ فتح النسخة المؤقتة بدلاً من الأصل

                teacher_prefix = teacher_name if teacher_name.startswith(("د.", "أ.")) else f"أ. {teacher_name}"

                # تعديل النصوص داخل الأشكال (Shapes)
                for shape in doc.Shapes:
                    if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                        text = shape.TextFrame.TextRange.Text
                        page_number = shape.Anchor.Information(3)
                        text = text.replace("{اسم المعلم}", teacher_prefix)
                        text = text.replace("{اسم المذكرة}", note_name)
                        text = text.replace("{رقم الهاتف}", phone_number)
                        #text = text.replace("{العلامة المائية}", water_mark)
                        shape.TextFrame.TextRange.Text = text

                        if "{الشعار}" in text:
                            logo_path = str(logo_path).strip() if pd.notna(logo_path) else ""
                            if logo_path and os.path.exists(logo_path):
                                try:
                                    transparent_logo_path = config.TRANSPARENT_LOGO_TEMP_PATH
                                    img = cv2.imread(logo_path, cv2.IMREAD_UNCHANGED)

                                    if img.shape[-1] == 3:
                                        img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)

                                    alpha = img[:, :, 3]
                                    alpha = cv2.multiply(alpha, 0.75)
                                    img[:, :, 3] = np.clip(alpha, 0, 255).astype(np.uint8)

                                    h, w = alpha.shape
                                    gradient = np.linspace(.5, 1, w, dtype=np.float32)
                                    gradient = np.tile(gradient, (h, 1))
                                    img[:, :, 3] = (img[:, :, 3] * gradient).astype(np.uint8)

                                    cv2.imwrite(transparent_logo_path, img)

                                    width = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)
                                    height = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)

                                     # 🔥 حذف النص {الشعار} قبل إضافة الصورة

                                    new_shape = doc.Shapes.AddPicture(transparent_logo_path , False,True, shape.Left + 10,  shape.Top + 30, width, height )
                                    shape.Delete()
                                    print(f"✅ Transparency applied based on brightness")
                                    print(f"تم حذف النص واستبداله بالصورة في الصفحة {page_number}")

                                    os.remove(transparent_logo_path)

                                except Exception as e:
                                    print(f"⚠️ حدث خطأ أثناء إضافة الشعار: {e}")

                            else:
                                # إذا لم يكن هناك مسار صالح، حذف النص فقط
                                text = text.replace("{الشعار}", "")
                                shape.TextFrame.TextRange.Text = text
                                print(f"⚠️ لم يتم العثور على صورة الشعار في الصفحة {page_number}، تم حذف النص فقط!")

                        if "{العلامة المائية}" in text:
                            water_mark = str(water_mark).strip() if pd.notna(
                                water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                            # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                            if not water_mark:
                                teacher_name = str(teacher_name).strip()
                                if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                    watermark_text = f"أ. {teacher_name}"
                                else:
                                    watermark_text = teacher_name

                            # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                            shape.TextFrame.TextRange.Text = water_mark
                            print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")


                for section in doc.Sections:
                    header = section.Headers(1)
                    for shape in header.Shapes:
                        if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                            text = shape.TextFrame.TextRange.Text
                            text = text.replace("{اسم المعلم}", teacher_prefix)
                            text = text.replace("{اسم المذكرة}", note_name)
                            text = text.replace("{رقم الهاتف}", phone_number)
                            #text = text.replace("{العلامة المائية}", water_mark)
                            shape.TextFrame.TextRange.Text = text

                            if "{الشعار}" in text:
                                logo_path = str(logo_path).strip() if pd.notna(logo_path) else ""
                                if logo_path and os.path.exists(logo_path):
                                    try:
                                        transparent_logo_path = config.TRANSPARENT_LOGO_TEMP_PATH
                                        img = cv2.imread(logo_path, cv2.IMREAD_UNCHANGED)

                                        if img.shape[-1] == 3:
                                            img = cv2.cvtColor(img, cv2.COLOR_BGR2BGRA)

                                        alpha = img[:, :, 3]
                                        alpha = cv2.multiply(alpha, 0.5)
                                        img[:, :, 3] = alpha

                                        h, w = alpha.shape
                                        gradient = np.linspace(0, 1, w, dtype=np.float32)
                                        gradient = np.tile(gradient, (h, 1))
                                        img[:, :, 3] = (img[:, :, 3] * gradient).astype(np.uint8)

                                        cv2.imwrite(transparent_logo_path, img)

                                        width = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)
                                        height = 2 * 72  # 2 إنش = 144 نقطة (1 إنش = 72 نقطة)

                                        # 🔥 حذف النص {الشعار} قبل إضافة الصورة

                                        new_shape = doc.Shapes.AddPicture(transparent_logo_path, False, True, shape.Left - 10,
                                                                          shape.Top + 10 , width, height)
                                        shape.Delete()
                                        print(f"✅ Transparency applied based on brightness")
                                        print(f"تم حذف النص واستبداله بالصورة في الصفحة {page_number}")

                                        os.remove(transparent_logo_path)

                                    except Exception as e:
                                        print(f"⚠️ حدث خطأ أثناء إضافة الشعار: {e}")

                                else:
                                    # إذا لم يكن هناك مسار صالح، حذف النص فقط
                                    text = text.replace("{الشعار}", "")
                                    shape.TextFrame.TextRange.Text = text
                                    print(f"⚠️ لم يتم العثور على صورة الشعار في الصفحة {page_number}، تم حذف النص فقط!")

                            if "{العلامة المائية}" in text:
                                water_mark = str(water_mark).strip() if pd.notna(
                                    water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                                # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                                if not water_mark:
                                    teacher_name = str(teacher_name).strip()
                                    if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                        water_mark = f"أ. {teacher_name}"
                                    else:
                                        water_mark = teacher_name

                                # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                                shape.TextFrame.TextRange.Text = water_mark
                                print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")

            # تعديل النصوص داخل محتوى المستند
                content_text = doc.Content.Text

                # حفظ المستند كملف PDF
                doc.SaveAs(output_pdf, FileFormat=17)
                doc.Close(SaveChanges=0)
                print(f"✅ تم إغلاق الملف : {output_pdf}")

                # معالجة PDF كصور وإضافة كلمة المرور
                process_pdf_as_images(output_pdf)
                add_password_to_pdf(output_pdf, password)

                print(f"✅ تم إنشاء الملف بنجاح: {output_pdf}")
                processed_files.append(output_pdf)
                os.remove(temp_file_path)
                print(f"🗑️ تم حذف النسخة المؤقتة: {temp_file_path}")

                #msgbox.showinfo("نجاح", f"تم إنشاء الملف وحفظه بنجاح:\n{output_pdf}")

            except Exception as e:
                print(f"⚠️ خطأ أثناء معالجة الملف {template_path}: {e}")
                msgbox.showinfo("خطأ", "خطأ أثناء معالجة الملف ")
                #if 'doc' in locals():  # التأكد من أن doc مفتوح قبل محاولة إغلاقه
                #    doc.Close(SaveChanges=0)
    finally:
        print("Done")
        # try:
        #     if 'doc' in locals() and doc is not None:
        #         doc.Close(SaveChanges=0)
        # except:
        #     print("⚠️ لم يتمكن من إغلاق المستند")

        # word.Quit()
    return processed_files

def process_orders_24(tabs, old_frame, links_container, frame_links):
    try:
        loading_label = tk.Label(old_frame, text="جاري معالجة الطلبات...", fg="green", font=("Arial", 12, "bold"))
        loading_label.pack(pady=10)

        # مسح أي روابط قديمة من الواجهة
        for widget in links_container.winfo_children():
            widget.destroy()

        if not excel_file or not os.path.exists(excel_file):
            msgbox.showerror("خطأ", "يرجى اختيار ملف Excel قبل المتابعة!")
            return

        if not selected_folder or not os.path.exists(selected_folder):
            msgbox.showerror("خطأ", "يرجى اختيار مجلد القوالب قبل المتابعة!")
            return

        # استخدام after لاستدعاء الدالة التي تعالج البيانات
        old_frame.after(100, process_grouped_data_24, loading_label, tabs, frame_links, links_container)

    except Exception as e:
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")

def process_client_24(client_code, client_orders, business_root_folder, loading_label, tabs, frame_links, links_container, data, links_list):
    start_time = time.time()

    order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))
    client_folder_name = "_".join(order_codes)

    def process_file(row):
        """فتح جلسة Word مستقلة لكل ملف داخل الطلب"""
        try:
            word_app = win32com.client.Dispatch("Word.Application")
            word_app.Visible = False

            file_code = str(row["كود الملف"]).strip()
            order_code = str(row["كود الطلب"]).strip()

            output_pdfs = modify_2024(
                client_code=client_code,
                order_codes=order_codes,
                file_code=file_code,
                teacher_name=row["اسم المعلم"],
                note_name=row["اسم المذكرة"],
                phone_number=row["رقم الهاتف"],
                water_mark=row["العلامة المائية"],
                logo_path=row["الشعار"],
                open_link=row["فتح الملف"],
                business_root_folder=business_root_folder,
                word = word_app
            )

            if output_pdfs:
                print(f"✅ تم إنشاء {len(output_pdfs)} ملف PDF للملف {file_code} في الطلب {order_code} بنجاح!")
            else:
                print(f"⚠️ لم يتم إنشاء أي ملفات PDF للملف {file_code} في الطلب {order_code}.")

            # word_app.Quit()
        except Exception as e:
            print(f"❌ خطأ في معالجة الملف {file_code} في الطلب {order_code}: {e}")

    def process_order(order_rows):
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as file_executor:
            file_futures = [file_executor.submit(process_file, row) for _, row in order_rows.iterrows()]
            concurrent.futures.wait(file_futures)

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as order_executor:
        order_futures = [order_executor.submit(process_order, order_rows) for _, order_rows in client_orders.groupby("كود الطلب")]
        concurrent.futures.wait(order_futures)

    end_time = time.time()
    iteration_time = end_time - start_time
    print(client_code, "::::::::::::::::::::::::::::::::::::", str(iteration_time))

    # raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
    # share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
    # shareable_link = upload_order_files_24(client_code, client_folder_name, business_root_folder, share_value)
    # data.loc[client_orders.index, "الرابط"] = shareable_link
    #
    # with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
    #     temp_path = tmp.name
    # data.to_excel(temp_path, index=False)
    # time.sleep(1)
    # shutil.move(temp_path, excel_file)
    # links_list.append(shareable_link)
    # print(f"🔗 رابط مجلد العميل على Google Drive: {shareable_link}")

def process_grouped_data_24(loading_label, tabs, frame_links, links_container):
    try:
        links_list = []
        data = pd.read_excel(excel_file)
        print("تمت قراءة البيانات بنجاح!")
        data.columns = data.columns.str.strip()

        grouped_data = data.groupby("كود العميل")
        global business_root_folder
        if business_root_folder is None:
            business_root_folder = settings.get_business_root_folder()

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(process_client_24, client_code, client_orders, business_root_folder, loading_label, tabs, frame_links, links_container, data, links_list) for client_code, client_orders in grouped_data]

            for future in concurrent.futures.as_completed(futures):
                try:
                    #start_time = time.time()
                    future.result()

                except Exception as e:
                    print(f"❌ خطأ في أحد الـ Threads: {e}")


        # 🟢 مرحلة الرفع لكل العملاء مع بعض
        all_links = []
        for client_code, client_orders in grouped_data:
            raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
            share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
            order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))
            client_folder_name = "_".join(order_codes)

            shareable_link = upload_order_files_24(client_code, client_folder_name, business_root_folder,
                                                share_value)
            if shareable_link:
                data.loc[client_orders.index, "الرابط"] = shareable_link
                all_links.append(shareable_link)

        # تحديث الملف والواجهة
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
            temp_path = tmp.name
        data.to_excel(temp_path, index=False)
        shutil.move(temp_path, excel_file)

        # إضافة ارسال واتساب لينك
        driver = initialize_driver()
        if driver is None:
            msgbox.showerror("خطأ", "⚠️ تعذر تشغيل المتصفح! تأكد من أن msedgedriver.exe موجود.")
            return

        driver.get(config.WHATSAPP_WEB_URL)
        wait_for_whatsapp_login()
        df = data[pd.notna(data['الرابط']) & data['الرابط'].str.strip().ne('')]

        grouped_data = df.groupby('اسم المعلم')
        sent_messages_count = 0
        failed_numbers = []

        for teacher, data in grouped_data:
            full_number = None
            try:
                client_name = teacher.strip()
                name_parts = client_name.split()

                if name_parts[0] in ['أ.', 'د.', 'م.']:
                    if len(name_parts) > 1 and name_parts[1] in ['عبد', 'أبو']:
                        first_name = f"{name_parts[1]} {name_parts[2]}"
                    else:
                        first_name = name_parts[1]
                elif name_parts[0] in ['عبد', 'أبو'] and len(name_parts) > 1:
                    first_name = f"{name_parts[0]} {name_parts[1]}"
                else:
                    first_name = name_parts[0]

                message = f"السلام عليكم أ. {first_name}\n"
                message += "اتفضل حضرتك الملفات على الرابط ده:\n"

                link_passwords = {}
                for index, row in data.iterrows():
                    link = str(row['الرابط']).strip()
                    client_code = str(row['كود العميل']).strip().zfill(5)
                    # year = year_entry.get().strip()
                    password = f"{config.PASSWORD_PREFIX}{client_code}{config.PASSWORD_YEAR_SUFFIX_2024}"
                    if link not in link_passwords:
                        link_passwords[link] = password

                for link, password in link_passwords.items():
                    message += f"{link}\n"
                    message += f"كلمة السر: {password}\n\n"

                message += "ــــــــــــــــــــــــــــــــــــــ\n"
                message += "ولو حضرتك مش معانا في الجروب الخاص يا ريت تنورنا:\n"
                message += config.WHATSAPP_GROUP_INVITE_LINK

                raw_number = data.iloc[0]['رقم الواتس']
                number = str(raw_number).strip().split('.')[0]  # دايمًا String

                # ✅ تنسيق الرقم
                if number.startswith("0"):
                    full_number = config.EGYPT_COUNTRY_CODE + number[1:]
                elif not number.startswith("+"):
                    full_number = config.EGYPT_COUNTRY_CODE + number
                else:
                    full_number = number

                if not full_number[1:].isdigit():
                    print(f"❌ الرقم غير صالح: {full_number}")
                    failed_numbers.append(full_number)
                    continue

                print(f"📞 الرقم بعد التعديل: {full_number}")

                encoded_message = urllib.parse.quote(message)
                whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"
                driver.get(whatsapp_url)
                print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")
                time.sleep(10)

                # ✅ البحث عن زر الإرسال
                try:
                    send_button = WebDriverWait(driver, 30).until(
                        EC.presence_of_element_located(
                            (By.XPATH,
                             "//button[contains(@aria-label, 'إرسال') or contains(@aria-label, 'Send')]")
                        )
                    )
                    driver.execute_script("arguments[0].click();", send_button)
                    sent_messages_count += 1
                    print(f"✅ تم إرسال الرسالة إلى {full_number}")
                    time.sleep(random.randint(5, 15))  # تأخير عشوائي لتجنب الحظر
                except TimeoutException:
                    print(f"🚫 الرقم {full_number} غير مسجل على واتساب أو زر الإرسال غير متاح.")
                    failed_numbers.append(full_number)
                    continue

            except Exception as e:
                print(f"❌ فشل الإرسال للرقم: {full_number}. الخطأ: {str(e)}")

            summary_text = f"📢 **ملخص الإرسال** 📢\n✅ تم إرسال {sent_messages_count} رسالة بنجاح.\n"
            if failed_numbers:
                summary_text += f"❌ لم يتم إرسال الرسائل إلى {len(failed_numbers)} رقم:\n"
                summary_text += "\n".join([f"   - {num}" for num in failed_numbers])
            else:
                summary_text += "🎉 تم إرسال جميع الرسائل بنجاح! 🚀"

            # 🟢 عرض ملخص الإرسال في نفس التبويب
            summary_label = tk.Label(
                links_container,
                text=summary_text,
                font=("Arial", 11),
                justify="left",
                fg="black"
            )
            summary_label.pack(anchor="w", padx=5, pady=10)

        for link in all_links:
            link_label = tk.Label(
                links_container, text=link, fg="blue", cursor="hand2", font=("Arial", 10, "underline")
            )
            link_label.pack(anchor="w", padx=5, pady=2)
            link_label.bind("<Button-1>", open_link)

        #root.after(0, update_gui)

        print("✅ تم الانتهاء من معالجة جميع العملاء!")
        # close_word()
        tabs.select(frame_links)
        messagebox.showinfo("نجاح", "تم الانتهاء من رفع الملفات، وتم حفظ الروابط!")

    except Exception as e:
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")
        messagebox.showerror("خطأ", f"⚠️ حدث خطأ أثناء معالجة الطلبات:\n{e}")

    finally:
        # close_word()
        loading_label.destroy()


# logo
def modify_logo(client_code, order_codes, file_code, teacher_name, phone_number, water_mark, note_name, open_link, business_root_folder, work_folder_name, add_password=True, protect_as_images=True, templates_root=None):
    global selected_folder_logo
    templates_root = templates_root or selected_folder_logo
    if not templates_root:
        print("⚠️ لم يتم اختيار مجلد القوالب الأصلية!")
        return

    file_code = format_code(file_code)
    templates_folder = os.path.join(templates_root, "_".join(map(str, order_codes)), file_code)
    print("تم فتح ملف كوده", templates_folder)

    base_path = os.path.join(business_root_folder, work_folder_name, settings.get_logo_orders_subdir())
    client_folder = os.path.join(base_path, "_".join(order_codes))
    file_folder = os.path.join(client_folder, file_code)
    os.makedirs(file_folder, exist_ok=True)

    word_files = glob.glob(os.path.join(templates_folder, "*.docx"))
    if not word_files:
        print(f"⚠️ لا توجد ملفات وورد في المجلد {templates_folder}")
        return

    print(f"📄 تم العثور على {len(word_files)} ملف وورد في المجلد:")
    for file in word_files:
        print(f"  - {os.path.basename(file)}")

    phone_number = clean_phone_number(phone_number)
    password = generate_password(client_code, work_folder_name)

    processed_files = []
    # ثريد الـ ThreadPoolExecutor ده جديد ومفيش فيه تهيئة COM تلقائية، فلازم نعمل
    # CoInitialize هنا وإلا win32com ممكن يرمي "CoInitialize has not been called"
    # أو يتصرف بشكل غير مستقر (اكتشفناها بالاختبار المباشر)
    pythoncom.CoInitialize()
    try:
        threads = []
        # 🔁 أتمتة Word أحيانًا بتفشل بخطأ عابر ("Command failed") لو كذا نسخة Word
        # شغالة في نفس اللحظة. بدل ما نخسر الملف من أول فشل عابر، بنرجّعه لآخر
        # الطابور ونعيد محاولته لحد 3 مرات قبل ما نستسلم فعلًا (شوف نهاية except تحت)
        file_queue = list(word_files)
        file_attempts = {}
        while file_queue:
            specific_file = file_queue.pop(0)
            word = None
            doc = None
            temp_file_path = None
            semaphore_acquired = False
            try:
                template_path = os.path.normpath(specific_file)
                if os.path.basename(template_path).startswith("~$"):
                    continue  # تخطي ملفات Word المؤقتة

                if not os.path.exists(template_path):
                    print(f"⚠️ الملف غير موجود، سيتم تخطيه: {template_path}")
                    continue

                temp_dir = tempfile.gettempdir()
                thread_temp_dir = os.path.join(temp_dir, f"thread_{threading.get_ident()}")
                os.makedirs(thread_temp_dir, exist_ok=True)

                # 🟢 إنشاء نسخة فريدة من الملف لكل ثريد
                # temp_file_path = os.path.join(thread_temp_dir, os.path.basename(template_path))
                # shutil.copy2(template_path, temp_file_path)
                #
                # print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")
                orig_name, ext = os.path.splitext(os.path.basename(template_path))
                unique_suffix = uuid.uuid4().hex  # بيطلع رقم/كود عشوائي وفريد
                temp_file_name = f"{orig_name}__{unique_suffix}{ext}"

                temp_file_path = os.path.join(thread_temp_dir, temp_file_name)
                shutil.copy2(template_path, temp_file_path)

                print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")

                file_name = os.path.basename(template_path).replace(".docx", "")
                #note_name = file_name
                output_pdf = os.path.join(file_folder, f"{order_codes[0]}_{file_code}_{file_name}_{teacher_name}.pdf")

                _word_concurrency_limit.acquire()
                semaphore_acquired = True
                word = win32com.client.DispatchEx("Word.Application")
                word.Visible = False

                print(f"📂 فتح الملف: {temp_file_path}")
                doc = word.Documents.Open(temp_file_path)  # ✅ فتح النسخة المؤقتة بدلاً من الأصل

                teacher_prefix = teacher_name if teacher_name.startswith(("د.", "أ.")) else f"أ. {teacher_name}"

                # تعديل النصوص داخل الأشكال (Shapes)
                for shape in doc.Shapes:
                    if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                        text = shape.TextFrame.TextRange.Text
                        page_number = shape.Anchor.Information(3)
                        text = text.replace("{اسم المعلم}", teacher_prefix)
                        text = text.replace("{اسم المذكرة}", note_name)
                        text = text.replace("{رقم الهاتف}", phone_number)
                        shape.TextFrame.TextRange.Text = text

                        if "{العلامة المائية}" in text:
                            water_mark = str(water_mark).strip() if pd.notna(
                                water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                            # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                            if not water_mark:
                                teacher_name = str(teacher_name).strip()
                                if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                    watermark_text = f"أ. {teacher_name}"
                                else:
                                    watermark_text = teacher_name

                            # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                            shape.TextFrame.TextRange.Text = water_mark
                            print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")


                for section in doc.Sections:
                    header = section.Headers(1)
                    for shape in header.Shapes:
                        if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                            text = shape.TextFrame.TextRange.Text
                            text = text.replace("{اسم المعلم}", teacher_prefix)
                            text = text.replace("{اسم المذكرة}", note_name)
                            text = text.replace("{رقم الهاتف}", phone_number)
                            shape.TextFrame.TextRange.Text = text

                            if "{العلامة المائية}" in text:
                                water_mark = str(water_mark).strip() if pd.notna(
                                    water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                                # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                                if not water_mark:
                                    teacher_name = str(teacher_name).strip()
                                    if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                        water_mark = f"أ. {teacher_name}"
                                    else:
                                        water_mark = teacher_name

                                # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                                shape.TextFrame.TextRange.Text = water_mark
                                print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")

            # تعديل النصوص داخل محتوى المستند
                content_text = doc.Content.Text

                # حفظ المستند كملف PDF
                export_word_to_pdf(doc, output_pdf)
                doc.Close(SaveChanges=0)
                print(f"✅ تم إغلاق الملف : {output_pdf}")
                # نقفل نسخة Word دي هنا جوه القفل (_word_concurrency_limit)، يعني
                # معدش نسخة Word تانية شغالة تتصادم معاها، قبل ما نسيب القفل
                try:
                    word.Quit()
                except Exception:
                    pass
                # مهلة صغيرة قبل ما نسيب القفل: word.Quit() بيرجع للكود فورًا بس
                # عملية WINWORD.exe ممكن تاخد لحظة زيادة تقفل فعليًا على مستوى
                # الويندوز. لو النسخة الجاية بدأت قبل ما دي تقفل خالص، بيحصل تصادم
                time.sleep(0.2)
                _word_concurrency_limit.release()
                semaphore_acquired = False
                # نتحقق من وجود الـ PDF بعد ما Word يقفل فعلًا، مش قبله.
                finalize_pdf_output(output_pdf, add_password=add_password, password=password, protect_as_images=protect_as_images)

                print(f"✅ تم إنشاء الملف بنجاح: {output_pdf}")
                processed_files.append(output_pdf)
                os.remove(temp_file_path)
                print(f"🗑️ تم حذف النسخة المؤقتة: {temp_file_path}")

                #msgbox.showinfo("نجاح", f"تم إنشاء الملف وحفظه بنجاح:\n{output_pdf}")

            except Exception as e:
                recovered_pdf = False
                if 'output_pdf' in locals() and file_exists_with_size(output_pdf):
                    try:
                        print(f"⚠️ حدث خطأ بعد إنشاء PDF على الأغلب، سأحاول إنقاذ الملف الموجود بدل إعادته من الصفر: {output_pdf}")
                        finalize_pdf_output(output_pdf, add_password=add_password, password=password, protect_as_images=protect_as_images)
                        if output_pdf not in processed_files:
                            processed_files.append(output_pdf)
                        recovered_pdf = True
                    except Exception as recovery_error:
                        print(f"⚠️ فشل إنقاذ ملف الـ PDF الموجود: {recovery_error}")

                try:
                    if doc is not None:
                        doc.Close(SaveChanges=0)
                except Exception:
                    pass
                try:
                    if word is not None:
                        word.Quit()
                except Exception:
                    pass
                if word is not None:
                    time.sleep(0.2)
                if semaphore_acquired:
                    _word_concurrency_limit.release()
                    semaphore_acquired = False

                # لازم نمسح النسخة المؤقتة من الملف الفاشل، وإلا هتفضل متراكمة في
                # Temp مع كل محاولة فاشلة وممكن تملي القرص (حصل بالفعل)
                try:
                    if temp_file_path and os.path.exists(temp_file_path):
                        os.remove(temp_file_path)
                except Exception:
                    pass

                if recovered_pdf:
                    print(f"✅ تم الاحتفاظ بملف PDF الموجود رغم الخطأ العارض: {output_pdf}")
                    continue

                attempts_so_far = file_attempts.get(specific_file, 0) + 1
                file_attempts[specific_file] = attempts_so_far
                if attempts_so_far < 6:
                    print(f"⚠️ خطأ أثناء معالجة الملف {template_path} (محاولة {attempts_so_far}/6)، هيتعاد المحاولة: {e}")
                    time.sleep(2)
                    file_queue.append(specific_file)
                else:
                    print(f"⚠️ خطأ أثناء معالجة الملف {template_path} بعد 6 محاولات: {e}")
    finally:
        print("Done")
        pythoncom.CoUninitialize()
    return processed_files

def process_orders_logo(tabs, logo_frame, links_container, frame_links, work_folder_name, add_password=True, progress_callback=None, shutdown_after=False, auto_export_failed=False, failed_orders_callback=None, local_only=False, protect_as_images=True, upload_workers=1, source_excel=None, templates_root=None, run_mode="logo"):
    try:
        # لوحة التقدّم الحقيقية بقت في الواجهة الجديدة (progress_callback)، فالليبل ده
        # بيتعمله بس عشان process_grouped_data_logo لسه محتاجاه كمتغير يقفله في النهاية (finally)
        loading_label_logo = tk.Label(logo_frame, text="جاري معالجة الطلبات...")

        # مسح أي روابط قديمة من الواجهة
        for widget in links_container.winfo_children():
            widget.destroy()

        if not work_folder_name:
            msgbox.showerror("خطأ", "يرجى اختيار فولدر الشغل من القايمة قبل المتابعة!")
            return

        source_excel = source_excel or excel_file_logo
        templates_root = templates_root or selected_folder_logo
        if not source_excel or not os.path.exists(source_excel):
            msgbox.showerror("خطأ", "يرجى اختيار ملف Excel قبل المتابعة!")
            return

        if not templates_root or not os.path.exists(templates_root):
            msgbox.showerror("خطأ", "يرجى اختيار مجلد القوالب قبل المتابعة!")
            return

        # 🟢 تشغيل المعالجة في ثريد منفصل عشان الواجهة تفضل مستجيبة، ولو تاب "الطلبات"
        # شغال في نفس الوقت يقدر يبدأ من غير ما يستنى ده يخلص
        clear_failed_orders(run_mode)
        if failed_orders_callback:
            failed_orders_callback(0)
        run = run_history.create(
            run_mode, work_folder_name, business_root_folder or settings.get_business_root_folder(),
            source_excel, local_only,
        )
        shutil.copy2(source_excel, run["snapshot"])
        _job_started(shutdown_after)
        threading.Thread(
            target=process_grouped_data_logo,
            args=(loading_label_logo, tabs, frame_links, links_container, work_folder_name, add_password, progress_callback, shutdown_after, auto_export_failed, failed_orders_callback, local_only, run["id"], protect_as_images, upload_workers, source_excel, templates_root, run_mode),
            daemon=True
        ).start()

    except Exception as e:
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")

def process_client_logo(client_code, client_orders, business_root_folder, work_folder_name, loading_label_logo, tabs, frame_links, links_container, data, links_list, add_password=True, protect_as_images=True, templates_root=None):
    def process_order(order_code, order_rows):
        order_succeeded = True
        order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in order_rows.iterrows()))
        for _, row in order_rows.iterrows():
            file_code = str(row["كود الملف"]).strip()
            try:
                output_pdfs = modify_logo(
                    client_code=client_code,
                    order_codes=order_codes,
                    file_code=file_code,
                    teacher_name=row["اسم المعلم"],
                    note_name=row["اسم المذكرة"],
                    phone_number=row["رقم الهاتف"],
                    water_mark=row["العلامة المائية"],
                    open_link=row["فتح الملف"],
                    business_root_folder=business_root_folder,
                    work_folder_name=work_folder_name,
                    add_password=add_password,
                    protect_as_images=protect_as_images,
                    templates_root=templates_root,
                )

                if output_pdfs:
                    print(f"✅ تم إنشاء {len(output_pdfs)} ملف PDF للملف {file_code} في الطلب {order_code} بنجاح!")
                else:
                    print(f"⚠️ لم يتم إنشاء أي ملفات PDF للملف {file_code} في الطلب {order_code}.")
                    order_succeeded = False
            except Exception as e:
                print(f"❌ خطأ في معالجة الملف {file_code} في الطلب {order_code}: {e}")
                order_succeeded = False
        return order_succeeded

    grouped_orders = list(client_orders.groupby("كود الطلب", sort=False))
    with concurrent.futures.ThreadPoolExecutor(max_workers=_order_parallelism) as order_executor:
        order_futures = [
            order_executor.submit(process_order, order_code, order_rows.copy())
            for order_code, order_rows in grouped_orders
        ]
        return all(future.result() for future in order_futures)

    # raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
    # share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
    # shareable_link = upload_order_files_logo(client_code, client_folder_name, business_root_folder, share_value)
    # data.loc[client_orders.index, "الرابط"] = shareable_link
    #
    # with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
    #     temp_path = tmp.name
    # data.to_excel(temp_path, index=False)
    # time.sleep(1)
    # shutil.move(temp_path, excel_file)
    # links_list.append(shareable_link)
    # print(f"🔗 رابط مجلد العميل على Google Drive: {shareable_link}")

def process_grouped_data_logo(loading_label_logo, tabs, frame_links, links_container, work_folder_name, add_password=True, progress_callback=None, shutdown_after=False, auto_export_failed=False, failed_orders_callback=None, local_only=False, run_id=None, protect_as_images=True, upload_workers=1, source_excel=None, templates_root=None, pause_mode="logo"):
    try:
        links_list = []
        global business_root_folder
        if business_root_folder is None:
            business_root_folder = settings.get_business_root_folder()

        # 🟢 كل عميل بيترفع على درايف فور ما تخلص معالجته، وفور ما آخر عميل لمعلم معيّن يخلص رفع
        # بيتبعت له رسالة الواتساب على طول (من غير ما نستنى باقي المعلمين/العملاء يخلصوا كمان)
        # القيم دي متراكمة عبر كل الباصات (لو الشيت اتزود فيه صفوف جديدة أثناء الشغل)
        all_links = []
        state_lock = threading.Lock()
        sent_messages_count = [0]
        failed_numbers = []
        teachers_with_failed_clients = set()
        failed_rows = []

        # مفاتيح الصفوف اللي اتعالجت خلاص - عشان لما نعيد قراءة الشيت بعد ما نخلص،
        # نقدر نميّز صف جديد اتضاف فعلاً عن صف قديم فشل (منعيدوش نحاول تاني هنا)
        known_keys = set()
        pass_number = 0
        idle_scans = 0

        while True:
            pass_number += 1
            data = pd.read_excel(source_excel or excel_file_logo)
            data = prepare_delivery_data(data)
            validate_delivery_data(data)

            # لو عمود "الرابط" فاضي في ملف الإكسل، بانداز بيفترضه float64 (NaN)، وبعدين
            # كتابة رابط (نص) فيه بترمي ValueError. نجبره يبقى object من الأول عشان
            # يقبل نصوص، بدل ما نستنى العميل يخلص رفعه ونكتشف المشكلة وقتها
            if "الرابط" not in data.columns:
                data["الرابط"] = None
            data["الرابط"] = data["الرابط"].astype("object")

            key_columns = [column for column in data.columns if column not in {"الرابط", "_row_key"}]
            row_keys = [
                tuple("" if pd.isna(value) else str(value).strip() for value in row)
                for row in data[key_columns].itertuples(index=False, name=None)
            ]
            data["_row_key"] = row_keys
            new_rows = data[~data["_row_key"].isin(known_keys)].drop(columns=["_row_key"])

            if pass_number == 1:
                print("تمت قراءة البيانات بنجاح!")
            elif new_rows.empty:
                idle_scans += 1
                if idle_scans >= 3:
                    print("✅ لم تتم إضافة صفوف لوجو جديدة خلال فترة المراجعة - خلصنا.")
                    break
                print("⏳ ننتظر صفوف لوجو جديدة في الشيت قبل الإنهاء...")
                time.sleep(5)
                continue
            else:
                idle_scans = 0
                print(f"🔁 لقينا {len(new_rows)} صف جديد اتضاف على الشيت بعد ما بدأنا، هنعالجهم كمان")

            known_keys.update(row_keys)
            grouped_data = new_rows.groupby("كود العميل", sort=False)

            # تجهيز مسبق: كام عميل باقي لكل معلم، عشان نعرف امتى نبعت رسالة المعلم (لما يخلصوا كلهم)
            teacher_of_client = {}
            teacher_remaining = {}
            for client_code, client_orders in grouped_data:
                teacher_name = str(client_orders["اسم المعلم"].iloc[0]).strip()
                teacher_of_client[client_code] = teacher_name
                teacher_remaining[teacher_name] = teacher_remaining.get(teacher_name, 0) + 1

            total_clients = len(teacher_of_client)
            completed_clients = [0]
            upload_gate = threading.BoundedSemaphore(max(1, int(upload_workers)))
            if progress_callback:
                try:
                    progress_callback(0, total_clients)
                except Exception as e:
                    print(f"⚠️ خطأ في progress_callback: {e}")

            def send_whatsapp_for_teacher(teacher_name):
                """بتتنده أول ما كل عملاء المعلم ده يخلصوا رفع، وبتبعت له رسالة واحدة فيها كل روابطه"""
                teacher_rows = data[
                    (data['اسم المعلم'].astype(str).str.strip() == teacher_name)
                    & pd.notna(data['الرابط']) & data['الرابط'].astype(str).str.strip().ne('')
                ]
                if teacher_rows.empty:
                    return  # كل عملاء المعلم ده فشل رفعهم، مفيش حاجة نبعتها

                full_number = None
                try:
                    whatsapp_ready_started_at = time.perf_counter()
                    driver = web_driver.ensure_whatsapp_ready()
                    if driver is None:
                        print("⚠️ تعذر تشغيل المتصفح! تأكد من أن msedgedriver.exe موجود.")
                        with state_lock:
                            failed_numbers.append(teacher_name)
                        return
                    log_timing("تجهيز واتساب للمعلم", whatsapp_ready_started_at, teacher_name)
                    message = build_teacher_whatsapp_message(teacher_name, teacher_rows, work_folder_name, add_password)

                    raw_number = teacher_rows.iloc[0]['رقم الواتس']
                    number = str(raw_number).strip().split('.')[0]  # دايمًا String

                    # ✅ تنسيق الرقم
                    if number.startswith("0"):
                        full_number = config.EGYPT_COUNTRY_CODE + number[1:]
                    elif not number.startswith("+"):
                        full_number = config.EGYPT_COUNTRY_CODE + number
                    else:
                        full_number = number

                    if not full_number[1:].isdigit():
                        print(f"❌ الرقم غير صالح: {full_number}")
                        with state_lock:
                            failed_numbers.append(full_number)
                        return

                    print(f"📞 الرقم بعد التعديل: {full_number}")

                    encoded_message = urllib.parse.quote(message)
                    whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"
                    whatsapp_send_started_at = time.perf_counter()
                    driver.get(whatsapp_url)
                    was_unread = web_driver.current_chat_is_unread(driver)
                    print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")

                    # ✅ البحث عن زر الإرسال
                    try:
                        web_driver.send_current_whatsapp_message(driver)
                        if was_unread:
                            web_driver.restore_current_chat_unread(driver)
                        with state_lock:
                            sent_messages_count[0] += 1
                        print(f"✅ تم إرسال الرسالة إلى {full_number}")
                        log_timing("إرسال واتساب", whatsapp_send_started_at, full_number)
                        time.sleep(settings.get_whatsapp_delay_seconds())
                    except TimeoutException:
                        print(f"🚫 الرقم {full_number} غير مسجل على واتساب أو زر الإرسال غير متاح.")
                        with state_lock:
                            failed_numbers.append(full_number)

                except Exception as e:
                    print(f"❌ فشل الإرسال للمعلم {teacher_name}. الخطأ: {str(e)}")
                    with state_lock:
                        failed_numbers.append(full_number or teacher_name)

            def process_client_only(client_code, client_orders):
                wait_if_paused(pause_mode, run_id)
                order_codes = sorted({str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()})
                order_label = "، ".join(order_codes)
                if run_id:
                    run_history.update(run_id, stage=f"Closing logo orders in parallel (max 10): {order_label}")
                    run_history.add_detail(run_id, f"Closing logo batch (parallel max 10) | orders {order_label}")
                client_started_at = time.perf_counter()
                if progress_callback:
                    progress_callback(completed_clients[0], total_clients, f"تقفيل لوجو متوازي حتى 10 طلبات: {order_label}")
                conversion_succeeded = process_client_logo(client_code, client_orders, business_root_folder, work_folder_name, loading_label_logo, tabs, frame_links, links_container, data, links_list, add_password, protect_as_images, templates_root)
                link = None
                if conversion_succeeded and not local_only:
                    # False means Drive was attempted and did not verify; do not run it twice.
                    link = False
                    client_folder_name = "_".join(order_codes)
                    raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
                    share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
                    if run_id:
                        run_history.update(run_id, stage=f"Uploading logo order {client_folder_name}")
                        run_history.add_detail(run_id, f"Drive upload started | logo order {client_folder_name}")
                    if progress_callback:
                        progress_callback(completed_clients[0], total_clients, f"رفع لوجو متوازي على Drive: {client_folder_name}")
                    with upload_gate:
                        link = upload_order_files_logo(client_code, client_folder_name, business_root_folder, work_folder_name, share_value)
                    if run_id and link:
                        run_history.add_detail(run_id, f"Drive verified | logo order {client_folder_name}")
                return client_code, client_orders.copy(), client_started_at, conversion_succeeded, link

            with concurrent.futures.ThreadPoolExecutor(max_workers=_client_parallelism) as executor:
                futures = {
                    executor.submit(process_client_only, client_code, client_orders): (client_code, client_orders.copy())
                    for client_code, client_orders in grouped_data
                }
                for future in concurrent.futures.as_completed(futures):
                    fallback_client_code, fallback_client_orders = futures[future]
                    try:
                        client_code, client_orders, client_started_at, conversion_succeeded, preuploaded_link = future.result()
                    except Exception as e:
                        client_code, client_orders = fallback_client_code, fallback_client_orders
                        client_started_at = time.perf_counter()
                        conversion_succeeded = False
                        preuploaded_link = None
                        print(f"❌ خطأ في تقفيل العميل {client_code}: {e}")

                    raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
                    share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
                    order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))
                    client_folder_name = "_".join(order_codes)

                    shareable_link = preuploaded_link
                    failure_reason = None
                    if conversion_succeeded and local_only:
                        shareable_link = "LOCAL_ONLY"
                        print(f"[RUN] Local-only completed: {client_folder_name}")
                    elif conversion_succeeded and shareable_link is None:
                        wait_if_paused(pause_mode, run_id)
                        if run_id:
                            run_history.update(run_id, stage=f"Uploading logo order {client_folder_name}")
                            run_history.add_detail(run_id, f"Drive upload started | logo order {client_folder_name}")
                        if progress_callback:
                            progress_callback(completed_clients[0], total_clients, f"رفع طلب اللوجو {client_folder_name} على Drive")
                        shareable_link = upload_order_files_logo(
                            client_code, client_folder_name, business_root_folder, work_folder_name, share_value,
                            progress_callback=lambda percentage: progress_callback(
                                completed_clients[0], total_clients,
                                f"رفع طلب اللوجو {client_folder_name} على Drive: {percentage}%",
                            ) if progress_callback else None,
                        )
                        if not shareable_link:
                            failure_reason = "فشل رفع الملفات أو التحقق من اكتمالها على Google Drive"
                        elif run_id:
                            run_history.add_detail(run_id, f"Drive verified | logo order {client_folder_name}")
                    else:
                        print(f"🚫 لن يتم رفع أو إرسال طلب اللوجو {client_folder_name} لأن تحويل ملفاته لم يكتمل.")
                        failure_reason = "فشل تحويل ملف Word أو إنشاء PDF بعد كل المحاولات"

                    teacher_name = teacher_of_client[client_code]
                    fire_teacher_message = False
                    with state_lock:
                        if shareable_link and shareable_link != "LOCAL_ONLY":
                            data.loc[client_orders.index, "الرابط"] = shareable_link
                            all_links.append(shareable_link)
                        elif shareable_link == "LOCAL_ONLY":
                            pass
                        else:
                            teachers_with_failed_clients.add(teacher_name)
                            failed_client_rows = client_orders.copy()
                            failed_client_rows["سبب الفشل"] = failure_reason or "لم يكتمل الطلب"
                            failed_rows.append(failed_client_rows)
                        teacher_remaining[teacher_name] -= 1
                        if teacher_remaining[teacher_name] == 0 and not local_only and teacher_name not in teachers_with_failed_clients:
                            fire_teacher_message = True
                        elif teacher_remaining[teacher_name] == 0:
                            print(f"🚫 لن يتم إرسال رسالة للمعلم {teacher_name} لأن أحد طلبات اللوجو لم يكتمل.")
                        completed_clients[0] += 1
                        done_count = completed_clients[0]

                    if progress_callback:
                        try:
                            progress_callback(done_count, total_clients)
                        except Exception as e:
                            print(f"⚠️ خطأ في progress_callback: {e}")

                    if fire_teacher_message:
                        if run_id:
                            run_history.update(run_id, stage=f"Sending WhatsApp to {teacher_name}")
                            run_history.add_detail(run_id, f"WhatsApp sending | logo orders for {teacher_name}")
                        if progress_callback:
                            progress_callback(done_count, total_clients, f"إرسال واتساب للمعلم {teacher_name}")
                        with web_driver.driver_lock:
                            send_whatsapp_for_teacher(teacher_name)
                        if run_id:
                            run_history.add_detail(run_id, f"WhatsApp confirmed | logo orders for {teacher_name}")
                    log_timing("زمن معالجة العميل", client_started_at, str(client_code))

            # تحديث الملف والواجهة
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                temp_path = tmp.name
            data.drop(columns=["_row_key"], errors="ignore").to_excel(temp_path, index=False)
            shutil.move(temp_path, source_excel or excel_file_logo)
            if run_id:
                shutil.copy2(source_excel or excel_file_logo, run_history.get(run_id)["snapshot"])

        failed_orders_count = save_failed_orders(pause_mode, failed_rows)
        if auto_export_failed and failed_orders_count:
            export_failed_orders(pause_mode)
        if failed_orders_callback:
            ui_after(loading_label_logo, lambda count=failed_orders_count: failed_orders_callback(count))

        sent_messages_count = sent_messages_count[0]
        ui_render_links_summary(links_container, all_links, sent_messages_count, failed_numbers)
        if run_id:
            run_history.update(run_id, status="local_complete" if local_only else "completed", stage="Completed")
        print("✅ تم الانتهاء من معالجة جميع العملاء!")
        tabs.select(frame_links)
        ui_showinfo(loading_label_logo, "نجاح", "تم الانتهاء من رفع الملفات، وتم حفظ الروابط!")
    except Exception as e:
        if run_id:
            run_history.update(run_id, status="failed", stage="Failed", details=str(e))
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")
        ui_showerror(loading_label_logo, "خطأ", f"⚠️ حدث خطأ أثناء معالجة الطلبات:\n{e}")
    finally:
        # نقفل كل نسخ Word المتبقية دفعة واحدة هنا (بعد ما الدفعة كلها خلصت)،
        # مش أثناء المعالجة لكل ملف لوحده - ده كان بيسبب تصادم "Command failed"
        close_word()
        ui_destroy(loading_label_logo)
        _job_finished()


# ==============================================================================
# ⚠️ DEPRECATED — شغل 2024 اتوقف. الكود ده مش متنده من الواجهة (gui.py) تاني.
# ==============================================================================
# logo 24

def modify_logo_24(client_code, order_codes, file_code, teacher_name, phone_number, water_mark, note_name, open_link, business_root_folder, word):
    global selected_folder
    if not selected_folder:
        print("⚠️ لم يتم اختيار مجلد القوالب الأصلية!")
        messagebox.showerror("خطأ", "لم يتم اختيار مجلد القوالب الأصلية")
        #msgbox.showinfo("خطأ", "لم يتم اختيار مجلد القوالب الأصلية")
        return

    file_code = format_code(file_code)
    templates_folder = os.path.join(selected_folder, "_".join(map(str, order_codes)), file_code)
    print("تم فتح ملف كوده", templates_folder)

    base_path = os.path.join(business_root_folder, config.LOGO_ORDERS_SUBPATH_2024)
    client_folder = os.path.join(base_path, "_".join(order_codes))
    file_folder = os.path.join(client_folder, file_code)
    os.makedirs(file_folder, exist_ok=True)

    word_files = glob.glob(os.path.join(templates_folder, "*.docx"))
    if not word_files:
        print(f"⚠️ لا توجد ملفات وورد في المجلد {templates_folder}")
        messagebox.showerror("خطأ", f"⚠️ لا توجد ملفات وورد في المجلد {templates_folder}")
        return

    print(f"📄 تم العثور على {len(word_files)} ملف وورد في المجلد:")
    for file in word_files:
        print(f"  - {os.path.basename(file)}")

    phone_number = clean_phone_number(phone_number)
    password = generate_password_24(client_code)

    processed_files = []
    try:
        threads = []
        for specific_file in word_files:
            try:
                template_path = os.path.normpath(specific_file)
                if os.path.basename(template_path).startswith("~$"):
                    continue  # تخطي ملفات Word المؤقتة

                if not os.path.exists(template_path):
                    print(f"⚠️ الملف غير موجود، سيتم تخطيه: {template_path}")
                    continue

                temp_dir = tempfile.gettempdir()
                thread_temp_dir = os.path.join(temp_dir, f"thread_{threading.get_ident()}")
                os.makedirs(thread_temp_dir, exist_ok=True)

                # 🟢 إنشاء نسخة فريدة من الملف لكل ثريد
                # temp_file_path = os.path.join(thread_temp_dir, os.path.basename(template_path))
                # shutil.copy2(template_path, temp_file_path)
                #
                # print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")
                orig_name, ext = os.path.splitext(os.path.basename(template_path))
                unique_suffix = uuid.uuid4().hex  # بيطلع رقم/كود عشوائي وفريد
                temp_file_name = f"{orig_name}__{unique_suffix}{ext}"

                temp_file_path = os.path.join(thread_temp_dir, temp_file_name)
                shutil.copy2(template_path, temp_file_path)

                print(f"📂 تم إنشاء نسخة مؤقتة من {template_path} -> {temp_file_path}")

                file_name = os.path.basename(template_path).replace(".docx", "")
                #note_name = file_name
                output_pdf = os.path.join(file_folder, f"{order_codes[0]}_{file_code}_{file_name}_{teacher_name}.pdf")

                word = win32com.client.DispatchEx("Word.Application")
                word.Visible = False

                print(f"📂 فتح الملف: {temp_file_path}")
                doc = word.Documents.Open(temp_file_path)  # ✅ فتح النسخة المؤقتة بدلاً من الأصل

                teacher_prefix = teacher_name if teacher_name.startswith(("د.", "أ.")) else f"أ. {teacher_name}"

                # تعديل النصوص داخل الأشكال (Shapes)
                for shape in doc.Shapes:
                    if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                        text = shape.TextFrame.TextRange.Text
                        page_number = shape.Anchor.Information(3)
                        text = text.replace("{اسم المعلم}", teacher_prefix)
                        text = text.replace("{اسم المذكرة}", note_name)
                        text = text.replace("{رقم الهاتف}", phone_number)
                        shape.TextFrame.TextRange.Text = text

                        if "{العلامة المائية}" in text:
                            water_mark = str(water_mark).strip() if pd.notna(
                                water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                            # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                            if not water_mark:
                                teacher_name = str(teacher_name).strip()
                                if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                    watermark_text = f"أ. {teacher_name}"
                                else:
                                    watermark_text = teacher_name

                            # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                            shape.TextFrame.TextRange.Text = water_mark
                            print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")


                for section in doc.Sections:
                    header = section.Headers(1)
                    for shape in header.Shapes:
                        if hasattr(shape, "TextFrame") and shape.TextFrame.HasText:
                            text = shape.TextFrame.TextRange.Text
                            text = text.replace("{اسم المعلم}", teacher_prefix)
                            text = text.replace("{اسم المذكرة}", note_name)
                            text = text.replace("{رقم الهاتف}", phone_number)
                            shape.TextFrame.TextRange.Text = text

                            if "{العلامة المائية}" in text:
                                water_mark = str(water_mark).strip() if pd.notna(
                                    water_mark) else ""  # قراءة قيمة العلامة المائية من الشيت

                                # إذا كانت العلامة المائية فارغة، استخدم اسم المعلم مع إضافة "أ." إذا لم يكن لديه لقب
                                if not water_mark:
                                    teacher_name = str(teacher_name).strip()
                                    if not teacher_name.startswith(("أ.", "د.", "م.", "أستاذ", "دكتور", "مهندس")):
                                        water_mark = f"أ. {teacher_name}"
                                    else:
                                        water_mark = teacher_name

                                # استبدال النص الموجود في الشكل بالعلامة المائية الجديدة
                                shape.TextFrame.TextRange.Text = water_mark
                                print(f"✅ تم استبدال {text} بـ '{water_mark}' في الصفحة {page_number}")

            # تعديل النصوص داخل محتوى المستند
                content_text = doc.Content.Text

                # حفظ المستند كملف PDF
                doc.SaveAs(output_pdf, FileFormat=17)
                doc.Close(SaveChanges=0)
                print(f"✅ تم إغلاق الملف : {output_pdf}")

                # معالجة PDF كصور وإضافة كلمة المرور
                process_pdf_as_images(output_pdf)
                add_password_to_pdf(output_pdf, password)

                print(f"✅ تم إنشاء الملف بنجاح: {output_pdf}")
                processed_files.append(output_pdf)
                os.remove(temp_file_path)
                print(f"🗑️ تم حذف النسخة المؤقتة: {temp_file_path}")

                #msgbox.showinfo("نجاح", f"تم إنشاء الملف وحفظه بنجاح:\n{output_pdf}")

            except Exception as e:
                print(f"⚠️ خطأ أثناء معالجة الملف {template_path}: {e}")
                msgbox.showinfo("خطأ", "خطأ أثناء معالجة الملف ")
                # if 'doc' in locals():  # التأكد من أن doc مفتوح قبل محاولة إغلاقه
                #     doc.Close(SaveChanges=0)
    finally:
        print("Dpne")
        # try:
        #     if 'doc' in locals() and doc is not None:
        #         doc.Close(SaveChanges=0)
        # except:
        #     print("⚠️ لم يتمكن من إغلاق المستند")

        # word.Quit()
    return processed_files

def process_orders_logo_24(tabs, logo_frame, links_container, frame_links):
    try:
        loading_label_24 = tk.Label(logo_frame, text="جاري معالجة الطلبات...", fg="green", font=("Arial", 12, "bold"))
        loading_label_24.pack(pady=10)

        # مسح أي روابط قديمة من الواجهة
        for widget in links_container.winfo_children():
            widget.destroy()

        if not excel_file or not os.path.exists(excel_file):
            msgbox.showerror("خطأ", "يرجى اختيار ملف Excel قبل المتابعة!")
            return

        if not selected_folder or not os.path.exists(selected_folder):
            msgbox.showerror("خطأ", "يرجى اختيار مجلد القوالب قبل المتابعة!")
            return

        # استخدام after لاستدعاء الدالة التي تعالج البيانات
        logo_frame.after(100, process_grouped_data_logo_24, loading_label_24, tabs, frame_links, links_container)

    except Exception as e:
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")

def process_client_logo_24(client_code, client_orders, business_root_folder, loading_label_24, tabs, frame_links, links_container, data, links_list):
    order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))
    client_folder_name = "_".join(order_codes)

    def process_file(row):
        """فتح جلسة Word مستقلة لكل ملف داخل الطلب"""
        try:
            word_app = win32com.client.Dispatch("Word.Application")
            word_app.Visible = False

            file_code = str(row["كود الملف"]).strip()
            order_code = str(row["كود الطلب"]).strip()

            output_pdfs = modify_logo_24(
                client_code=client_code,
                order_codes=order_codes,
                file_code=file_code,
                teacher_name=row["اسم المعلم"],
                note_name=row["اسم المذكرة"],
                phone_number=row["رقم الهاتف"],
                water_mark=row["العلامة المائية"],
                open_link=row["فتح الملف"],
                business_root_folder=business_root_folder,
                word = word_app
            )

            if output_pdfs:
                print(f"✅ تم إنشاء {len(output_pdfs)} ملف PDF للملف {file_code} في الطلب {order_code} بنجاح!")
            else:
                print(f"⚠️ لم يتم إنشاء أي ملفات PDF للملف {file_code} في الطلب {order_code}.")

            # word_app.Quit()
        except Exception as e:
            print(f"❌ خطأ في معالجة الملف {file_code} في الطلب {order_code}: {e}")

    def process_order(order_rows):
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as file_executor:
            file_futures = [file_executor.submit(process_file, row) for _, row in order_rows.iterrows()]
            concurrent.futures.wait(file_futures)

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as order_executor:
        order_futures = [order_executor.submit(process_order, order_rows) for _, order_rows in client_orders.groupby("كود الطلب")]
        concurrent.futures.wait(order_futures)

    # raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
    # share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
    # shareable_link = upload_order_files_logo_24(client_code, client_folder_name, business_root_folder, share_value)
    # data.loc[client_orders.index, "الرابط"] = shareable_link
    #
    # with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
    #     temp_path = tmp.name
    # data.to_excel(temp_path, index=False)
    # time.sleep(1)
    # shutil.move(temp_path, excel_file)
    # links_list.append(shareable_link)
    # print(f"🔗 رابط مجلد العميل على Google Drive: {shareable_link}")

def process_grouped_data_logo_24(loading_label_24, tabs, frame_links, links_container):
    try:
        links_list = []
        data = pd.read_excel(excel_file)
        print("تمت قراءة البيانات بنجاح!")
        data.columns = data.columns.str.strip()

        grouped_data = data.groupby("كود العميل")
        global business_root_folder
        if business_root_folder is None:
            business_root_folder = settings.get_business_root_folder()

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(process_client_logo_24, client_code, client_orders, business_root_folder, loading_label_24, tabs, frame_links, links_container, data, links_list) for client_code, client_orders in grouped_data]
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    print(f"❌ خطأ في أحد الـ Threads: {e}")

        # 🟢 مرحلة الرفع لكل العملاء مع بعض
        all_links = []
        for client_code, client_orders in grouped_data:
            raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
            share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
            order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))
            client_folder_name = "_".join(order_codes)

            shareable_link = upload_order_files_logo_24(client_code, client_folder_name, business_root_folder,
                                                share_value)
            if shareable_link:
                data.loc[client_orders.index, "الرابط"] = shareable_link
                all_links.append(shareable_link)

        # تحديث الملف والواجهة
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
            temp_path = tmp.name
        data.to_excel(temp_path, index=False)
        shutil.move(temp_path, excel_file)

        # إضافة ارسال واتساب لينك
        driver = initialize_driver()
        if driver is None:
            msgbox.showerror("خطأ", "⚠️ تعذر تشغيل المتصفح! تأكد من أن msedgedriver.exe موجود.")
            return

        driver.get(config.WHATSAPP_WEB_URL)
        wait_for_whatsapp_login()
        df = data[pd.notna(data['الرابط']) & data['الرابط'].str.strip().ne('')]

        grouped_data = df.groupby('اسم المعلم')
        sent_messages_count = 0
        failed_numbers = []

        for teacher, data in grouped_data:
            full_number = None
            try:
                client_name = teacher.strip()
                name_parts = client_name.split()

                if name_parts[0] in ['أ.', 'د.', 'م.']:
                    if len(name_parts) > 1 and name_parts[1] in ['عبد', 'أبو']:
                        first_name = f"{name_parts[1]} {name_parts[2]}"
                    else:
                        first_name = name_parts[1]
                elif name_parts[0] in ['عبد', 'أبو'] and len(name_parts) > 1:
                    first_name = f"{name_parts[0]} {name_parts[1]}"
                else:
                    first_name = name_parts[0]

                message = f"السلام عليكم أ. {first_name}\n"
                message += "اتفضل حضرتك الملفات على الرابط ده:\n"

                link_passwords = {}
                for index, row in data.iterrows():
                    link = str(row['الرابط']).strip()
                    client_code = str(row['كود العميل']).strip().zfill(5)
                    # year = year_entry.get().strip()
                    password = f"{config.PASSWORD_PREFIX}{client_code}{config.PASSWORD_YEAR_SUFFIX_2024}"
                    if link not in link_passwords:
                        link_passwords[link] = password

                for link, password in link_passwords.items():
                    message += f"{link}\n"
                    message += f"كلمة السر: {password}\n\n"

                message += "ــــــــــــــــــــــــــــــــــــــ\n"
                message += "ولو حضرتك مش معانا في الجروب الخاص يا ريت تنورنا:\n"
                message += config.WHATSAPP_GROUP_INVITE_LINK

                raw_number = data.iloc[0]['رقم الواتس']
                number = str(raw_number).strip().split('.')[0]  # دايمًا String

                # ✅ تنسيق الرقم
                if number.startswith("0"):
                    full_number = config.EGYPT_COUNTRY_CODE + number[1:]
                elif not number.startswith("+"):
                    full_number = config.EGYPT_COUNTRY_CODE + number
                else:
                    full_number = number

                if not full_number[1:].isdigit():
                    print(f"❌ الرقم غير صالح: {full_number}")
                    failed_numbers.append(full_number)
                    continue

                print(f"📞 الرقم بعد التعديل: {full_number}")

                encoded_message = urllib.parse.quote(message)
                whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"
                driver.get(whatsapp_url)
                print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")
                time.sleep(10)

                # ✅ البحث عن زر الإرسال
                try:
                    send_button = WebDriverWait(driver, 30).until(
                        EC.presence_of_element_located(
                            (By.XPATH,
                             "//button[contains(@aria-label, 'إرسال') or contains(@aria-label, 'Send')]")
                        )
                    )
                    driver.execute_script("arguments[0].click();", send_button)
                    sent_messages_count += 1
                    print(f"✅ تم إرسال الرسالة إلى {full_number}")
                    time.sleep(random.randint(5, 15))  # تأخير عشوائي لتجنب الحظر
                except TimeoutException:
                    print(f"🚫 الرقم {full_number} غير مسجل على واتساب أو زر الإرسال غير متاح.")
                    failed_numbers.append(full_number)
                    continue

            except Exception as e:
                print(f"❌ فشل الإرسال للرقم: {full_number}. الخطأ: {str(e)}")

        summary_text = f"📢 **ملخص الإرسال** 📢\n✅ تم إرسال {sent_messages_count} رسالة بنجاح.\n"
        if failed_numbers:
            summary_text += f"❌ لم يتم إرسال الرسائل إلى {len(failed_numbers)} رقم:\n"
            summary_text += "\n".join([f"   - {num}" for num in failed_numbers])
        else:
            summary_text += "🎉 تم إرسال جميع الرسائل بنجاح! 🚀"

        # 🟢 عرض ملخص الإرسال في نفس التبويب
        summary_label = tk.Label(
            links_container,
            text=summary_text,
            font=("Arial", 11),
            justify="left",
            fg="black"
        )
        summary_label.pack(anchor="w", padx=5, pady=10)

        for link in links_list:
            link_label = tk.Label(
                links_container, text=link, fg="blue", cursor="hand2", font=("Arial", 10, "underline")
            )
            link_label.pack(anchor="w", padx=5, pady=2)
            link_label.bind("<Button-1>", open_link)

        #root.after(0, update_gui)

        print("✅ تم الانتهاء من معالجة جميع العملاء!")
        # close_word()
        tabs.select(frame_links)
        messagebox.showinfo("نجاح", "تم الانتهاء من رفع الملفات، وتم حفظ الروابط!")
    except Exception as e:
        print(f"⚠️ خطأ أثناء معالجة الطلبات: {e}")
        messagebox.showerror("خطأ", f"⚠️ حدث خطأ أثناء معالجة الطلبات:\n{e}")
    finally:
        # close_word()
        loading_label_24.destroy()


# uplode only

def drive_reupload(work_folder_name):
    if not work_folder_name:
        msgbox.showerror("خطأ", "يرجى اختيار فولدر الشغل من القايمة قبل المتابعة!")
        return

    if not excel_file or not os.path.exists(excel_file):
        msgbox.showerror("خطأ", "يرجى اختيار ملف Excel من تاب الطلبات قبل استخدام إعادة الرفع!")
        return

    data = pd.read_excel(excel_file)
    print("تمت قراءة البيانات بنجاح!")
    data.columns = data.columns.str.strip()  # إزالة الفراغات من أسماء الأعمدة

    # تصفية الصفوف التي ليس لها رابط (يعني الرابط فارغ)
    rows_without_link = data[data['الرابط'].isna()]

    # إجراء groupby على "كود العميل"
    grouped_by_client = rows_without_link.groupby("كود العميل")
    global business_root_folder
    if business_root_folder is None:
        business_root_folder = settings.get_business_root_folder()

    # المرور على كل مجموعة (كود العميل)
    for client_code, client_orders in grouped_by_client:
        try:
            # الحصول على أكواد الطلبات وترتيبها ثم تحويلها إلى قائمة
            order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))

            # إنشاء اسم المجلد بناءً على أكواد الطلبات
            client_folder_name = "_".join(order_codes)
            print(f"يتم رفع {client_folder_name}")

            # رفع الملفات والدوال الأخرى
            data["الرابط"] = data["الرابط"].astype("object")

            raw_value = client_orders.get("فتح الملف", ["لا"]).iloc[0]
            share_value = str(raw_value).strip() if pd.notna(raw_value) else "لا"
            shareable_link = upload_order_files(client_code, client_folder_name, business_root_folder, work_folder_name, share_value)

            # تحديث الرابط في البيانات
            data.loc[client_orders.index, "الرابط"] = shareable_link

            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                temp_path = tmp.name
            data.to_excel(temp_path, index=False)
            time.sleep(1)
            shutil.move(temp_path, excel_file)
            print(f"تم رفع بنجاح {client_folder_name}")

        except Exception as e:
            # في حال حدوث مشكلة أثناء رفع الفولدر
            print(f"❌ خطأ أثناء رفع {client_folder_name}: {e}")

    # بعد الانتهاء من معالجة جميع العملاء
    print("✅ تم الانتهاء من رفع جميع الفولدرات بنجاح!")

    # إظهار رسالة للمستخدم بعد الانتهاء من رفع كل شيء
    messagebox.showinfo("نجاح", "تم الانتهاء من رفع جميع الملفات بنجاح!")

    # إرجاع البيانات المحدثة (اختياري)
    return data


# ⚠️ DEPRECATED — شغل 2024 اتوقف، الدالة دي مش بتتنده من الواجهة تاني
def drive_24():
    data = pd.read_excel(excel_file)
    print("تمت قراءة البيانات بنجاح!")
    data.columns = data.columns.str.strip()  # إزالة الفراغات من أسماء الأعمدة

    # تصفية الصفوف التي ليس لها رابط (يعني الرابط فارغ)
    rows_without_link = data[data['الرابط'].isna()]

    # إجراء groupby على "كود العميل"
    grouped_by_client = rows_without_link.groupby("كود العميل")
    global business_root_folder
    if business_root_folder is None:
        business_root_folder = settings.get_business_root_folder()

    # المرور على كل مجموعة (كود العميل)
    for client_code, client_orders in grouped_by_client:
        try:
            # الحصول على أكواد الطلبات وترتيبها ثم تحويلها إلى قائمة
            order_codes = sorted(set(str(row["كود الطلب"]).strip() for _, row in client_orders.iterrows()))

            # إنشاء اسم المجلد بناءً على أكواد الطلبات
            client_folder_name = "_".join(order_codes)
            print(f"يتم رفع {client_folder_name}")

            # رفع الملفات والدوال الأخرى
            data["الرابط"] = data["الرابط"].astype("object")
            shareable_link = upload_order_files_24(client_code, client_folder_name, business_root_folder)
            # تحديث الرابط في البيانات
            data.loc[client_orders.index, "الرابط"] = shareable_link
            with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
                temp_path = tmp.name
            data.to_excel(temp_path, index=False)
            time.sleep(1)
            shutil.move(temp_path, excel_file)
            print(f"تم رفع بنجاح {client_folder_name}")

        except Exception as e:
            # في حال حدوث مشكلة أثناء رفع الفولدر
            print(f"❌ خطأ أثناء رفع {client_folder_name}: {e}")

    # بعد الانتهاء من معالجة جميع العملاء
    print("✅ تم الانتهاء من رفع جميع الفولدرات بنجاح!")

                    # إظهار رسالة للمستخدم بعد الانتهاء من رفع كل شيء
    messagebox.showinfo("نجاح", "تم الانتهاء من رفع جميع الملفات بنجاح!")

    return data

