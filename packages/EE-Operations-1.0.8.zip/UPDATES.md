# Publishing Updates

1. Change `APP_VERSION` in `version.py`.
2. Create a ZIP containing the app files only. Never include `venv`, `token.json`, `user_settings.json`, `.run_history`, or `client_secret_*.json`.
3. Copy the ZIP and its SHA-256 into `EE-Operations-Updates`: place the ZIP under `packages/` and update `manifest.json`.
4. Push both files to the public update repository.

Users choose **Check for updates** from Settings. The app verifies the SHA-256 before replacing code, preserves their local authentication and settings, installs any new dependencies, and restarts.
