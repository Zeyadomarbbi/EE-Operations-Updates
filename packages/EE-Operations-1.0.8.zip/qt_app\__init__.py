"""PySide6 presentation layer for EE Operations."""
