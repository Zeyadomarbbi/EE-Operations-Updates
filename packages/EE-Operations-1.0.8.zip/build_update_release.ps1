param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot "release")
)

$ErrorActionPreference = "Stop"
$versionFile = Join-Path $PSScriptRoot "version.py"
$versionMatch = Select-String -Path $versionFile -Pattern 'APP_VERSION\s*=\s*"([^"]+)"'
if (-not $versionMatch) { throw "Could not read APP_VERSION from version.py." }
$version = $versionMatch.Matches[0].Groups[1].Value
$appRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
if (-not $OutputDirectory.StartsWith($appRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw "OutputDirectory must remain inside the application folder."
}
$packageName = "EE-Operations-$version.zip"
$staging = Join-Path $OutputDirectory "staging"
$package = Join-Path $OutputDirectory $packageName

Remove-Item -LiteralPath $OutputDirectory -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $staging -Force | Out-Null

# A public update package contains code only; each user's identity stays local.
$excluded = @(".git", ".idea", "venv", "__pycache__", ".run_history", ".updates", "release", "token.json", "user_settings.json", ".drive_upload_sessions.json")
Get-ChildItem -LiteralPath $PSScriptRoot -Force | Where-Object {
    $_.Name -notin $excluded -and
    $_.Name -notlike "client_secret_*.json" -and
    $_.Name -notlike "*.log"
} | Copy-Item -Destination $staging -Recurse -Force

Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $package -Force
$sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $package).Hash.ToLower()
$releaseUrl = "https://api.github.com/repos/Zeyadomarbbi/EE-Operations-Updates/contents/packages/${packageName}?ref=main"
$manifest = [ordered]@{
    version = $version
    download_url = $releaseUrl
    sha256 = $sha256
    notes = "EE Operations update $version"
} | ConvertTo-Json
[System.IO.File]::WriteAllText(
    (Join-Path $OutputDirectory "manifest.json"),
    $manifest,
    [System.Text.UTF8Encoding]::new($false)
)

Write-Output "Package: $package"
Write-Output "SHA-256: $sha256"
Write-Output "Copy the ZIP to EE-Operations-Updates\packages, then copy release\manifest.json and push both files."
