"""Application entry point for the PySide6 presentation layer."""

import os
import sys


def _configure_stdio():
    try:
        if sys.stdout is None:
            sys.stdout = open(os.devnull, "w", encoding="utf-8")
        if sys.stderr is None:
            sys.stderr = open(os.devnull, "w", encoding="utf-8")
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
    except OSError:
        pass


def main():
    _configure_stdio()
    # PySide6 on Windows may look for a bundled fonts directory that is no longer shipped.
    # Windows Fonts is the correct system source and avoids the harmless startup warning.
    os.environ.setdefault("QT_QPA_FONTDIR", os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"))
    from ui import debug_log
    debug_log.install()
    from PySide6.QtWidgets import QApplication
    import settings
    from qt_app.controller import BackendController
    from qt_app.tokens import stylesheet
    from qt_app.window import MainWindow

    app = QApplication(sys.argv)
    app.setStyleSheet(stylesheet(settings.get_theme_preference()))
    controller = BackendController()
    window = MainWindow(controller)
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
