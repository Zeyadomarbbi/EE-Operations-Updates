@echo off
cd /d "%~dp0"
"venv\Scripts\python.exe" main.py >> app_log.txt 2>&1
