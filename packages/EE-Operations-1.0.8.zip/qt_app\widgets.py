"""Reusable presentation widgets used by the PySide6 shell."""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QProgressBar,
    QVBoxLayout,
    QWidget,
)


class Card(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(22, 20, 22, 20)
        self.layout.setSpacing(12)


class PageHeader(QWidget):
    def __init__(self, title, subtitle, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 6)
        layout.setSpacing(4)
        heading = QLabel(title)
        heading.setObjectName("pageTitle")
        description = QLabel(subtitle)
        description.setObjectName("pageSubtitle")
        description.setWordWrap(True)
        layout.addWidget(heading)
        layout.addWidget(description)


class FilePicker(QWidget):
    changed = Signal(str)

    def __init__(self, label, button_text="اختيار ملف", parent=None):
        super().__init__(parent)
        self._path = ""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        caption = QLabel(label)
        caption.setObjectName("sectionTitle")
        layout.addWidget(caption)
        row = QHBoxLayout()
        self.value = QLabel("لم يتم الاختيار بعد")
        self.value.setObjectName("muted")
        self.value.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.value.setWordWrap(True)
        self.button = QPushButton(button_text)
        row.addWidget(self.value, 1)
        row.addWidget(self.button)
        layout.addLayout(row)

    @property
    def path(self):
        return self._path

    def set_path(self, path):
        self._path = path or ""
        self.value.setText(self._path or "لم يتم الاختيار بعد")
        self.value.setObjectName("muted" if not self._path else "")
        self.changed.emit(self._path)


class ToggleRow(QWidget):
    def __init__(self, title, helper="", checked=False, parent=None):
        super().__init__(parent)
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 4, 0, 4)
        text = QVBoxLayout()
        name = QLabel(title)
        name.setObjectName("sectionTitle")
        text.addWidget(name)
        if helper:
            note = QLabel(helper)
            note.setObjectName("muted")
            note.setWordWrap(True)
            text.addWidget(note)
        self.toggle = QCheckBox()
        self.toggle.setChecked(checked)
        row.addLayout(text, 1)
        row.addWidget(self.toggle)


class ExecutionPanel(Card):
    def __init__(self, title="حالة التشغيل", parent=None):
        super().__init__(parent)
        heading = QLabel(title)
        heading.setObjectName("sectionTitle")
        self.state = QLabel("جاهز")
        self.state.setObjectName("muted")
        self.stage = QLabel("اختر الملفات وإعدادات التشغيل ثم ابدأ.")
        self.stage.setObjectName("muted")
        self.stage.setWordWrap(True)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.count = QLabel("0 / 0")
        self.count.setObjectName("muted")
        self.layout.addWidget(heading)
        self.layout.addWidget(self.state)
        self.layout.addWidget(self.stage)
        self.layout.addWidget(self.progress)
        self.layout.addWidget(self.count)

    def set_status(self, text, kind="muted"):
        self.state.setText(text)
        self.state.setStyleSheet({
            "success": "color: #2D8060; font-weight: 700;",
            "danger": "color: #C4524C; font-weight: 700;",
            "warning": "color: #B5792A; font-weight: 700;",
        }.get(kind, "color: #607077; font-weight: 600;"))

    def set_progress(self, done, total, stage):
        total = max(int(total or 0), 0)
        done = max(int(done or 0), 0)
        self.progress.setValue(round(done * 100 / total) if total else 0)
        self.count.setText(f"{done} / {total}")
        self.stage.setText(stage or "جارٍ العمل...")


class EmptyState(QWidget):
    def __init__(self, title, detail, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)
        layout.setSpacing(8)
        label = QLabel(title)
        label.setObjectName("sectionTitle")
        label.setAlignment(Qt.AlignCenter)
        text = QLabel(detail)
        text.setObjectName("muted")
        text.setWordWrap(True)
        text.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)
        layout.addWidget(text)
