import os
import threading
import queue
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import ttkbootstrap as tb

import config
import settings
import drive
import web_driver
import upload_files
import run_history
import retry_delivery_only
from upload_files import upload_excel
from upload_files import upload_folder
from upload_files import process_orders
from upload_files import process_orders_logo
from upload_files import drive_reupload

from msgs import upload_exel2
from msgs import send_custom_whatsapp_messages

from ui import theme as th
from ui import icons
from ui import debug_log
from ui.components import Card, page_header, section_title, FilePickerRow, ProgressPanel
from ui.sidebar import Sidebar

DEBUG_LOG_PASSWORD = "1234567890"


# ==========================================================================
# ويزارد إعداد أول استخدام: يظهر مرة واحدة بس على كل جهاز، وبيجهز 3 حاجات
# قبل ما الواجهة الرئيسية تفتح: المجلد الرئيسي + Google Drive + واتساب ويب.
# ==========================================================================
def run_first_time_setup(root):
    if settings.is_setup_completed():
        return

    wizard = tk.Toplevel(root)
    wizard.title("إعداد أول استخدام")
    wizard.geometry("520x380")
    wizard.resizable(False, False)
    wizard.transient(root)
    wizard.lift()
    wizard.focus_force()
    wizard.attributes("-topmost", True)
    wizard.after(300, lambda: wizard.attributes("-topmost", False))
    wizard.grab_set()

    ttk.Label(wizard, text="⚙️ إعداد البرنامج لأول مرة", font=("Segoe UI", 15, "bold")).pack(pady=(24, 4))
    ttk.Label(
        wizard,
        text="هنجهزلك 3 حاجات مرة واحدة بس، ومش هتتسأل فيهم تاني على الجهاز ده.",
        font=("Segoe UI", 10), foreground="#999999"
    ).pack(pady=(0, 20))

    steps_text = [
        "📁  المجلد الرئيسي لشغل الشركة",
        "🔑  تسجيل الدخول لـ Google Drive",
        "💬  تسجيل الدخول لواتساب ويب",
    ]
    status_vars = [tk.StringVar(value="⏳ في الانتظار") for _ in steps_text]
    for text, var in zip(steps_text, status_vars):
        row = ttk.Frame(wizard)
        row.pack(fill="x", padx=30, pady=10)
        ttk.Label(row, text=text, font=("Segoe UI", 11)).pack(side="left")
        ttk.Label(row, textvariable=var, foreground="#999999").pack(side="right")

    hint_var = tk.StringVar(value="")
    ttk.Label(
        wizard, textvariable=hint_var, font=("Segoe UI", 9),
        foreground="#e0a020", wraplength=460, justify="center"
    ).pack(pady=(10, 0))

    q = queue.Queue()
    retry_btn = tb.Button(wizard, text="🔁 إعادة المحاولة", bootstyle="warning")

    def worker():
        try:
            q.put(("status", 1, "⏳ جاري تسجيل الدخول..."))
            drive.authenticate_google_drive()
            q.put(("status", 1, "✅ تم"))

            q.put(("status", 2, "⏳ افتح واتساب وامسح كود QR لو ظهرلك"))
            wa_driver = web_driver.initialize_driver()
            wa_driver.get(config.WHATSAPP_WEB_URL)
            web_driver.wait_for_whatsapp_login()
            q.put(("status", 2, "✅ تم"))

            q.put(("done", None, None))
        except Exception as e:
            q.put(("error", None, str(e)))

    def start_worker():
        hint_var.set("")
        retry_btn.pack_forget()
        status_vars[1].set("⏳ في الانتظار")
        status_vars[2].set("⏳ في الانتظار")
        threading.Thread(target=worker, daemon=True).start()

    retry_btn.config(command=start_worker)

    def poll():
        try:
            while True:
                kind, i, text = q.get_nowait()
                if kind == "status":
                    status_vars[i].set(text)
                elif kind == "done":
                    settings.mark_setup_completed()
                    wizard.destroy()
                    return
                elif kind == "error":
                    hint_var.set(f"⚠️ حصل خطأ: {text}")
                    retry_btn.pack(pady=(10, 20))
                    return
        except queue.Empty:
            pass
        wizard.after(200, poll)

    # الخطوة الأولى (اختيار المجلد) لازم تتنفذ على نفس الـ thread الرئيسي
    # لأنها بتفتح نوافذ Tkinter مباشرة (filedialog/messagebox)
    wizard.update()
    settings.get_business_root_folder()
    status_vars[0].set("✅ تم")

    start_worker()
    wizard.after(200, poll)

    root.wait_window(wizard)


class _PageRouter:
    """
    بديل خفيف لـ ttk.Notebook بواجهة select(frame) بس، عشان upload_files.py يقدر يستدعي
    tabs.select(frame_links) زي ما كان بيعمل بالظبط من غير ما يعرف إننا بدّلنا نظام
    التنقل بالكامل لـ Sidebar. آمن يتنده من أي ثريد خلفي (بيمرّر التنفيذ الفعلي
    لثريد الواجهة الرئيسي عبر after، عشان الودجت متتلمسش من غير الـ main thread).
    """

    def __init__(self, root):
        self._root = root
        self._frame_to_key = {}
        self._show_page = None

    def register(self, key, frame):
        self._frame_to_key[frame] = key

    def bind_show(self, show_page_fn):
        self._show_page = show_page_fn

    def select(self, frame):
        key = self._frame_to_key.get(frame)
        if key and self._show_page:
            self._root.after(0, lambda: self._show_page(key))


def _run_in_background(target, *args):
    threading.Thread(target=target, args=args, daemon=True).start()


def create_gui():
    theme_key = settings.get_theme_preference()
    root = tb.Window(themename=th.THEME_NAMES.get(theme_key, th.THEME_NAMES["dark"]))
    root.title("EE Operations")
    root.geometry("1200x760")
    root.minsize(980, 650)

    style = tb.Style()
    th.apply_base_style(style)

    run_first_time_setup(root)

    # فولدر الشغل الرئيسي — قيمة قابلة للتغيير من صفحة الإعدادات، فمخزّنة في حاوية
    # قابلة للتعديل بدل متغيّر عادي (عشان أي دالة متداخلة تقدر تحدّثها)
    business_root_folder_holder = {"value": settings.get_business_root_folder()}
    theme_state = {"value": theme_key}

    router = _PageRouter(root)

    # ======================================================================
    # الهيكل العام: Sidebar (لوجو + تنقل) + منطقة محتوى فيها شريط فولدر الشغل
    # الثابت فوق، وتحته الصفحة الحالية.
    # ======================================================================
    shell = ttk.Frame(root, style="App.TFrame")
    shell.pack(fill="both", expand=True)

    # content_root بيتبني هنا لكن من غير ما يتحط (pack) في shell دلوقتي، عشان
    # Sidebar لازم يتحط قبله (على الشمال) — وSidebar نفسه لازم يتبني بعد ما كل
    # الصفحات تتبني (لأنه بيعرض أول صفحة تلقائيًا جوه الـ constructor بتاعه.
    content_root = ttk.Frame(shell, style="App.TFrame")

    # -------------------- شريط فولدر الشغل (سياق مشترك فوق كل الصفحات) --------------------
    top_bar = ttk.Frame(content_root, style="Context.TFrame", padding=(th.SPACE_XL, th.SPACE_MD))
    top_bar.pack(fill="x")

    ttk.Label(top_bar, text="فولدر الشغل", style="ContextTitle.TLabel").pack(side="left", padx=(0, th.SPACE_SM))

    work_folder_var = tk.StringVar()
    work_folder_combo = tb.Combobox(top_bar, textvariable=work_folder_var, state="readonly", width=36, bootstyle="primary")
    work_folder_combo.pack(side="left")

    def refresh_work_folders(event=None):
        folders = settings.list_work_folders(business_root_folder_holder["value"])
        work_folder_combo["values"] = folders
        if folders and work_folder_var.get() not in folders:
            work_folder_var.set(folders[-1])  # أحدث فولدر كافتراضي

    refresh_work_folders()
    work_folder_combo.bind("<Button-1>", refresh_work_folders)

    active_operations_var = tk.StringVar(value="لا توجد عمليات نشطة")
    ttk.Label(top_bar, textvariable=active_operations_var, style="Small.TLabel").pack(side="right")

    def refresh_active_operations():
        runs = run_history.list_runs()
        active = [item for item in runs if item.get("status") in {"running", "retrying", "paused"}]
        if not active:
            active_operations_var.set("لا توجد عمليات نشطة")
        elif any(item.get("status") == "paused" for item in active):
            active_operations_var.set(f"{len(active)} عملية نشطة أو متوقفة مؤقتاً")
        else:
            active_operations_var.set(f"{len(active)} عملية قيد التشغيل")
        root.after(1000, refresh_active_operations)

    refresh_active_operations()

    ttk.Label(
        top_bar, text="بيتحدّث تلقائيًا — أي فولدر جديد تضيفه هيظهر لوحده", style="Small.TLabel",
    ).pack(side="left", padx=(th.SPACE_BASE, 0))

    ttk.Separator(content_root).pack(fill="x")

    # -------------------- Canvas + Scrollbar عشان لو الشاشة اتصغّرت (أو المحتوى
    # طال) نقدر ننزل ونطلع بالماوس أو بالسكرول بار، بدل ما جزء من المحتوى يضيع
    # برا حدود النافذة من غير ما نقدر نوصله --------------------
    scroll_container = ttk.Frame(content_root)
    scroll_container.pack(fill="both", expand=True)

    pages_canvas = tk.Canvas(scroll_container, highlightthickness=0)
    pages_scrollbar = ttk.Scrollbar(scroll_container, orient="vertical", command=pages_canvas.yview)
    pages_canvas.configure(yscrollcommand=pages_scrollbar.set)
    pages_canvas.pack(side="left", fill="both", expand=True)
    pages_scrollbar.pack(side="right", fill="y")

    pages_root = ttk.Frame(pages_canvas, padding=th.SPACE_XL)
    pages_root_window = pages_canvas.create_window((0, 0), window=pages_root, anchor="nw")

    def _on_pages_root_configure(event=None):
        pages_canvas.configure(scrollregion=pages_canvas.bbox("all"))
    pages_root.bind("<Configure>", _on_pages_root_configure)

    def _on_pages_canvas_configure(event):
        # نخلي عرض المحتوى الداخلي يتساوى مع عرض الـ canvas نفسه، وإلا المحتوى
        # ممكن يتقص أو يفضل بعرض ثابت غلط لما النافذة تتكبر/تتصغر
        pages_canvas.itemconfigure(pages_root_window, width=event.width)
    pages_canvas.bind("<Configure>", _on_pages_canvas_configure)

    def _on_mousewheel(event):
        pages_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _bind_mousewheel(event=None):
        pages_canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def _unbind_mousewheel(event=None):
        pages_canvas.unbind_all("<MouseWheel>")

    # نربط عجلة الماوس بس لما المؤشر يبقى فوق منطقة المحتوى، عشان منأثرش على
    # سكرول بار تاني موجود في مكان تاني من الواجهة (زي تاب السجل التقني)
    pages_canvas.bind("<Enter>", _bind_mousewheel)
    pages_canvas.bind("<Leave>", _unbind_mousewheel)

    pages = {}

    def show_page(key):
        for frame in pages.values():
            frame.pack_forget()
        pages[key].pack(fill="both", expand=True)
        sidebar.activate(key)

    # ======================================================================
    # حالة اختيار الملف/المجلد — منفصلة تمامًا بين "الطلبات" و"الشعار" عشان
    # يتشغلوا مع بعض من غير ما يتعارضوا (كل تاب بياخد ملفه ومجلده الخاص بيه)
    # ======================================================================
    def pick_excel_file(mode, row):
        upload_excel(mode)
        row.set_path(upload_files.get_excel_file(mode))

    def pick_templates_folder(mode, row):
        upload_folder(mode)
        row.set_path(upload_files.get_selected_folder(mode))

    def make_progress_callback(panel, state_callback=None):
        """بيرجع دالة (done, total) آمنة تتنده من أي ثريد، وبتحدّث اللوحة عبر after."""
        def cb(done, total, stage_text=""):
            def _update():
                if not panel.winfo_exists():
                    return
                if done == 0:
                    panel.start("جاري تنفيذ الطلبات...", total=total)
                    if state_callback:
                        state_callback("running")
                else:
                    panel.update_progress(done, total, stage_text)
                if stage_text and done == 0:
                    panel.set_stage(stage_text)
                if total and done >= total:
                    panel.finish(f"✓ تم الانتهاء من معالجة {total} عميل")
                    if state_callback:
                        state_callback("completed")
            root.after(0, _update)
        return cb

    # ======================================================================
    # صفحة: الطلبات
    # ======================================================================
    frame_upload = ttk.Frame(pages_root)
    pages["orders"] = frame_upload

    page_header(
        frame_upload, "الطلبات",
        "اختر ملف البيانات ومجلد القوالب، واختر خيارات التنفيذ، وابدأ.",
    ).pack(anchor="w", fill="x")

    files_card = Card(frame_upload)
    files_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        files_card.body, "ملفات الطلب",
        "الأعمدة المطلوبة في ملف الإكسل: كود العميل، كود الطلب، كود الملف، اسم المعلم، "
        "اسم المذكرة، رقم الهاتف، رقم الواتس، الشعار، العلامة المائية، وفتح الملف (اختياري — نعم/لا). "
        "البرنامج بيضيف عمود 'الرابط' تلقائيًا بعد الرفع.",
    ).pack(anchor="w", fill="x")

    excel_row = FilePickerRow(files_card.body, "ملف البيانات (Excel)", "اختر ملف Excel")
    excel_row.pick_button.configure(command=lambda: pick_excel_file("normal", excel_row))
    excel_row.pack(fill="x", pady=(th.SPACE_MD, 0))
    excel_row.set_path(upload_files.get_excel_file("normal"))

    folder_row = FilePickerRow(files_card.body, "مجلد القوالب", "اختر مجلد القوالب")
    folder_row.pick_button.configure(command=lambda: pick_templates_folder("normal", folder_row))
    folder_row.pack(fill="x", pady=(th.SPACE_MD, 0))
    folder_row.set_path(upload_files.get_selected_folder("normal"))

    options_card = Card(frame_upload)
    options_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(options_card.body, "خيارات التنفيذ").pack(anchor="w")

    add_password_var = tk.BooleanVar(value=True)
    tb.Checkbutton(
        options_card.body, text="تفعيل حماية الملفات بباسورد", variable=add_password_var, bootstyle="round-toggle"
    ).pack(anchor="w", pady=(th.SPACE_MD, 4))

    shutdown_var = tk.BooleanVar(value=False)
    tb.Checkbutton(
        options_card.body, text="إغلاق الجهاز تلقائيًا بعد ما ينتهي التنفيذ", variable=shutdown_var, bootstyle="round-toggle"
    ).pack(anchor="w", pady=4)

    auto_export_failed_var = tk.BooleanVar(value=False)
    tb.Checkbutton(
        options_card.body, text="تنزيل الطلبات غير المكتملة تلقائيًا على الديسكتوب", variable=auto_export_failed_var, bootstyle="round-toggle"
    ).pack(anchor="w", pady=4)

    local_only_var = tk.BooleanVar(value=False)
    tb.Checkbutton(
        options_card.body, text="إنهاء الطلبات على الجهاز فقط (بدون رفع أو واتساب)",
        variable=local_only_var, bootstyle="round-toggle"
    ).pack(anchor="w", pady=4)

    orders_progress = ProgressPanel(frame_upload)
    orders_progress.pack(fill="x", pady=(th.SPACE_LG, 0))

    orders_actions = ttk.Frame(frame_upload)
    orders_actions.pack(fill="x", pady=(th.SPACE_LG, 0))

    def update_normal_failed_orders_button(count):
        if count:
            normal_failed_orders_button.configure(
                text=f"تنزيل الطلبات غير المكتملة ({count} صف)", state="normal"
            )
        else:
            normal_failed_orders_button.configure(text="كل الطلبات اكتملت بنجاح", state="disabled")

    def download_normal_failed_orders():
        def worker():
            file_path = upload_files.export_failed_orders("normal")
            if file_path:
                root.after(0, lambda: messagebox.showinfo("تم", f"تم حفظ الشيت على الديسكتوب:\n{file_path}"))
        threading.Thread(target=worker, daemon=True).start()

    def set_normal_controls(state):
        if state == "running":
            normal_start_button.configure(state="disabled")
            normal_pause_button.configure(state="normal")
            normal_resume_button.configure(state="disabled")
        elif state == "paused":
            normal_pause_button.configure(state="disabled")
            normal_resume_button.configure(state="normal")
        else:
            normal_start_button.configure(state="normal")
            normal_pause_button.configure(state="disabled")
            normal_resume_button.configure(state="disabled")

    def start_normal_orders():
        process_orders(
            router, frame_upload, links_container, frame_links, work_folder_var.get(),
            add_password_var.get(), shutdown_var.get(), make_progress_callback(orders_progress, set_normal_controls),
            auto_export_failed_var.get(), update_normal_failed_orders_button, local_only_var.get(),
        )

    normal_start_button = tb.Button(
        orders_actions, text="بدء التنفيذ", bootstyle="primary", command=start_normal_orders,
    )
    normal_start_button.pack(side="left", padx=(0, th.SPACE_SM), ipadx=14, ipady=6)

    normal_pause_button = tb.Button(
        orders_actions, text="إيقاف مؤقت", bootstyle="warning-outline",
        command=lambda: (upload_files.request_pause("normal"), set_normal_controls("paused"))
    )
    normal_pause_button.pack(side="left", padx=(0, th.SPACE_SM), ipadx=10, ipady=6)
    normal_resume_button = tb.Button(
        orders_actions, text="استكمال", bootstyle="success-outline",
        command=lambda: (upload_files.resume_run("normal"), set_normal_controls("running"))
    )
    normal_resume_button.pack(side="left", padx=(0, th.SPACE_SM), ipadx=10, ipady=6)
    set_normal_controls("ready")

    tb.Button(
        orders_actions, text="إعادة رفع", bootstyle="secondary-outline",
        command=lambda: _run_in_background(drive_reupload, work_folder_var.get())
    ).pack(side="left", ipadx=10, ipady=6)

    normal_failed_orders_button = tb.Button(
        orders_actions, text="كل الطلبات اكتملت بنجاح", bootstyle="success-outline", state="disabled",
        command=download_normal_failed_orders,
    )
    normal_failed_orders_button.pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)

    # ======================================================================
    # صفحة: الشعار
    # ======================================================================
    logo_frame = ttk.Frame(pages_root)
    pages["logo"] = logo_frame

    page_header(
        logo_frame, "الشعار",
        "نفس فكرة الطلبات، بس بيضيف شعار العميل على المذكرات. ملف ومجلد مستقلين عن تاب الطلبات.",
    ).pack(anchor="w", fill="x")

    logo_files_card = Card(logo_frame)
    logo_files_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        logo_files_card.body, "ملفات الطلب",
        "الأعمدة المطلوبة في ملف الإكسل: كود العميل، كود الطلب، كود الملف، اسم المعلم، "
        "اسم المذكرة، رقم الهاتف، رقم الواتس، العلامة المائية، وفتح الملف (اختياري — نعم/لا). "
        "البرنامج بيضيف عمود 'الرابط' تلقائيًا بعد الرفع.",
    ).pack(anchor="w", fill="x")

    logo_excel_row = FilePickerRow(logo_files_card.body, "ملف البيانات (Excel)", "اختر ملف Excel")
    logo_excel_row.pick_button.configure(command=lambda: pick_excel_file("logo", logo_excel_row))
    logo_excel_row.pack(fill="x", pady=(th.SPACE_MD, 0))
    logo_excel_row.set_path(upload_files.get_excel_file("logo"))

    logo_folder_row = FilePickerRow(logo_files_card.body, "مجلد القوالب", "اختر مجلد القوالب")
    logo_folder_row.pick_button.configure(command=lambda: pick_templates_folder("logo", logo_folder_row))
    logo_folder_row.pack(fill="x", pady=(th.SPACE_MD, 0))
    logo_folder_row.set_path(upload_files.get_selected_folder("logo"))

    logo_options_card = Card(logo_frame)
    logo_options_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(logo_options_card.body, "خيارات التنفيذ").pack(anchor="w")

    add_password_var_logo = tk.BooleanVar(value=True)
    tb.Checkbutton(
        logo_options_card.body, text="تفعيل حماية الملفات بباسورد", variable=add_password_var_logo, bootstyle="round-toggle"
    ).pack(anchor="w", pady=(th.SPACE_MD, 4))

    shutdown_var_logo = tk.BooleanVar(value=False)
    tb.Checkbutton(
        logo_options_card.body, text="إغلاق الجهاز تلقائيًا بعد ما ينتهي التنفيذ", variable=shutdown_var_logo, bootstyle="round-toggle"
    ).pack(anchor="w", pady=4)

    auto_export_failed_var_logo = tk.BooleanVar(value=False)
    tb.Checkbutton(
        logo_options_card.body, text="تنزيل طلبات اللوجو غير المكتملة تلقائيًا على الديسكتوب", variable=auto_export_failed_var_logo, bootstyle="round-toggle"
    ).pack(anchor="w", pady=4)

    local_only_var_logo = tk.BooleanVar(value=False)
    tb.Checkbutton(
        logo_options_card.body, text="إنهاء الطلبات على الجهاز فقط (بدون رفع أو واتساب)",
        variable=local_only_var_logo, bootstyle="round-toggle"
    ).pack(anchor="w", pady=4)

    logo_progress = ProgressPanel(logo_frame)
    logo_progress.pack(fill="x", pady=(th.SPACE_LG, 0))

    logo_actions = ttk.Frame(logo_frame)
    logo_actions.pack(fill="x", pady=(th.SPACE_LG, 0))

    def update_logo_failed_orders_button(count):
        if count:
            logo_failed_orders_button.configure(
                text=f"تنزيل طلبات اللوجو غير المكتملة ({count} صف)", state="normal"
            )
        else:
            logo_failed_orders_button.configure(text="كل طلبات اللوجو اكتملت بنجاح", state="disabled")

    def download_logo_failed_orders():
        def worker():
            file_path = upload_files.export_failed_orders("logo")
            if file_path:
                root.after(0, lambda: messagebox.showinfo("تم", f"تم حفظ الشيت على الديسكتوب:\n{file_path}"))
        threading.Thread(target=worker, daemon=True).start()

    def set_logo_controls(state):
        if state == "running":
            logo_start_button.configure(state="disabled")
            logo_pause_button.configure(state="normal")
            logo_resume_button.configure(state="disabled")
        elif state == "paused":
            logo_pause_button.configure(state="disabled")
            logo_resume_button.configure(state="normal")
        else:
            logo_start_button.configure(state="normal")
            logo_pause_button.configure(state="disabled")
            logo_resume_button.configure(state="disabled")

    def start_logo_orders():
        process_orders_logo(
            router, logo_frame, links_container, frame_links, work_folder_var.get(),
            add_password_var_logo.get(), make_progress_callback(logo_progress, set_logo_controls), shutdown_var_logo.get(),
            auto_export_failed_var_logo.get(), update_logo_failed_orders_button, local_only_var_logo.get(),
        )

    logo_start_button = tb.Button(
        logo_actions, text="بدء التنفيذ", bootstyle="primary", command=start_logo_orders,
    )
    logo_start_button.pack(side="left", ipadx=14, ipady=6)

    logo_pause_button = tb.Button(
        logo_actions, text="إيقاف مؤقت", bootstyle="warning-outline",
        command=lambda: (upload_files.request_pause("logo"), set_logo_controls("paused"))
    )
    logo_pause_button.pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)
    logo_resume_button = tb.Button(
        logo_actions, text="استكمال", bootstyle="success-outline",
        command=lambda: (upload_files.resume_run("logo"), set_logo_controls("running"))
    )
    logo_resume_button.pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)
    set_logo_controls("ready")

    logo_failed_orders_button = tb.Button(
        logo_actions, text="كل طلبات اللوجو اكتملت بنجاح", bootstyle="success-outline", state="disabled",
        command=download_logo_failed_orders,
    )
    logo_failed_orders_button.pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)

    # ======================================================================
    # frame_links/links_container: مش تاب ظاهر تاني (اتشال بناءً على طلبك، لأن
    # الروابط بتترفع وتتبعت واتساب أوتوماتيك أصلًا)، لكن لسه لازم يتبنوا (مخفيين)
    # عشان process_grouped_data في upload_files.py بيستخدمهم داخليًا وقت المعالجة
    # (بيحط فيهم ملخص الإرسال) — من غير ما نعدّل الكود هناك.
    # ======================================================================
    frame_links = ttk.Frame(pages_root)
    links_container = ttk.Frame(frame_links)
    links_container.pack(fill="both", expand=True)

    # ======================================================================
    # Page: delivery retry and durable run history.
    # ======================================================================
    frame_retry = ttk.Frame(pages_root)
    pages["retry"] = frame_retry
    page_header(
        frame_retry, "إعادة الرفع وسجل التشغيل",
        "يعرض كل تشغيل محفوظ. اختر عملية انتهى تقفيلها محلياً أو تعثرت في التسليم لإعادة رفعها وإرسال رسائلها بدون إعادة إنشاء PDF.",
    ).pack(anchor="w", fill="x")
    retry_toolbar = ttk.Frame(frame_retry)
    retry_toolbar.pack(fill="x", pady=(th.SPACE_LG, 0))
    ttk.Label(retry_toolbar, text="بحث", style="Small.TLabel").pack(side="left", padx=(0, th.SPACE_SM))
    retry_search_var = tk.StringVar()
    retry_search = tb.Entry(retry_toolbar, textvariable=retry_search_var, width=42)
    retry_search.pack(side="left")
    retry_mode_var = tk.StringVar(value="الكل")
    retry_status_var = tk.StringVar(value="الكل")
    tb.Combobox(retry_toolbar, textvariable=retry_mode_var, state="readonly", width=12,
                values=("الكل", "طلبات", "لوجو")).pack(side="left", padx=(th.SPACE_SM, 0))
    tb.Combobox(retry_toolbar, textvariable=retry_status_var, state="readonly", width=16,
                values=("الكل", "قيد التشغيل", "متوقف مؤقتاً", "مكتمل", "محلي فقط", "فشل")).pack(side="left", padx=(th.SPACE_SM, 0))
    retry_card = Card(frame_retry)
    retry_card.pack(fill="both", expand=True, pady=(th.SPACE_LG, 0))
    retry_columns = ("created", "mode", "work_folder", "status", "stage", "id")
    retry_list = ttk.Treeview(retry_card.body, columns=retry_columns, show="headings", height=13)
    retry_headings = {
        "created": "وقت التشغيل", "mode": "النوع", "work_folder": "فولدر الشغل",
        "status": "الحالة", "stage": "المرحلة", "id": "معرف العملية",
    }
    retry_widths = {"created": 145, "mode": 75, "work_folder": 145, "status": 115, "stage": 235, "id": 115}
    for column in retry_columns:
        retry_list.heading(column, text=retry_headings[column])
        retry_list.column(column, width=retry_widths[column], minwidth=70, anchor="center")
    retry_scroll = ttk.Scrollbar(retry_card.body, orient="vertical", command=retry_list.yview)
    retry_list.configure(yscrollcommand=retry_scroll.set)
    retry_scroll.pack(side="right", fill="y")
    retry_list.pack(fill="both", expand=True)
    retry_detail_var = tk.StringVar(value="اختر عملية لعرض تفاصيلها وخيارات الاستكمال.")
    ttk.Label(
        retry_card.body, textvariable=retry_detail_var, style="Small.TLabel", wraplength=850, justify="right",
    ).pack(anchor="w", fill="x", pady=(th.SPACE_MD, 0))
    retry_progress = ProgressPanel(frame_retry)
    retry_progress.pack(fill="x", pady=(th.SPACE_LG, 0))
    retry_runs = []

    def refresh_run_history():
        query = retry_search_var.get().strip().lower()
        all_runs = run_history.list_runs()
        status_labels = {
            "running": "قيد التشغيل", "retrying": "قيد التشغيل", "paused": "متوقف مؤقتاً",
            "completed": "مكتمل", "local_complete": "محلي فقط", "failed": "فشل",
        }
        retry_runs[:] = [
            item for item in all_runs
            if (not query or query in " ".join(str(value) for value in item.values()).lower())
            and (retry_mode_var.get() == "الكل" or (retry_mode_var.get() == "لوجو") == (item["mode"] == "logo"))
            and (retry_status_var.get() == "الكل" or status_labels.get(item["status"], item["status"]) == retry_status_var.get())
        ]
        for item_id in retry_list.get_children():
            retry_list.delete(item_id)
        for item in retry_runs:
            mode_label = "لوجو" if item["mode"] == "logo" else "طلبات"
            retry_list.insert(
                "", "end", iid=item["id"], values=(
                    item["created_at"], mode_label, item["work_folder"], status_labels.get(item["status"], item["status"]), item["stage"], item["id"],
                ),
            )

    def show_run_details(event=None):
        selected = retry_list.selection()
        if not selected:
            return
        item = run_history.get(selected[0])
        if item:
            retry_detail_var.set(
                f"المسار: {item['business_root']} | المصدر: {item['source_excel']} | "
                f"آخر تحديث: {item['updated_at']} | التفاصيل: {item.get('details') or 'لا توجد ملاحظات'}"
            )

    retry_list.bind("<<TreeviewSelect>>", show_run_details)
    retry_search_var.trace_add("write", lambda *_: refresh_run_history())
    retry_mode_var.trace_add("write", lambda *_: refresh_run_history())
    retry_status_var.trace_add("write", lambda *_: refresh_run_history())

    def run_selected_delivery():
        selected = retry_list.selection()
        if not selected:
            messagebox.showwarning("اختر عملية", "اختر عملية من القائمة أولاً.")
            return
        run = run_history.get(selected[0])
        if run["status"] == "completed":
            messagebox.showinfo("مكتمل", "هذه العملية مكتملة بالفعل ولا تحتاج إعادة رفع.")
            return
        retry_progress.start("جاري مراجعة ورفع الطلبات المحلية...", total=1)

        def callback(done, total, stage=""):
            root.after(0, lambda: retry_progress.update_progress(done, total, stage))

        def worker():
            try:
                retry_delivery_only.run_saved_delivery(run["id"], callback)
                root.after(0, lambda: (retry_progress.finish("تمت إعادة الرفع والإرسال"), refresh_run_history()))
            except Exception as exc:
                root.after(0, lambda msg=str(exc): (retry_progress.finish("تعذرت إعادة الرفع"), messagebox.showerror("خطأ إعادة الرفع", msg), refresh_run_history()))

        threading.Thread(target=worker, daemon=True).start()

    retry_actions = ttk.Frame(frame_retry)
    retry_actions.pack(fill="x", pady=(th.SPACE_LG, 0))
    tb.Button(retry_actions, text="تحديث السجل", bootstyle="secondary-outline", command=refresh_run_history).pack(side="left", ipadx=10, ipady=6)
    tb.Button(retry_actions, text="إعادة الرفع والإرسال", bootstyle="primary", command=run_selected_delivery).pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)
    tb.Button(retry_actions, text="إيقاف مؤقت", bootstyle="warning-outline", command=lambda: upload_files.request_pause("retry")).pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)
    tb.Button(retry_actions, text="استكمال", bootstyle="success-outline", command=lambda: upload_files.resume_run("retry")).pack(side="left", padx=(th.SPACE_SM, 0), ipadx=10, ipady=6)
    refresh_run_history()

    # ======================================================================
    # صفحة: رسائل واتساب (رسالة مخصّصة لكل الصفوف في ملف إكسل)
    # ======================================================================
    frame_msgs = ttk.Frame(pages_root)
    pages["messages"] = frame_msgs

    page_header(
        frame_msgs, "رسائل واتساب",
        "ابعت رسالة واحدة مخصّصة لكل الأرقام في ملف إكسل. تقدر تستخدم {اسم المعلم} أو أي اسم عمود تاني جوه {} في النص.",
    ).pack(anchor="w", fill="x")

    msgs_file_card = Card(frame_msgs)
    msgs_file_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        msgs_file_card.body, "ملف البيانات",
        "العمود الإلزامي: رقم الواتس. عمود اسم المعلم اختياري (لو موجود بيتحط بدل {اسم المعلم} في الرسالة). "
        "أي عمود تاني في الملف تقدر تستخدمه في نص الرسالة بكتابة اسمه بين قوسين معقوفين، زي {اسم العمود}.",
    ).pack(anchor="w", fill="x")

    tb.Button(
        msgs_file_card.body, text="اختر ملف إكسل", bootstyle="secondary-outline",
        command=lambda: upload_exel2(label_file),
    ).pack(anchor="w", pady=(th.SPACE_MD, 0))
    label_file = ttk.Label(msgs_file_card.body, text="لم يتم تحميل ملف بعد", style="Small.TLabel")
    label_file.pack(anchor="w", pady=(th.SPACE_SM, 0))

    msg_card = Card(frame_msgs)
    msg_card.pack(fill="both", expand=True, pady=(th.SPACE_LG, 0))
    section_title(msg_card.body, "نص الرسالة").pack(anchor="w")

    message_entry = tk.Text(msg_card.body, height=6, wrap="word", font=th.FONT_BODY, relief="flat")

    def paste_text(event=None):
        try:
            clipboard_text = root.clipboard_get()
            message_entry.insert(tk.INSERT, clipboard_text)
        except tk.TclError:
            pass  # الحافظة فاضية

    popup_menu = tk.Menu(message_entry, tearoff=0)
    popup_menu.add_command(label="لصق", command=paste_text)

    def show_popup(event):
        popup_menu.post(event.x_root, event.y_root)

    message_entry.pack(fill="both", expand=True, pady=(th.SPACE_MD, 0))
    message_entry.bind("<Control-v>", paste_text)
    message_entry.bind("<Button-3>", show_popup)

    label_status = ttk.Label(frame_msgs, text="", style="Small.TLabel")
    label_status.pack(anchor="w", pady=(th.SPACE_SM, 0))

    def start_custom_messages():
        message_snapshot = message_entry.get("1.0", "end").strip()
        send_messages_button.configure(state="disabled")

        def worker():
            try:
                send_custom_whatsapp_messages(label_status, custom_message=message_snapshot)
            finally:
                root.after(0, lambda: send_messages_button.configure(state="normal"))

        threading.Thread(target=worker, daemon=True).start()

    send_messages_button = tb.Button(
        frame_msgs, text="إرسال الرسالة", bootstyle="primary", command=start_custom_messages,
    )
    send_messages_button.pack(anchor="w", pady=(th.SPACE_LG, 0), ipadx=14, ipady=6)

    # ======================================================================
    # صفحة: الإعدادات
    # ======================================================================
    frame_settings = ttk.Frame(pages_root)
    pages["settings"] = frame_settings

    page_header(frame_settings, "الإعدادات", "إعدادات عامة للبرنامج على الجهاز ده.").pack(anchor="w", fill="x")

    folder_card = Card(frame_settings)
    folder_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        folder_card.body, "المجلد الرئيسي لشغل الشركة",
        "المجلد اللي فيه كل فولدرات الشغل (زي 'شغل 2024' و'شغل 2025').",
    ).pack(anchor="w")

    folder_value_label = ttk.Label(folder_card.body, text=business_root_folder_holder["value"], style="Mono.TLabel")
    folder_value_label.pack(anchor="w", pady=(th.SPACE_MD, th.SPACE_SM))

    def change_business_folder():
        new_path = filedialog.askdirectory(title="اختر المجلد الرئيسي لشغل الشركة")
        if new_path and os.path.isdir(new_path):
            settings.set_business_root_folder(new_path)
            upload_files.business_root_folder = new_path
            business_root_folder_holder["value"] = new_path
            folder_value_label.configure(text=new_path)
            refresh_work_folders()
            messagebox.showinfo("تم", "تم تحديث المجلد الرئيسي بنجاح.")

    tb.Button(
        folder_card.body, text="تغيير المجلد", bootstyle="secondary-outline", command=change_business_folder,
    ).pack(anchor="w")

    output_card = Card(frame_settings)
    output_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        output_card.body, "فولدرات الحفظ والرفع",
        "الأسماء دي هي اللي البرنامج بيحفظ فيها الملفات داخل فولدر الشغل، وبيستخدم نفس الأسماء عند الرفع.",
    ).pack(anchor="w")

    orders_subdir_var = tk.StringVar(value=settings.get_orders_subdir())
    logo_orders_subdir_var = tk.StringVar(value=settings.get_logo_orders_subdir())

    ttk.Label(output_card.body, text="فولدر الطلبات", style="Small.TLabel").pack(anchor="w", pady=(th.SPACE_MD, 2))
    orders_subdir_label = ttk.Label(output_card.body, textvariable=orders_subdir_var, style="Mono.TLabel")
    orders_subdir_label.pack(anchor="w", pady=(0, th.SPACE_SM))

    def change_orders_subdir():
        current_value = settings.get_orders_subdir()
        new_value = simpledialog.askstring(
            "اسم فولدر الطلبات",
            "اكتب اسم فولدر الطلبات الجديد:",
            initialvalue=current_value,
            parent=root,
        )
        if new_value is None:
            return
        new_value = new_value.strip()
        if not new_value:
            messagebox.showwarning("تحذير", "اسم الفولدر لا يمكن أن يكون فارغًا.")
            return
        settings.set_orders_subdir(new_value)
        orders_subdir_var.set(new_value)
        messagebox.showinfo("تم", "تم تحديث اسم فولدر الطلبات بنجاح.")

    tb.Button(
        output_card.body, text="تغيير اسم فولدر الطلبات", bootstyle="secondary-outline", command=change_orders_subdir,
    ).pack(anchor="w")

    ttk.Label(output_card.body, text="فولدر طلبات اللوجو", style="Small.TLabel").pack(anchor="w", pady=(th.SPACE_BASE, 2))
    logo_orders_subdir_label = ttk.Label(output_card.body, textvariable=logo_orders_subdir_var, style="Mono.TLabel")
    logo_orders_subdir_label.pack(anchor="w", pady=(0, th.SPACE_SM))

    def change_logo_orders_subdir():
        current_value = settings.get_logo_orders_subdir()
        new_value = simpledialog.askstring(
            "اسم فولدر طلبات اللوجو",
            "اكتب اسم فولدر طلبات اللوجو الجديد:",
            initialvalue=current_value,
            parent=root,
        )
        if new_value is None:
            return
        new_value = new_value.strip()
        if not new_value:
            messagebox.showwarning("تحذير", "اسم الفولدر لا يمكن أن يكون فارغًا.")
            return
        settings.set_logo_orders_subdir(new_value)
        logo_orders_subdir_var.set(new_value)
        messagebox.showinfo("تم", "تم تحديث اسم فولدر طلبات اللوجو بنجاح.")

    tb.Button(
        output_card.body, text="تغيير اسم فولدر طلبات اللوجو", bootstyle="secondary-outline", command=change_logo_orders_subdir,
    ).pack(anchor="w")

    message_card = Card(frame_settings)
    message_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        message_card.body, "رسالة تسليم الطلبات على واتساب",
        "تقدر تعدل النص أو تلصقه. استخدم {الاسم} و {الروابط} و {رابط الجروب}، أو أي اسم عمود من الشيت بين {} مثل {كود الطلب}. القيم المتعددة تتجمع تلقائيًا.",
    ).pack(anchor="w")
    teacher_message_text = tk.Text(message_card.body, height=9, wrap="word", font=th.FONT_BODY, relief="flat")
    teacher_message_text.insert("1.0", settings.get_teacher_whatsapp_template())
    teacher_message_text.pack(fill="x", pady=(th.SPACE_MD, th.SPACE_SM))

    def paste_teacher_message(event=None):
        try:
            teacher_message_text.insert(tk.INSERT, root.clipboard_get())
        except tk.TclError:
            pass
        return "break"

    teacher_message_menu = tk.Menu(teacher_message_text, tearoff=0)
    teacher_message_menu.add_command(label="لصق", command=paste_teacher_message)
    teacher_message_text.bind("<Control-v>", paste_teacher_message)
    teacher_message_text.bind("<Button-3>", lambda event: teacher_message_menu.tk_popup(event.x_root, event.y_root))

    def save_teacher_message_template():
        message_template = teacher_message_text.get("1.0", "end").strip()
        if not message_template:
            messagebox.showwarning("تحذير", "نص الرسالة لا يمكن أن يكون فارغًا.")
            return
        settings.set_teacher_whatsapp_template(message_template)
        messagebox.showinfo("تم", "تم حفظ رسالة واتساب الافتراضية.")

    tb.Button(
        message_card.body, text="حفظ نص الرسالة", bootstyle="secondary-outline", command=save_teacher_message_template,
    ).pack(anchor="w")

    appearance_card = Card(frame_settings)
    appearance_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(appearance_card.body, "المظهر", "تقدر تبدّل بين الوضع الغامق والفاتح من نفس الزرار في أسفل الشريط الجانبي.").pack(anchor="w")

    accounts_card = Card(frame_settings)
    accounts_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(accounts_card.body, "الحسابات المتصلة").pack(anchor="w")

    ttk.Label(accounts_card.body, text="حساب Google Drive", style="Small.TLabel").pack(anchor="w", pady=(th.SPACE_MD, 0))
    drive_status_label = ttk.Label(accounts_card.body, text="", style="Small.TLabel")
    drive_status_label.pack(anchor="w", pady=(2, 4))

    def do_switch_drive_account():
        drive_status_label.configure(text="جاري فتح صفحة تسجيل الدخول في المتصفح...")

        def worker():
            try:
                drive.switch_google_account()
                root.after(0, lambda: drive_status_label.configure(text="✓ تم تسجيل الدخول بحساب Drive جديد."))
            except Exception as e:
                err_msg = str(e)
                root.after(0, lambda msg=err_msg: drive_status_label.configure(text=f"⚠️ حصل خطأ: {msg}"))

        threading.Thread(target=worker, daemon=True).start()

    tb.Button(
        accounts_card.body, text="تغيير حساب Drive", bootstyle="secondary-outline", command=do_switch_drive_account,
    ).pack(anchor="w")

    ttk.Label(accounts_card.body, text="حساب واتساب", style="Small.TLabel").pack(anchor="w", pady=(th.SPACE_BASE, 0))
    ttk.Label(
        accounts_card.body, text="هيفتح واتساب ويب — سجّل خروج من القايمة وامسح كود QR لحساب تاني.",
        style="Small.TLabel", wraplength=420, justify="left",
    ).pack(anchor="w", pady=(2, 4))

    tb.Button(
        accounts_card.body, text="فتح واتساب ويب لتغيير الحساب", bootstyle="secondary-outline",
        command=lambda: _run_in_background(web_driver.reset_whatsapp_session),
    ).pack(anchor="w")

    debug_card = Card(frame_settings)
    debug_card.pack(fill="x", pady=(th.SPACE_LG, 0))
    section_title(
        debug_card.body, "السجل التقني",
        "شاشة محمية بكلمة سر بتوريك كل حاجة البرنامج بيطبعها وهو شغال. افتحها لو حصل خطأ وابعتلي اللي فيها.",
    ).pack(anchor="w")

    def open_debug_log():
        pw = simpledialog.askstring("دخول محمي", "اكتب كلمة السر:", show="*", parent=root)
        if pw is None:
            return
        if pw != DEBUG_LOG_PASSWORD:
            messagebox.showerror("خطأ", "كلمة السر غلط.")
            return
        show_page("logs")

    tb.Button(
        debug_card.body, text="عرض السجل التقني", bootstyle="secondary-outline", command=open_debug_log,
    ).pack(anchor="w", pady=(th.SPACE_MD, 0))
    tb.Button(
        debug_card.body, text="سجل التشغيل وإعادة الرفع", bootstyle="secondary-outline",
        command=lambda: (refresh_run_history(), show_page("retry")),
    ).pack(anchor="w", pady=(th.SPACE_SM, 0))

    # ======================================================================
    # صفحة مخفية: السجل التقني (متاحة بس عن طريق الزرار المحمي بكلمة سر فوق،
    # مش موجودة في nav_items عشان متبانش لمستخدم عادي)
    # ======================================================================
    frame_logs = ttk.Frame(pages_root)
    pages["logs"] = frame_logs

    page_header(
        frame_logs, "السجل التقني",
        "كل حاجة البرنامج بيطبعها وهو شغال، لحظة بلحظة. لو حصل خطأ، دوس 'نسخ الكل' وابعتلي اللي اتنسخ.",
    ).pack(anchor="w", fill="x")

    log_card = Card(frame_logs)
    log_card.pack(fill="both", expand=True, pady=(th.SPACE_LG, 0))

    log_toolbar = ttk.Frame(log_card.body)
    log_toolbar.pack(fill="x")

    def copy_log():
        root.clipboard_clear()
        root.clipboard_append(debug_log.get_full_text())
        messagebox.showinfo("تم", "تم نسخ السجل كامل.")

    def clear_log_view():
        debug_log.clear()
        log_text_widget.configure(state="normal")
        log_text_widget.delete("1.0", tk.END)
        log_text_widget.configure(state="disabled")
        _log_state["length"] = 0

    tb.Button(log_toolbar, text="نسخ الكل", bootstyle="primary", command=copy_log).pack(side="left")
    tb.Button(log_toolbar, text="امسح العرض", bootstyle="secondary-outline", command=clear_log_view).pack(
        side="left", padx=(th.SPACE_SM, 0)
    )

    log_text_frame = ttk.Frame(log_card.body)
    log_text_frame.pack(fill="both", expand=True, pady=(th.SPACE_SM, 0))

    log_scroll = ttk.Scrollbar(log_text_frame)
    log_scroll.pack(side="right", fill="y")

    log_text_widget = tk.Text(
        log_text_frame, wrap="word", font=th.FONT_MONO, state="disabled", yscrollcommand=log_scroll.set,
    )
    log_text_widget.pack(side="left", fill="both", expand=True)
    log_scroll.configure(command=log_text_widget.yview)

    _log_state = {"length": 0}

    def refresh_log():
        text = debug_log.get_full_text()
        cur_len = len(text)
        if cur_len != _log_state["length"]:
            if cur_len < _log_state["length"]:
                # البفر اتقصّ (وصل لسقفه)، نعيد رسم الكل من غير ما نفترض إنها إضافة بس
                log_text_widget.configure(state="normal")
                log_text_widget.delete("1.0", tk.END)
                log_text_widget.insert(tk.END, text)
                log_text_widget.configure(state="disabled")
                log_text_widget.see(tk.END)
            else:
                new_part = text[_log_state["length"]:]
                was_at_bottom = log_text_widget.yview()[1] >= 0.999
                log_text_widget.configure(state="normal")
                log_text_widget.insert(tk.END, new_part)
                log_text_widget.configure(state="disabled")
                if was_at_bottom:
                    log_text_widget.see(tk.END)
            _log_state["length"] = cur_len
        root.after(700, refresh_log)

    refresh_log()

    # ======================================================================
    # الشريط الجانبي — بيتبني آخر حاجة عشان يقدر يشاور على كل الصفحات اللي فوق
    # ======================================================================
    def toggle_theme():
        new_key = "light" if theme_state["value"] == "dark" else "dark"
        theme_state["value"] = new_key
        settings.set_theme_preference(new_key)
        th.set_app_theme(root, style, new_key)
        sidebar.set_theme_button_text(new_key)

    nav_items = [
        ("orders", icons.NAV_ICONS["orders"], "الطلبات"),
        ("logo", icons.NAV_ICONS["logo"], "الشعار"),
        ("retry", icons.NAV_ICONS["retry"], "إعادة الرفع والسجل"),
        ("messages", icons.NAV_ICONS["messages"], "رسائل واتساب"),
        ("settings", icons.NAV_ICONS["settings"], "الإعدادات"),
    ]

    sidebar = Sidebar(
        shell,
        logo_path=os.path.join(os.path.dirname(os.path.abspath(__file__)), "img.jpeg"),
        nav_items=nav_items,
        on_nav=show_page,
        on_toggle_theme=toggle_theme,
        theme_key=theme_state["value"],
        version_text="EE Operations",
    )
    # الشريط الجانبي بيتحط الأول (يمين الشاشة بصريًا = يسار في ترتيب pack)،
    # وبعدين منطقة المحتوى تاخد الباقي كله
    sidebar.pack(side="left", fill="y")
    content_root.pack(side="left", fill="both", expand=True)

    # أول صفحة تتفتح فعليًا (Sidebar بس بيلوّن شكل الزرار النشط جوه الـ constructor،
    # مش بيعرض الصفحة نفسها — عشان show_page نفسها بتشاور على sidebar)
    show_page(nav_items[0][0])

    # ملحوظة: مش بنسجّل frame_links في الراوتر — تاب الروابط اتشال من الواجهة،
    # فـ tabs.select(frame_links) اللي upload_files.py بينده بعد ما يخلص معالجة
    # هيبقى من غير أي تأثير (مش هيلاقي مفتاح مسجّل، فمش هيغيّر الصفحة الحالية)
    router.bind_show(show_page)

    root.mainloop()
