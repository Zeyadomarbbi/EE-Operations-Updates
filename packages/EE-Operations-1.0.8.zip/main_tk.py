"""Explicit launcher for the legacy Tk interface, retained as a safe fallback."""

from gui import create_gui


if __name__ == "__main__":
    create_gui()
