$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$WshShell = New-Object -ComObject WScript.Shell
$ShortcutPath = Join-Path $env:USERPROFILE "Desktop\EE Operations.lnk"
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = Join-Path $env:SystemRoot "System32\wscript.exe"
$Shortcut.Arguments = "`"$here\run_app_silent.vbs`""
$Shortcut.WorkingDirectory = $here
$Shortcut.WindowStyle = 7
$iconPath = Join-Path $here "app_icon.ico"
if (Test-Path $iconPath) {
    $Shortcut.IconLocation = $iconPath
}
$Shortcut.Description = "EE Operations"
$Shortcut.Save()
Write-Output "Shortcut created at: $ShortcutPath"
