@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================
echo   EE Operations - first-time setup
echo ============================================
echo.

rem This build is pinned to Python 3.11. Python 3.13 has no compatible
rem NumPy 1.26 wheel and would otherwise trigger a failed C compiler build.
set "PYCMD="
where py >nul 2>nul
if not errorlevel 1 (
    py -3.11 -c "import sys" >nul 2>nul
    if not errorlevel 1 set "PYCMD=py -3.11"
)

if "%PYCMD%"=="" if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set PYCMD="%LocalAppData%\Programs\Python\Python311\python.exe"
if "%PYCMD%"=="" if exist "%ProgramFiles%\Python311\python.exe" set PYCMD="%ProgramFiles%\Python311\python.exe"

if "%PYCMD%"=="" (
    echo Python 3.11 is required. Trying Windows Package Manager...
    where winget >nul 2>nul
    if not errorlevel 1 winget install --id Python.Python.3.11 --exact --silent --accept-package-agreements --accept-source-agreements
    if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set PYCMD="%LocalAppData%\Programs\Python\Python311\python.exe"
    if "%PYCMD%"=="" if exist "%ProgramFiles%\Python311\python.exe" set PYCMD="%ProgramFiles%\Python311\python.exe"
)

if "%PYCMD%"=="" (
    echo.
    echo [ERROR] Python 3.11 could not be found or installed automatically.
    echo Install Python 3.11 from https://www.python.org/downloads/ then run setup.bat again.
    pause
    exit /b 1
)

%PYCMD% -c "import sys; print('Using Python', sys.version)"

rem A copied virtual environment stores paths from the old computer.
rem Recreate it whenever it is missing or was built with another Python version.
if exist venv\Scripts\python.exe (
    venv\Scripts\python.exe -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)" >nul 2>nul
    if errorlevel 1 (
        echo Removing incompatible virtual environment...
        rmdir /s /q venv
    )
)

if not exist venv\Scripts\python.exe (
    echo Creating Python 3.11 virtual environment...
    %PYCMD% -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create the virtual environment.
        pause
        exit /b 1
    )
)

echo.
echo Installing required packages, this can take a few minutes...
venv\Scripts\python.exe -m pip install --upgrade pip
venv\Scripts\python.exe -m pip install --only-binary=:all: -r requirements.lock.txt
if errorlevel 1 (
    echo [ERROR] Package installation failed. Check internet access, then run setup.bat again.
    pause
    exit /b 1
)

echo.
echo Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
if errorlevel 1 (
    echo [WARNING] Could not create the desktop shortcut automatically.
    echo You can still run the app with run_app.bat in this folder.
)

echo.
echo ============================================
echo   Done. Look for "EE Operations" on your Desktop.
echo ============================================
pause
