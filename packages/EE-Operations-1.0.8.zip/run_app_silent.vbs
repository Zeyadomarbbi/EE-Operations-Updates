Set WshShell = CreateObject("WScript.Shell")
scriptDir = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
cmd = "cmd /c cd /d """ & scriptDir & """ && venv\Scripts\python.exe main.py > app_log.txt 2>&1"
WshShell.Run cmd, 0, False
