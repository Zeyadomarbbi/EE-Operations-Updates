"""Retry Drive upload and WhatsApp delivery for PDFs that already exist locally."""

import os
import shutil
import sys
import tempfile
import time
import urllib.parse

import pandas as pd

import config
import drive
import settings
import upload_files
import web_driver
import run_history


for output_stream in (sys.stdout, sys.stderr):
    try:
        output_stream.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass


def normalized_phone(value):
    number = str(value).strip().split(".")[0]
    if number.startswith("0"):
        return config.EGYPT_COUNTRY_CODE + number[1:]
    if number.startswith("+"):
        return number
    return config.EGYPT_COUNTRY_CODE + number


def send_teacher_message(teacher_name, teacher_rows, work_folder_name):
    phone = normalized_phone(teacher_rows.iloc[0]["رقم الواتس"])
    if not phone[1:].isdigit():
        raise ValueError(f"Invalid WhatsApp number for {teacher_name}: {phone}")

    # Delivery jobs may run beside normal/logo conversion; the browser itself remains serial.
    with web_driver.driver_lock:
        driver = web_driver.ensure_whatsapp_ready()
        if driver is None:
            raise RuntimeError("WhatsApp Web could not be started")

        message = upload_files.build_teacher_whatsapp_message(
            teacher_name,
            teacher_rows,
            work_folder_name,
            add_password=False,
        )
        driver.get(
            f"{config.WHATSAPP_SEND_URL_BASE}?phone={phone}&text={urllib.parse.quote(message)}"
        )
        web_driver.send_current_whatsapp_message(driver)
    print(f"[DELIVERY] WhatsApp sent: {teacher_name} | {phone}")


def main(excel_path, business_root_folder, work_folder_name, mode="normal", progress_callback=None):
    data = pd.read_excel(excel_path)
    data = upload_files.prepare_delivery_data(data)
    upload_files.validate_delivery_data(data)
    if "الرابط" not in data.columns:
        data["الرابط"] = None
    data["الرابط"] = data["الرابط"].astype("object")

    failed_teachers = set()
    upload_function = drive.upload_order_files_logo if mode == "logo" else drive.upload_order_files
    service = drive.authenticate_google_drive()
    general_products_id = drive.find_folder(service, config.DRIVE_FOLDER_GENERAL_PRODUCTS)
    pending_clients = []
    for client_code, client_rows in data.groupby("كود العميل", sort=False):
        order_codes = sorted({str(value).strip() for value in client_rows["كود الطلب"]})
        client_folder_name = "_".join(order_codes)
        existing_links = client_rows["الرابط"].dropna().astype(str).str.strip()
        remote_folder_id = (
            drive.find_folder(service, client_folder_name, general_products_id)
            if general_products_id else None
        )
        # A stored link alone is not proof that Drive still has the order.
        if remote_folder_id and not existing_links.empty and existing_links.ne("").all():
            continue
        pending_clients.append((client_code, client_rows.copy()))

    for index, (client_code, client_rows) in enumerate(pending_clients, start=1):
        upload_files.wait_if_paused("retry")
        if progress_callback:
            progress_callback(index - 1, len(pending_clients), f"Uploading {client_code}")
        order_codes = sorted({str(value).strip() for value in client_rows["كود الطلب"]})
        client_folder_name = "_".join(order_codes)
        output_subdir = settings.get_logo_orders_subdir() if mode == "logo" else settings.get_orders_subdir()
        local_order_folder = os.path.join(business_root_folder, work_folder_name, output_subdir, client_folder_name)
        raw_open_value = client_rows["فتح الملف"].iloc[0]
        share_value = str(raw_open_value).strip() if pd.notna(raw_open_value) else ""
        teacher_name = str(client_rows["اسم المعلم"].iloc[0]).strip()

        if not os.path.isdir(local_order_folder) or not any(
            name.lower().endswith(".pdf") for _, _, files in os.walk(local_order_folder) for name in files
        ):
            failed_teachers.add(teacher_name)
            print(f"[DELIVERY] Local PDFs are missing: {client_folder_name}")
            continue
        print(f"[DELIVERY] Retrying upload only: {client_folder_name}")
        link = upload_function(
            client_code,
            client_folder_name,
            business_root_folder,
            work_folder_name,
            share_value,
        )
        if link:
            data.loc[client_rows.index, "الرابط"] = link
            print(f"[DELIVERY] Drive verified: {client_folder_name}")
        else:
            failed_teachers.add(teacher_name)
            print(f"[DELIVERY] Upload failed: {client_folder_name}")
        if progress_callback:
            progress_callback(index, len(pending_clients), f"Uploaded {client_code}")

    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as temporary_file:
        temporary_path = temporary_file.name
    data.to_excel(temporary_path, index=False)
    shutil.move(temporary_path, excel_path)

    for teacher_name, teacher_rows in data.groupby("اسم المعلم", sort=False):
        upload_files.wait_if_paused("retry")
        teacher_name = str(teacher_name).strip()
        if teacher_name in failed_teachers:
            print(f"[DELIVERY] WhatsApp skipped because upload failed: {teacher_name}")
            continue
        ready_rows = teacher_rows[
            pd.notna(teacher_rows["الرابط"])
            & teacher_rows["الرابط"].astype(str).str.strip().ne("")
        ]
        if ready_rows.empty:
            print(f"[DELIVERY] WhatsApp skipped because no verified link exists: {teacher_name}")
            continue
        send_teacher_message(teacher_name, ready_rows, work_folder_name)
        time.sleep(2)


def run_saved_delivery(run_id, progress_callback=None):
    run = run_history.get(run_id)
    if not run:
        raise ValueError("The selected run is no longer available.")
    if not os.path.exists(run["snapshot"]):
        raise FileNotFoundError("The saved Excel snapshot for this run is missing.")
    run_history.update(run_id, status="retrying", stage="Delivery retry")
    try:
        main(run["snapshot"], run["business_root"], run["work_folder"], run["mode"], progress_callback)
        run_history.update(run_id, status="completed", stage="Drive and WhatsApp completed")
    except Exception as exc:
        run_history.update(run_id, status="failed", stage="Delivery retry failed", details=str(exc))
        raise


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit(
            "Usage: retry_delivery_only.py <excel_path> <business_root_folder> <work_folder_name>"
        )
    main(*sys.argv[1:])
