from tkinter import filedialog, ttk
import tkinter.messagebox as msgbox
from tkinter import filedialog, messagebox
import pandas as pd
import tkinter as tk
import random
import urllib.parse
import re
import time
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import config
import web_driver


excel_file2 = None

def upload_exel2(label_file):
    global excel_file2
    file_path2 = filedialog.askopenfilename(title="اختر ملف البيانات", filetypes=[("Excel files", "*.xlsx;*.xls")])

    if file_path2:
        try:
            df = pd.read_excel(file_path2)  # قراءة الملف
            if "رقم الواتس" not in df.columns:
                messagebox.showerror("خطأ", "⚠️ الملف لا يحتوي على عمود باسم 'رقم الواتس'!")
                return  # إيقاف التنفيذ

            excel_file2 = file_path2
            label_file.config(text="✅ تم رفع الملف بنجاح!", foreground="green")

        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء قراءة الملف: {e}")
    else:
        label_file.config(text="⚠️ لم يتم اختيار أي ملف!", foreground="red")


def send_custom_whatsapp_messages(label_status, message_entry=None, custom_message=None, progress_callback=None):
    global excel_file2

    def update_status(text, color="black"):
        label_status.after(0, lambda: label_status.config(text=text, foreground=color))

    def show_error(message):
        label_status.after(0, lambda: msgbox.showerror("خطأ", message))

    update_status("")

    # **التأكد من تحميل ملف الإكسل**
    if not excel_file2:
        show_error("⚠️ لم يتم تحميل ملف الإكسل! الرجاء رفع الملف أولاً.")
        update_status("⚠️ لم يتم تحميل ملف الإكسل!", "red")
        return

    # ✅ **قراءة ملف الإكسل**
    try:
        df = pd.read_excel(excel_file2)
    except Exception as e:
        show_error(f"⚠️ خطأ أثناء قراءة ملف الإكسل: {str(e)}")
        update_status("⚠️ خطأ في قراءة ملف الإكسل!", "red")
        return

    # ✅ **التأكد من أن الرسالة ليست فارغة**
    if custom_message is None:
        custom_message = message_entry.get("1.0", tk.END).strip()
    else:
        custom_message = custom_message.strip()
    if not custom_message:
        show_error("⚠️ لا يوجد محتوى للرسالة! الرجاء كتابة الرسالة قبل الإرسال.")
        update_status("⚠️ الرجاء كتابة الرسالة!", "red")
        return

    with web_driver.driver_lock:
        driver = web_driver.ensure_whatsapp_ready()
    if driver is None:
        show_error("⚠️ تعذر تشغيل المتصفح! تأكد من أن msedgedriver.exe موجود.")
        return

    # ✅ **تجميع البيانات لكل معلم**
    grouped_data = df.groupby('رقم الواتس')
    sent_messages_count = 0
    failed_numbers = []  # قائمة لتخزين الأرقام التي فشل إرسال الرسائل إليها


    send_delay_range = (2.5, 4.5)

    # ✅ **إرسال الرسائل لكل مدرس**
    total_messages = grouped_data.ngroups
    for sent_index, (index, data) in enumerate(grouped_data, start=1):
        if progress_callback:
            progress_callback(sent_index - 1, total_messages, f"Preparing WhatsApp message {sent_index}")
        full_number = None
        try:
            # ✅ **استخراج اسم المدرس مع اللقب**
            if "اسم المعلم" in data.columns:
                teacher = str(data.iloc[0]["اسم المعلم"]).strip()
                name_parts = teacher.strip().split()
                if name_parts[0] in ['د.', 'م.', 'أ.']:
                    if len(name_parts) > 1 and name_parts[1] in ['عبد', 'أبو']:
                        first_name = f" {name_parts[0]} {name_parts[1]} {name_parts[2]}"
                    else:
                        first_name = f"{name_parts[0]} {name_parts[1]}"
                elif name_parts[0] in ['عبد', 'أبو'] and len(name_parts) > 1:
                    first_name = f"أ. {name_parts[0]} {name_parts[1]}"  # أ. عبد الله / أ. أبو بكر

                else:
                    first_name = f"أ. {name_parts[0]}"
            else:
                first_name = " "
                # ✅ **استبدال {الاسم} في الرسالة**
            message = custom_message.replace("{اسم المعلم}", first_name)

            #استبدال كلمات بقيمة الاعمدة
            placeholders = re.findall(r"{(.*?)}", message)

            if placeholders:
                print(f"🔍 الكلمات المستخرجة من الرسالة قبل المعالجة: {placeholders}")

                # ✅ **تنظيف المسافات الزائدة داخل الكلمات**
                placeholders = [' '.join(ph.split()).strip() for ph in placeholders]

                print(f"✅ الكلمات المستخرجة بعد تنظيف المسافات: {placeholders}")

            else:
                print("⚠️ لا توجد أي كلمات محاطة بأقواس {} في الرسالة!")

            # ✅ **استبدال أي متغير موجود في ملف الإكسل**
            for placeholder in placeholders:
                cleaned_placeholder = placeholder.strip()  # إزالة أي مسافات زائدة

                # ✅ التأكد من وجود العمود في ملف الإكسل حتى بعد إزالة المسافات الزائدة
                matching_columns = [col for col in data.columns if col.strip() == cleaned_placeholder]

                if matching_columns:
                    value = str(data.iloc[0][matching_columns[0]])
                    message = message.replace(f"{{{placeholder}}}", value)
                else:
                    print(f"⚠️ تحذير: العمود '{placeholder}' غير موجود في ملف الإكسل (بعد تنظيف المسافات)!")

            # الرقم
            number = str(data.iloc[0]['رقم الواتس']).strip().split('.')[0]  # إزالة أي أصفار أو .0

            # ✅ **تنسيق الرقم**
            if number.startswith("0"):
                full_number = config.EGYPT_COUNTRY_CODE + number[1:]
            elif not number.startswith("+"):
                full_number = config.EGYPT_COUNTRY_CODE + number
            else:
                full_number = number

            if not full_number[1:].isdigit():
                print(f"❌ الرقم غير صالح: {full_number}")
                failed_numbers.append(full_number)
                continue  # ⬅️ تخطي هذا الرقم

            print(f"📞 الرقم بعد التعديل: {full_number}")

            # ✅ **إنشاء رابط واتساب**
            encoded_message = urllib.parse.quote(message)
            whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"

            with web_driver.driver_lock:
                driver = web_driver.ensure_whatsapp_ready()
                if driver is None:
                    raise RuntimeError("تعذر تجهيز واتساب ويب.")

                driver.get(whatsapp_url)
                print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")

                web_driver.send_current_whatsapp_message(driver)

            sent_messages_count += 1
            print(f"✅ تم إرسال الرسالة إلى {full_number}")
            update_status(f"✅ تم إرسال الرسالة إلى {full_number}", "green")
            time.sleep(random.uniform(*send_delay_range))
            if progress_callback:
                progress_callback(sent_index, total_messages, f"WhatsApp message {sent_index} of {total_messages}")

        except Exception as e:
            print(f"❌ فشل الإرسال للرقم: {full_number}. الخطأ: {str(e)}")
            failed_numbers.append(full_number or str(index))
            update_status(f"❌ فشل الإرسال للرقم: {full_number or index}", "red")

    # ✅ تحديث نص الليبل بعد انتهاء الإرسال
    summary_text = f"📢 **ملخص الإرسال** 📢\n✅ تم إرسال {sent_messages_count} رسالة بنجاح.\n"

    if failed_numbers:
        summary_text += f"❌ لم يتم إرسال الرسائل إلى {len(failed_numbers)} رقم:\n"
        summary_text += "\n".join([f"   - {num}" for num in failed_numbers])
    else:
        summary_text += "🎉 تم إرسال جميع الرسائل بنجاح! 🚀"

    # ✅ عرض النتيجة في الليبل
    update_status(summary_text, "green" if not failed_numbers else "red")
