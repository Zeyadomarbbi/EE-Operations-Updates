# إعدادات بيختارها المستخدم بنفسه وبتتحفظ على الجهاز عشان متتسألش تاني
import json
import os
import re
from tkinter import filedialog, messagebox
import config

SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "user_settings.json")

DEFAULT_TEACHER_WHATSAPP_TEMPLATE = (
    "السلام عليكم أ. {الاسم}\n"
    "اتفضل حضرتك الملفات على الرابط ده:\n"
    "{الروابط}\n"
    "----------------------------------------\n"
    "ولو حضرتك مش معانا في الجروب الخاص يا ريت تنورنا:\n"
    "{رابط الجروب}"
)


def _load():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save(data):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def get_business_root_folder():
    """
    مسار المجلد الرئيسي لشغل الشركة (اللي جواه فولدرات زي "شغل 2024" و"شغل 2025").
    أول مرة يتشغل فيها البرنامج على الجهاز، بيسأل المستخدم يختاره من فولدر بيكر،
    وبعدين بيحفظه في user_settings.json عشان مايتسألش تاني في المرات الجاية.
    """
    data = _load()
    root_folder = data.get("business_root_folder")

    if root_folder and os.path.isdir(root_folder):
        return root_folder

    while True:
        messagebox.showinfo(
            "إعداد أول استخدام",
            "اختر المجلد الرئيسي لشغل الشركة (اللي فيه فولدرات زي 'شغل 2024' و'شغل 2025').\n"
            "هيتم حفظ اختيارك، ومش هيتسأل منك تاني على الجهاز ده."
        )
        root_folder = filedialog.askdirectory(title="اختر المجلد الرئيسي لشغل الشركة")
        if root_folder and os.path.isdir(root_folder):
            data["business_root_folder"] = root_folder
            _save(data)
            return root_folder
        messagebox.showwarning("تحذير", "لازم تختار مجلد صحيح عشان تكمل.")


def list_work_folders(business_root_folder):
    """
    يرجع أسماء كل الفولدرات الموجودة مباشرة جوه المجلد الرئيسي (أي فولدر، مش شرط يبدأ بـ"شغل ").
    بيقرأ من الديسك في كل مرة، فأي فولدر جديد بتضيفه هيظهر تلقائيًا من غير أي تعديل في الكود.
    """
    try:
        return sorted(
            name for name in os.listdir(business_root_folder)
            if os.path.isdir(os.path.join(business_root_folder, name))
        )
    except FileNotFoundError:
        return []


def is_setup_completed():
    """هل خطوات إعداد أول استخدام (المجلد + Google Drive + واتساب) خلصت قبل كده على الجهاز ده؟"""
    return bool(_load().get("setup_completed"))


def mark_setup_completed():
    """تسجيل إن إعداد أول استخدام خلص، عشان الويزارد ميظهرش تاني على الجهاز ده."""
    data = _load()
    data["setup_completed"] = True
    _save(data)


def set_business_root_folder(new_path):
    """تغيير المجلد الرئيسي لشغل الشركة يدويًا من شاشة الإعدادات (بدل ويزارد أول استخدام بس)."""
    data = _load()
    data["business_root_folder"] = new_path
    _save(data)


def _get_non_empty_setting(key, default_value):
    value = _load().get(key, default_value)
    if isinstance(value, str):
        value = value.strip()
    return value or default_value


def get_orders_subdir():
    """اسم فولدر الطلبات المحلي/الأساسي الحالي."""
    return _get_non_empty_setting("orders_subdir", config.ORDERS_SUBDIR)


def set_orders_subdir(folder_name):
    data = _load()
    data["orders_subdir"] = folder_name.strip()
    _save(data)


def get_logo_orders_subdir():
    """اسم فولدر طلبات اللوجو المحلي/الأساسي الحالي."""
    return _get_non_empty_setting("logo_orders_subdir", config.LOGO_ORDERS_SUBDIR)


def set_logo_orders_subdir(folder_name):
    data = _load()
    data["logo_orders_subdir"] = folder_name.strip()
    _save(data)


def get_work_folder():
    """Return the work folder selected once from the settings screen."""
    return _load().get("work_folder", "").strip()


def set_work_folder(folder_name):
    data = _load()
    data["work_folder"] = folder_name.strip()
    _save(data)


def get_teacher_whatsapp_template():
    """نص رسالة تسليم الطلبات المحفوظ من صفحة الإعدادات."""
    return _get_non_empty_setting("teacher_whatsapp_template", DEFAULT_TEACHER_WHATSAPP_TEMPLATE)


def set_teacher_whatsapp_template(message_template):
    data = _load()
    data["teacher_whatsapp_template"] = message_template.strip()
    _save(data)


def get_theme_preference():
    """المظهر المحفوظ (light/dark). الفاتح هو الافتراضي."""
    return _load().get("theme", "light")


def set_theme_preference(theme_name):
    data = _load()
    data["theme"] = theme_name
    _save(data)


def get_password_year_suffix(work_folder_name):
    """
    بيستخرج لاحقة باسورد حماية الـ PDF من اسم فولدر الشغل نفسه (زي "شغل 2025" → "2425"):
    آخر رقمين من السنة اللي قبل + آخر رقمين من السنة الموجودة في اسم الفولدر.
    لو اسم الفولدر مفيهوش سنة (4 أرقام)، بترجع None.
    """
    match = re.search(r"(\d{4})", work_folder_name)
    if not match:
        return None
    year = int(match.group(1))
    return f"{str(year - 1)[-2:]}{str(year)[-2:]}"
