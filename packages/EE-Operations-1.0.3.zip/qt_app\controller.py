"""Safe Qt-to-existing-engine adapter. Business modules remain untouched."""

import threading
import tkinter as tk
import time

from PySide6.QtCore import QObject, Signal

import msgs
import retry_delivery_only
import run_history
import upload_files


class _Tabs:
    def select(self, _frame):
        pass


class _StatusProxy:
    def __init__(self, callback):
        self._callback = callback

    def after(self, _delay, function):
        function()

    def config(self, **kwargs):
        self._callback(kwargs.get("text", ""))


class BackendController(QObject):
    progress = Signal(str, int, int, str)
    status = Signal(str, str)
    completed = Signal(str)
    failed = Signal(str, str)

    def __init__(self):
        super().__init__()
        self._tk_root = tk.Tk()
        self._tk_root.withdraw()
        self._tabs = _Tabs()
        self._normal_frame = tk.Frame(self._tk_root)
        self._logo_frame = tk.Frame(self._tk_root)
        self._links_frame = tk.Frame(self._tk_root)
        self._links_container = tk.Frame(self._links_frame)

    def set_source(self, mode, excel_path=None, templates_path=None):
        if mode == "logo":
            if excel_path is not None:
                upload_files.excel_file_logo = excel_path
            if templates_path is not None:
                upload_files.selected_folder_logo = templates_path
        else:
            if excel_path is not None:
                upload_files.excel_file = excel_path
            if templates_path is not None:
                upload_files.selected_folder = templates_path

    def _progress_callback(self, mode):
        return lambda done, total, stage="": self.progress.emit(mode, done, total, stage)

    def start_orders(self, mode, work_folder, password, shutdown, auto_export, local_only, protect_as_images=True):
        try:
            known_runs = {item["id"] for item in run_history.list_runs()}
            if mode == "logo":
                upload_files.process_orders_logo(
                    self._tabs, self._logo_frame, self._links_container, self._links_frame,
                    work_folder, password, self._progress_callback(mode), shutdown, auto_export,
                    lambda _count: None, local_only, protect_as_images,
                )
            else:
                upload_files.process_orders(
                    self._tabs, self._normal_frame, self._links_container, self._links_frame,
                    work_folder, password, shutdown, self._progress_callback(mode), auto_export,
                    lambda _count: None, local_only, protect_as_images,
                )
            created = next(
                (item for item in run_history.list_runs()
                 if item.get("mode") == mode and item.get("id") not in known_runs),
                None,
            )
            if not created:
                raise RuntimeError("لم يتم إنشاء سجل للتشغيل. تحقق من البيانات ثم حاول مرة أخرى.")
            self.status.emit(mode, "جارٍ التشغيل")
            threading.Thread(target=self._watch_run, args=(mode, created["id"]), daemon=True).start()
        except Exception as exc:
            self.failed.emit(mode, str(exc))

    def _watch_run(self, mode, run_id):
        """Translate durable backend run states into Qt signals without polling UI widgets."""
        terminal = {"completed", "local_complete", "failed"}
        while True:
            run = run_history.get(run_id)
            if not run:
                self.failed.emit(mode, "تعذر العثور على سجل التشغيل.")
                return
            state = run.get("status", "")
            if state == "paused":
                self.status.emit(mode, "تم الإيقاف المؤقت عند نقطة آمنة. يمكنك الاستكمال الآن.")
            else:
                self.status.emit(mode, run.get("stage", "جارٍ العمل"))
            if state in terminal:
                if state == "failed":
                    self.failed.emit(mode, run.get("details") or "فشل التشغيل.")
                else:
                    self.completed.emit(mode)
                return
            time.sleep(1)

    def pause(self, mode):
        upload_files.request_pause(mode)
        self.status.emit(mode, "تم طلب الإيقاف المؤقت. جارٍ الوصول لأقرب نقطة آمنة...")

    def resume(self, mode):
        upload_files.resume_run(mode)
        self.status.emit(mode, "تم طلب الاستكمال. جارٍ استئناف أقرب خطوة آمنة...")

    def retry_delivery_direct(self, excel_path, business_root, work_folder, mode):
        def worker():
            try:
                self.status.emit("retry", "جارٍ فحص الملفات المحلية وDrive...")
                retry_delivery_only.main(
                    excel_path, business_root, work_folder, mode,
                    lambda done, total, stage="": self.progress.emit("retry", done, total, stage),
                )
                self.completed.emit("retry")
            except Exception as exc:
                self.failed.emit("retry", str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def retry_delivery(self, run_id):
        def worker():
            try:
                retry_delivery_only.run_saved_delivery(
                    run_id, lambda done, total, stage="": self.progress.emit("retry", done, total, stage)
                )
                self.completed.emit("retry")
            except Exception as exc:
                self.failed.emit("retry", str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def send_custom_messages(self, excel_path, message):
        def worker():
            try:
                msgs.excel_file2 = excel_path
                proxy = _StatusProxy(lambda text: self.status.emit("messages", text))
                msgs.send_custom_whatsapp_messages(
                    proxy,
                    custom_message=message,
                    progress_callback=lambda done, total, stage="": self.progress.emit("messages", done, total, stage),
                )
                self.completed.emit("messages")
            except Exception as exc:
                self.failed.emit("messages", str(exc))
        threading.Thread(target=worker, daemon=True).start()
