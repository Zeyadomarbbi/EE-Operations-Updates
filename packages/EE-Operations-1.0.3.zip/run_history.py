"""Persistent, user-facing history for normal, logo, and delivery-only jobs."""

import json
import os
import threading
import uuid
from datetime import datetime


_BASE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".run_history")
_INDEX_PATH = os.path.join(_BASE_DIR, "runs.json")
_LOCK = threading.RLock()


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _read():
    try:
        with open(_INDEX_PATH, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return []


def _write(items):
    os.makedirs(_BASE_DIR, exist_ok=True)
    temporary = _INDEX_PATH + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(items, handle, ensure_ascii=False, indent=2)
    os.replace(temporary, _INDEX_PATH)


def create(mode, work_folder, business_root, source_excel, local_only=False):
    """Create one durable job and reserve its immutable Excel snapshot path."""
    with _LOCK:
        run_id = uuid.uuid4().hex[:12]
        snapshot = os.path.join(_BASE_DIR, f"{run_id}.xlsx")
        item = {
            "id": run_id,
            "mode": mode,
            "work_folder": work_folder,
            "business_root": business_root,
            "source_excel": source_excel,
            "snapshot": snapshot,
            "local_only": bool(local_only),
            "status": "running",
            "stage": "Preparing",
            "created_at": _now(),
            "updated_at": _now(),
            "details": "",
        }
        items = _read()
        items.insert(0, item)
        _write(items[:250])
        return item


def update(run_id, **changes):
    with _LOCK:
        items = _read()
        for item in items:
            if item["id"] == run_id:
                item.update(changes)
                item["updated_at"] = _now()
                _write(items)
                return item
    return None


def list_runs():
    with _LOCK:
        return _read()


def get(run_id):
    return next((item for item in list_runs() if item["id"] == run_id), None)
