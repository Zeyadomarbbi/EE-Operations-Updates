@echo off
cd /d "%~dp0"

echo ============================================
echo   EE Operations - first-time setup
echo ============================================
echo.

rem Windows sometimes points the bare "python" command at a Microsoft Store
rem stub instead of a real install. The "py" launcher is not affected by that,
rem so we prefer it and only fall back to "python" if "py" isn't available.
set PYCMD=
where py >nul 2>nul
if not errorlevel 1 (
    set PYCMD=py -3
) else (
    where python >nul 2>nul
    if not errorlevel 1 (
        set PYCMD=python
    )
)

if "%PYCMD%"=="" (
    echo [ERROR] Python was not found on this PC.
    echo Install Python 3.11 from https://www.python.org/downloads/
    echo During install, make sure to check "Add python.exe to PATH".
    echo Then run this setup.bat again.
    echo.
    pause
    exit /b 1
)

if not exist venv (
    echo Creating virtual environment...
    %PYCMD% -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create the virtual environment.
        echo.
        pause
        exit /b 1
    )
) else (
    echo Virtual environment already exists, skipping creation.
)

echo.
echo Installing required packages, this can take a few minutes...
venv\Scripts\python.exe -m pip install --upgrade pip
if exist requirements.lock.txt (
    venv\Scripts\python.exe -m pip install -r requirements.lock.txt
) else (
    venv\Scripts\python.exe -m pip install -r requirements.txt
)
if errorlevel 1 (
    echo [ERROR] Installing packages failed. Check your internet connection and try again.
    echo.
    pause
    exit /b 1
)

echo.
echo Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
if errorlevel 1 (
    echo [WARNING] Could not create the desktop shortcut automatically.
    echo You can still run the app with run_app.bat in this folder.
)

echo.
echo ============================================
echo   Done. Look for "EE Operations" on your Desktop.
echo   Double-click it to start the app.
echo ============================================
echo.
pause
