import unittest
from unittest.mock import patch

from selenium.common.exceptions import TimeoutException

import web_driver


class _Button:
    def __init__(self, driver, click_sends):
        self.driver = driver
        self.click_sends = click_sends
        self.enter_count = 0

    def is_displayed(self):
        return True

    def is_enabled(self):
        return True

    def click(self):
        if self.click_sends:
            self.driver.sent = True

    def send_keys(self, key):
        if str(key) in {"\ue007", "\ue006"}:
            self.enter_count += 1
            self.driver.sent = True


class _Driver:
    def __init__(self, click_sends):
        self.sent = False
        self.button = _Button(self, click_sends)
        self.switch_to = type("SwitchTo", (), {"active_element": self.button})()

    def find_element(self, _by, _xpath):
        return self.button

    def find_elements(self, _by, xpath):
        if xpath == web_driver._OUTGOING_MESSAGE_XPATH:
            return [object()] if self.sent else []
        if xpath == web_driver._SEND_BUTTON_XPATH:
            return [self.button]
        return []

    def execute_script(self, _script, element):
        element.click()


class _ImmediateWait:
    def __init__(self, driver, _timeout):
        self.driver = driver

    def until(self, condition):
        result = condition(self.driver)
        if result:
            return result
        raise TimeoutException()


class WhatsAppDeliveryTests(unittest.TestCase):
    def test_button_send_requires_new_outgoing_message(self):
        driver = _Driver(click_sends=True)
        with patch.object(web_driver, "WebDriverWait", _ImmediateWait):
            self.assertTrue(web_driver.send_current_whatsapp_message(driver))
        self.assertTrue(driver.sent)
        self.assertEqual(driver.button.enter_count, 0)

    def test_enter_fallback_is_used_once_when_click_did_not_send(self):
        driver = _Driver(click_sends=False)
        with patch.object(web_driver, "WebDriverWait", _ImmediateWait):
            self.assertTrue(web_driver.send_current_whatsapp_message(driver))
        self.assertTrue(driver.sent)
        self.assertEqual(driver.button.enter_count, 1)

    def test_chat_hints_normalize_phone_and_name(self):
        hints = web_driver._chat_hint_variants("+201000000000", "د. محمد أحمد")
        self.assertIn("+201000000000", hints)
        self.assertIn("201000000000", hints)
        self.assertIn("د. محمد أحمد", hints)


if __name__ == "__main__":
    unittest.main()
