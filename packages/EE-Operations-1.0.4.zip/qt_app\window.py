"""PySide6 workspace that presents the existing automation backend."""

import os
from pathlib import Path

from PySide6.QtCore import QTimer, Qt, Signal
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

import drive
import run_history
import settings
import upload_files
import web_driver
import update_service
from version import APP_VERSION
from qt_app.widgets import Card, ExecutionPanel, FilePicker, PageHeader, ToggleRow


MODE_LABELS = {"normal": "طلبات عادية", "logo": "طلبات لوجو"}


def _show_message(parent, title, text, icon=QMessageBox.Information):
    message = QMessageBox(parent)
    message.setWindowTitle(title)
    message.setText(text)
    message.setIcon(icon)
    message.exec()


class OrderPage(QWidget):
    def __init__(self, mode, controller, window):
        super().__init__()
        self.mode = mode
        self.controller = controller
        self.window = window
        label = MODE_LABELS[mode]
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        root = QWidget()
        self.layout = QVBoxLayout(root)
        self.layout.setContentsMargins(30, 26, 30, 30)
        self.layout.setSpacing(18)
        subtitle = "إدارة تقفيل الملفات ورفعها وإرسال رسائلها من شاشة واحدة واضحة."
        self.layout.addWidget(PageHeader(label, subtitle))

        source = Card()
        heading = QLabel("مصدر العمل")
        heading.setObjectName("sectionTitle")
        source.layout.addWidget(heading)
        self.excel = FilePicker("ملف Excel للطلبات")
        self.excel.button.clicked.connect(self._pick_excel)
        source.layout.addWidget(self.excel)
        self.templates = FilePicker("مجلد القوالب")
        self.templates.button.setText("اختيار مجلد")
        self.templates.button.clicked.connect(self._pick_templates)
        source.layout.addWidget(self.templates)
        self.layout.addWidget(source)

        options = Card()
        heading = QLabel("إعدادات التنفيذ")
        heading.setObjectName("sectionTitle")
        options.layout.addWidget(heading)
        self.password = ToggleRow("حماية الملفات بكلمة مرور", "تستخدم إعدادات كلمة المرور الحالية.", True)
        self.image_protection = ToggleRow("حماية بالتحويل إلى صور", "يحوّل صفحات PDF إلى صور قبل الحماية. ألغِه لإنشاء PDF مباشر أسرع وقابل للبحث.", True)
        self.local_only = ToggleRow("إنهاء محلي بدون رفع أو رسائل", "يحفظ الملفات على الجهاز لتعيد رفعها لاحقًا من سجل التشغيل.")
        self.auto_export = ToggleRow("حفظ تقرير الفشل تلقائيًا", "عند وجود طلبات لم تكتمل بعد كل المحاولات.", True)
        self.shutdown = ToggleRow("إغلاق الجهاز بعد اكتمال كل الخطوات", "لن يغلق الجهاز قبل حفظ تقرير الفشل إن وجد.")
        for row in (self.password, self.image_protection, self.local_only, self.auto_export, self.shutdown):
            options.layout.addWidget(row)
        self.layout.addWidget(options)

        self.execution = ExecutionPanel()
        actions = QHBoxLayout()
        self.start = QPushButton("بدء التنفيذ")
        self.start.setObjectName("primary")
        self.pause = QPushButton("إيقاف مؤقت")
        self.resume = QPushButton("استكمال")
        self.export_failed = QPushButton("تصدير الطلبات غير المكتملة")
        self.export_failed.setEnabled(False)
        self.start.clicked.connect(self._start)
        self.pause.clicked.connect(lambda: self.controller.pause(self.mode))
        self.resume.clicked.connect(lambda: self.controller.resume(self.mode))
        self.export_failed.clicked.connect(self._export_failed)
        actions.addWidget(self.start)
        actions.addWidget(self.pause)
        actions.addWidget(self.resume)
        actions.addStretch(1)
        actions.addWidget(self.export_failed)
        self.execution.layout.addLayout(actions)
        self.layout.addWidget(self.execution)
        self.layout.addStretch(1)
        scroll.setWidget(root)
        wrapper = QVBoxLayout(self)
        wrapper.setContentsMargins(0, 0, 0, 0)
        wrapper.addWidget(scroll)

    def _pick_excel(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختيار ملف الطلبات", "", "Excel Files (*.xlsx *.xls)")
        if path:
            self.excel.set_path(path)

    def _pick_templates(self):
        path = QFileDialog.getExistingDirectory(self, "اختيار مجلد القوالب")
        if path:
            self.templates.set_path(path)

    def _start(self):
        if not self.window.work_folder():
            _show_message(self, "مجلد العمل مطلوب", "اختر مجلد العمل من صفحة الإعدادات أولًا.", QMessageBox.Warning)
            return
        if not Path(self.excel.path).is_file() or not Path(self.templates.path).is_dir():
            _show_message(self, "بيانات ناقصة", "اختر ملف Excel صالحًا ومجلد القوالب قبل بدء التشغيل.", QMessageBox.Warning)
            return
        self.controller.set_source(self.mode, self.excel.path, self.templates.path)
        self.controller.start_orders(
            self.mode,
            self.window.work_folder(),
            self.password.toggle.isChecked(),
            self.shutdown.toggle.isChecked(),
            self.auto_export.toggle.isChecked(),
            self.local_only.toggle.isChecked(),
            self.image_protection.toggle.isChecked(),
        )
        self.start.setEnabled(False)
        self.execution.set_status("جارٍ التشغيل", "warning")

    def _export_failed(self):
        try:
            path = upload_files.export_failed_orders(self.mode)
        except Exception as exc:
            _show_message(self, "تعذر التصدير", str(exc), QMessageBox.Warning)
            return
        _show_message(self, "تم التصدير", f"تم حفظ التقرير في:\n{path}")

    def update_progress(self, done, total, stage):
        self.execution.set_progress(done, total, stage)

    def update_status(self, text):
        self.execution.set_status(text, "warning" if "إيقاف" in text else "muted")

    def completed(self):
        self.start.setEnabled(True)
        self.execution.set_status("اكتمل التشغيل", "success")
        self.export_failed.setEnabled(upload_files.has_failed_orders(self.mode))

    def failed(self, error):
        self.start.setEnabled(True)
        self.execution.set_status("توقف التشغيل بسبب خطأ", "danger")
        self.execution.stage.setText(error)
        self.export_failed.setEnabled(upload_files.has_failed_orders(self.mode))


class HistoryPage(QWidget):
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self._runs = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 30)
        layout.setSpacing(16)
        layout.addWidget(PageHeader("سجل التشغيل", "كل تشغيل محفوظ بحالته ومصدره وخياراته، مع إمكانية إعادة إرسال ما لم يكتمل."))
        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("بحث برقم التشغيل أو المجلد...")
        self.mode = QComboBox(); self.mode.addItems(["كل الأنواع", "طلبات عادية", "طلبات لوجو"])
        self.status = QComboBox(); self.status.addItems(["كل الحالات", "مكتمل", "جارٍ", "متوقف", "فشل"])
        refresh = QPushButton("تحديث")
        refresh.clicked.connect(self.refresh)
        self.search.textChanged.connect(self.refresh)
        self.mode.currentIndexChanged.connect(self.refresh)
        self.status.currentIndexChanged.connect(self.refresh)
        filters.addWidget(self.search, 1); filters.addWidget(self.mode); filters.addWidget(self.status); filters.addWidget(refresh)
        layout.addLayout(filters)
        body = QHBoxLayout()
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["الحالة", "النوع", "مجلد العمل", "المرحلة", "بدأ", "رقم التشغيل"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self._details)
        body.addWidget(self.table, 3)
        detail = Card(); detail.setMinimumWidth(310)
        title = QLabel("تفاصيل التشغيل"); title.setObjectName("sectionTitle")
        self.detail = QLabel("اختر تشغيلًا لعرض التفاصيل."); self.detail.setObjectName("muted"); self.detail.setWordWrap(True)
        note = QLabel("السجل للمتابعة والقراءة فقط. استخدم صفحة إعادة الرفع والإرسال للعمليات الجديدة.")
        note.setObjectName("muted"); note.setWordWrap(True)
        detail.layout.addWidget(title); detail.layout.addWidget(self.detail); detail.layout.addWidget(note); detail.layout.addStretch(1)
        body.addWidget(detail, 1)
        layout.addLayout(body, 1)
        self.refresh()

    def refresh(self):
        query = self.search.text().strip().lower()
        mode = {"طلبات عادية": "normal", "طلبات لوجو": "logo"}.get(self.mode.currentText())
        states = {"مكتمل": "completed", "جارٍ": "running", "متوقف": "paused", "فشل": "failed"}
        wanted = states.get(self.status.currentText())
        self._runs = [item for item in run_history.list_runs() if (not mode or item.get("mode") == mode) and (not wanted or item.get("status") == wanted)]
        if query:
            self._runs = [item for item in self._runs if query in " ".join(map(str, (item.get("id"), item.get("work_folder"), item.get("stage")))).lower()]
        self.table.setRowCount(len(self._runs))
        for row, item in enumerate(self._runs):
            values = [item.get("status", ""), MODE_LABELS.get(item.get("mode"), item.get("mode", "")), item.get("work_folder", ""), item.get("stage", ""), item.get("created_at", ""), item.get("id", "")]
            for col, value in enumerate(values): self.table.setItem(row, col, QTableWidgetItem(str(value)))

    def _details(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows: return
        item = self._runs[rows[0].row()]
        self.detail.setText("\n".join([
            f"النوع: {MODE_LABELS.get(item.get('mode'), item.get('mode'))}",
            f"الحالة: {item.get('status', '')}",
            f"المجلد: {item.get('work_folder', '')}",
            f"المرحلة: {item.get('stage', '')}",
            f"المصدر: {item.get('source_excel', '')}",
        ]))


class MessagesPage(QWidget):
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 30)
        layout.setSpacing(18)
        layout.addWidget(PageHeader("رسائل WhatsApp", "إرسال الرسائل المستقلة من ملف Excel. اللصق والتحرير متاحان مباشرة داخل النص."))
        card = Card()
        self.file = FilePicker("ملف جهات الاتصال", "اختيار ملف Excel")
        self.file.button.clicked.connect(self._pick)
        card.layout.addWidget(self.file)
        label = QLabel("نص الرسالة"); label.setObjectName("sectionTitle")
        self.message = QTextEdit()
        self.message.setPlaceholderText("اكتب الرسالة هنا. يمكنك استخدام أسماء الأعمدة بين أقواس مثل {الاسم}.")
        self.message.setMinimumHeight(180)
        self.status = QLabel("جاهز للإرسال"); self.status.setObjectName("muted")
        self.progress = ExecutionPanel("تقدم الإرسال")
        self.progress.layout.setContentsMargins(0, 10, 0, 0)
        send = QPushButton("إرسال الرسائل")
        send.setObjectName("primary")
        send.clicked.connect(self._send)
        card.layout.addWidget(label); card.layout.addWidget(self.message); card.layout.addWidget(self.status); card.layout.addWidget(self.progress); card.layout.addWidget(send)
        layout.addWidget(card); layout.addStretch(1)

    def _pick(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختيار ملف الرسائل", "", "Excel Files (*.xlsx *.xls)")
        if path: self.file.set_path(path)

    def _send(self):
        if not Path(self.file.path).is_file() or not self.message.toPlainText().strip():
            _show_message(self, "بيانات ناقصة", "اختر ملف Excel واكتب نص الرسالة قبل الإرسال.", QMessageBox.Warning)
            return
        self.status.setText("جارٍ تجهيز الإرسال...")
        self.progress.set_status("جارٍ الإرسال", "warning")
        self.controller.send_custom_messages(self.file.path, self.message.toPlainText())


class LandingPage(QWidget):
    def __init__(self, window):
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)
        layout.setContentsMargins(42, 42, 42, 42)
        layout.setSpacing(22)
        layout.addStretch(1)
        hero = Card(); hero.setObjectName("hero")
        title = QLabel("مركز إدارة الطلبات") ; title.setObjectName("heroTitle")
        text = QLabel("مساحة عمل موحدة لتقفيل الملفات، متابعة الرفع، وإرسال رسائل WhatsApp بثقة ووضوح.")
        text.setObjectName("heroText"); text.setWordWrap(True)
        begin = QPushButton("ابدأ بالطلبات العادية"); begin.setObjectName("primary"); begin.clicked.connect(lambda: window.open_page("orders"))
        hero.layout.addWidget(title); hero.layout.addWidget(text); hero.layout.addSpacing(8); hero.layout.addWidget(begin)
        layout.addWidget(hero, 0, Qt.AlignHCenter)
        cards = QHBoxLayout()
        for title_text, detail, key in (
            ("طلبات عادية", "تشغيل تقفيل ورفع الطلبات الأساسية.", "orders"),
            ("طلبات لوجو", "تشغيل الملفات المخصصة باللوجو.", "logo"),
            ("إعادة الرفع", "رفع الملفات المحلية غير المكتملة ثم إرسالها.", "retry"),
        ):
            card = Card(); heading = QLabel(title_text); heading.setObjectName("sectionTitle")
            description = QLabel(detail); description.setObjectName("muted"); description.setWordWrap(True)
            button = QPushButton("فتح"); button.clicked.connect(lambda checked=False, page=key: window.open_page(page))
            card.layout.addWidget(heading); card.layout.addWidget(description); card.layout.addStretch(1); card.layout.addWidget(button)
            cards.addWidget(card)
        layout.addLayout(cards)
        layout.addStretch(1)


class RetryPage(QWidget):
    def __init__(self, controller, window):
        super().__init__()
        self.controller, self.window = controller, window
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        root = QWidget(); layout = QVBoxLayout(root); layout.setContentsMargins(30, 26, 30, 30); layout.setSpacing(18)
        layout.addWidget(PageHeader("إعادة الرفع والإرسال", "يفحص الطلبات الموجودة على الجهاز، ويرفع الناقص على Drive ثم يرسل رسائله. لا يعتمد على اختيار من سجل التشغيل."))
        setup = Card(); heading = QLabel("مصدر إعادة الرفع"); heading.setObjectName("sectionTitle"); setup.layout.addWidget(heading)
        self.file = FilePicker("ملف Excel الأصلي"); self.file.button.clicked.connect(self._pick); setup.layout.addWidget(self.file)
        self.mode = QComboBox(); self.mode.addItem("طلبات عادية", "normal"); self.mode.addItem("طلبات لوجو", "logo")
        setup.layout.addWidget(QLabel("نوع الطلبات")); setup.layout.addWidget(self.mode)
        layout.addWidget(setup)
        self.execution = ExecutionPanel("حالة إعادة الرفع والإرسال")
        actions = QHBoxLayout(); self.start = QPushButton("فحص وبدء إعادة الرفع"); self.start.setObjectName("primary")
        self.pause = QPushButton("إيقاف مؤقت"); self.resume = QPushButton("استكمال")
        self.start.clicked.connect(self._start); self.pause.clicked.connect(lambda: controller.pause("retry")); self.resume.clicked.connect(lambda: controller.resume("retry"))
        actions.addWidget(self.start); actions.addWidget(self.pause); actions.addWidget(self.resume); actions.addStretch(1)
        self.execution.layout.addLayout(actions); layout.addWidget(self.execution); layout.addStretch(1)
        scroll.setWidget(root); outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0); outer.addWidget(scroll)

    def _pick(self):
        path, _ = QFileDialog.getOpenFileName(self, "اختيار ملف الطلبات", "", "Excel Files (*.xlsx *.xls)")
        if path: self.file.set_path(path)

    def _start(self):
        if not Path(self.file.path).is_file() or not self.window.work_folder():
            _show_message(self, "بيانات ناقصة", "اختر ملف Excel ومجلد العمل قبل البدء.", QMessageBox.Warning); return
        self.start.setEnabled(False); self.execution.set_status("جارٍ فحص الملفات المحلية وDrive...", "warning")
        self.controller.retry_delivery_direct(self.file.path, settings.get_business_root_folder(), self.window.work_folder(), self.mode.currentData())


class SettingsPage(QWidget):
    def __init__(self, window):
        super().__init__()
        self.window = window
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 30)
        layout.setSpacing(18)
        layout.addWidget(PageHeader("الإعدادات", "إعدادات المسارات والرسائل والجلسات. لا تغيّر هذه الصفحة طريقة معالجة الملفات."))
        paths = Card(); title = QLabel("مسارات العمل"); title.setObjectName("sectionTitle")
        self.root = QLineEdit(settings.get_business_root_folder() or "")
        self.orders = QLineEdit(settings.get_orders_subdir())
        self.logo = QLineEdit(settings.get_logo_orders_subdir())
        for text, control in (("مجلد Drive الرئيسي", self.root), ("مجلد الطلبات العادية", self.orders), ("مجلد طلبات اللوجو", self.logo)):
            paths.layout.addWidget(QLabel(text)); paths.layout.addWidget(control)
        paths.layout.addWidget(QLabel("مجلد العمل الحالي"))
        self.work_folder = QComboBox()
        self._refresh_work_folder_options()
        paths.layout.addWidget(self.work_folder)
        save = QPushButton("حفظ المسارات"); save.setObjectName("primary"); save.clicked.connect(self._save)
        paths.layout.addWidget(save); layout.addWidget(paths)
        template = Card(); title = QLabel("الرسالة الافتراضية للمعلم"); title.setObjectName("sectionTitle")
        self.teacher_template = QTextEdit(); self.teacher_template.setPlainText(settings.get_teacher_whatsapp_template() or ""); self.teacher_template.setMinimumHeight(130)
        save_template = QPushButton("حفظ الرسالة"); save_template.clicked.connect(lambda: settings.set_teacher_whatsapp_template(self.teacher_template.toPlainText()))
        template.layout.addWidget(title); template.layout.addWidget(self.teacher_template); template.layout.addWidget(save_template); layout.addWidget(template)
        sessions = Card(); title = QLabel("الجلسات والسجل"); title.setObjectName("sectionTitle")
        self.dark_mode = ToggleRow("الوضع الداكن", "يتم حفظ الاختيار ويفعّل مباشرة.", settings.get_theme_preference() == "dark")
        self.dark_mode.toggle.toggled.connect(lambda enabled: self.window.apply_theme("dark" if enabled else "light"))
        change_drive = QPushButton("تغيير حساب Google Drive"); change_drive.clicked.connect(lambda: self.window.run_background(drive.switch_google_account, "تم فتح إعداد حساب Drive."))
        reset_wa = QPushButton("إعادة ضبط جلسة WhatsApp"); reset_wa.clicked.connect(lambda: self.window.run_background(web_driver.reset_whatsapp_session, "تمت إعادة ضبط جلسة WhatsApp."))
        logs = QPushButton("عرض السجل التقني"); logs.clicked.connect(self.window.show_logs)
        updates = QPushButton(f"التحقق من التحديثات (الإصدار {APP_VERSION})"); updates.clicked.connect(self.window.check_updates)
        sessions.layout.addWidget(title); sessions.layout.addWidget(self.dark_mode); sessions.layout.addWidget(updates); sessions.layout.addWidget(change_drive); sessions.layout.addWidget(reset_wa); sessions.layout.addWidget(logs); layout.addWidget(sessions); layout.addStretch(1)

    def _save(self):
        settings.set_business_root_folder(self.root.text().strip())
        settings.set_orders_subdir(self.orders.text().strip())
        settings.set_logo_orders_subdir(self.logo.text().strip())
        settings.set_work_folder(self.work_folder.currentText())
        self._refresh_work_folder_options()
        _show_message(self, "تم الحفظ", "تم حفظ المسارات ومجلد العمل الحالي.")

    def _refresh_work_folder_options(self):
        current = settings.get_work_folder()
        root = self.root.text().strip() or settings.get_business_root_folder()
        self.work_folder.clear()
        self.work_folder.addItems(settings.list_work_folders(root))
        index = self.work_folder.findText(current)
        if index >= 0:
            self.work_folder.setCurrentIndex(index)


class MainWindow(QMainWindow):
    update_result = Signal(object)
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.setWindowTitle("EE Operations")
        self.setMinimumSize(820, 560)
        self.resize(1380, 860)
        host = QWidget(); self.setCentralWidget(host)
        outer = QHBoxLayout(host); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        self.sidebar = QFrame(); self.sidebar.setObjectName("sidebar"); self.sidebar.setMinimumWidth(190); self.sidebar.setMaximumWidth(250)
        side = QVBoxLayout(self.sidebar); side.setContentsMargins(20, 28, 20, 20); side.setSpacing(8)
        brand = QLabel("EE\nOperations"); brand.setObjectName("brand"); side.addWidget(brand); side.addSpacing(24)
        self.nav = []
        for key, title in (("home", "الرئيسية"), ("orders", "الطلبات العادية"), ("logo", "طلبات اللوجو"), ("retry", "إعادة الرفع والإرسال"), ("history", "سجل التشغيل"), ("messages", "رسائل WhatsApp"), ("settings", "الإعدادات")):
            button = QPushButton(title); button.setObjectName("nav"); button.clicked.connect(lambda checked=False, name=key: self.open_page(name)); side.addWidget(button); self.nav.append((key, button))
        side.addStretch(1)
        version = QLabel("إصدار سطح المكتب\nواجهة تشغيل منظمة")
        version.setObjectName("sidebarNote"); side.addWidget(version)
        outer.addWidget(self.sidebar)
        content = QWidget(); right = QVBoxLayout(content); right.setContentsMargins(0, 0, 0, 0); right.setSpacing(0)
        bar = QFrame(); bar.setObjectName("topbar"); top = QHBoxLayout(bar); top.setContentsMargins(30, 14, 30, 14)
        header_title = QLabel("EE Operations")
        header_title.setObjectName("sectionTitle")
        header_subtitle = QLabel("مركز إدارة الطلبات")
        header_subtitle.setObjectName("muted")
        heading = QVBoxLayout(); heading.setSpacing(1); heading.addWidget(header_title); heading.addWidget(header_subtitle)
        top.addLayout(heading)
        top.addStretch(1)
        self.active = QLabel("العمليات النشطة: 0"); self.active.setObjectName("muted"); top.addWidget(self.active)
        right.addWidget(bar)
        self.pages = QStackedWidget(); right.addWidget(self.pages, 1); outer.addWidget(content, 1)
        self.home_page = LandingPage(self)
        self.orders_page = OrderPage("normal", controller, self)
        self.logo_page = OrderPage("logo", controller, self)
        self.retry_page = RetryPage(controller, self)
        self.history_page = HistoryPage(controller)
        self.messages_page = MessagesPage(controller)
        self.settings_page = SettingsPage(self)
        settings_scroll = QScrollArea(); settings_scroll.setWidgetResizable(True); settings_scroll.setFrameShape(QFrame.NoFrame); settings_scroll.setWidget(self.settings_page)
        self.page_map = {"home": self.home_page, "orders": self.orders_page, "logo": self.logo_page, "retry": self.retry_page, "history": self.history_page, "messages": self.messages_page, "settings": settings_scroll}
        for page in self.page_map.values(): self.pages.addWidget(page)
        self.open_page("home")
        controller.progress.connect(self._progress)
        controller.status.connect(self._status)
        controller.completed.connect(self._completed)
        controller.failed.connect(self._failed)
        self.update_result.connect(self._show_update_result)
        self.timer = QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(1500)

    def work_folder(self):
        return settings.get_work_folder()

    def open_page(self, key):
        self.pages.setCurrentWidget(self.page_map[key])
        for name, button in self.nav:
            button.setProperty("active", name == key)
            button.style().unpolish(button); button.style().polish(button)
        if key == "history": self.history_page.refresh()

    def _progress(self, mode, done, total, stage):
        if mode == "messages":
            self.messages_page.progress.set_progress(done, total, stage)
        elif mode == "retry":
            self.retry_page.execution.set_progress(done, total, stage)
        else:
            page = self.orders_page if mode == "normal" else self.logo_page
            page.update_progress(done, total, stage)

    def _status(self, mode, text):
        if mode in ("normal", "logo"):
            (self.orders_page if mode == "normal" else self.logo_page).update_status(text)
        elif mode == "retry": self.retry_page.execution.set_status(text, "warning")
        elif mode == "messages": self.messages_page.status.setText(text)

    def _completed(self, mode):
        if mode in ("normal", "logo"): (self.orders_page if mode == "normal" else self.logo_page).completed()
        elif mode == "retry":
            self.retry_page.start.setEnabled(True); self.retry_page.execution.set_status("اكتملت إعادة الرفع والإرسال", "success")
        elif mode == "messages": self.messages_page.status.setText("اكتمل إرسال الرسائل.")
        self.history_page.refresh()

    def _failed(self, mode, error):
        if mode in ("normal", "logo"): (self.orders_page if mode == "normal" else self.logo_page).failed(error)
        elif mode == "retry":
            self.retry_page.start.setEnabled(True); self.retry_page.execution.set_status("توقفت إعادة الرفع", "danger"); self.retry_page.execution.stage.setText(error)
        elif mode == "messages": self.messages_page.status.setText(f"تعذر الإرسال: {error}")
        self.history_page.refresh()

    def apply_theme(self, theme):
        from qt_app.tokens import stylesheet
        settings.set_theme_preference(theme)
        QApplication.instance().setStyleSheet(stylesheet(theme))

    def check_updates(self):
        import threading
        self.update_result.emit({"checking": True})
        def check():
            try:
                self.update_result.emit({"manifest": update_service.check_for_update()})
            except Exception as exc:
                self.update_result.emit({"error": str(exc)})
        threading.Thread(target=check, daemon=True).start()

    def _show_update_result(self, result):
        if result.get("checking"):
            self.statusBar().showMessage("جارٍ التحقق من التحديثات...")
            return
        if result.get("error"):
            _show_message(self, "تعذر التحقق من التحديث", result["error"], QMessageBox.Warning)
            return
        manifest = result["manifest"]
        if not manifest.get("is_newer"):
            _show_message(self, "التطبيق محدث", f"أنت تستخدم أحدث إصدار متاح: {APP_VERSION}")
            return
        message = QMessageBox(self)
        message.setWindowTitle("تحديث متاح")
        message.setText(f"يتوفر إصدار {manifest['version']}. هل تريد تنزيله وتثبيته الآن؟")
        message.setInformativeText(manifest.get("notes", "سيتم الاحتفاظ بإعداداتك وجلساتك المحلية."))
        message.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        if message.exec() != QMessageBox.Yes:
            return
        try:
            self.statusBar().showMessage("جارٍ تنزيل التحديث والتحقق منه...")
            package = update_service.download_update(manifest)
            update_service.schedule_install(package, Path(__file__).resolve().parents[1])
            QApplication.instance().quit()
        except Exception as exc:
            _show_message(self, "تعذر تثبيت التحديث", str(exc), QMessageBox.Warning)

    def _tick(self):
        active = len([run for run in run_history.list_runs() if run.get("status") in ("running", "paused")])
        self.active.setText(f"العمليات النشطة: {active}")

    def run_background(self, func, success_text):
        import threading
        def execute():
            try:
                func()
                QTimer.singleShot(0, lambda: _show_message(self, "تم", success_text))
            except Exception as exc:
                QTimer.singleShot(0, lambda: _show_message(self, "تعذر التنفيذ", str(exc), QMessageBox.Warning))
        threading.Thread(target=execute, daemon=True).start()

    def show_logs(self):
        dialog = QDialog(self); dialog.setWindowTitle("السجل التقني"); dialog.resize(900, 560)
        layout = QVBoxLayout(dialog); text = QTextEdit(); text.setReadOnly(True); layout.addWidget(text)
        actions = QHBoxLayout()
        copied = QLabel(""); copied.setObjectName("muted")
        copy = QPushButton("نسخ السجل التقني")
        def copy_log():
            QApplication.clipboard().setText(text.toPlainText())
            copied.setText("تم نسخ السجل.")
        copy.clicked.connect(copy_log)
        actions.addWidget(copy); actions.addWidget(copied); actions.addStretch(1)
        layout.addLayout(actions)
        path = Path(__file__).resolve().parents[1] / "app_log.txt"
        try: text.setPlainText(path.read_text(encoding="utf-8", errors="replace")[-30000:])
        except OSError: text.setPlainText("لا يوجد سجل تقني محفوظ حتى الآن.")
        dialog.exec()
