# Publishing Updates

1. Change `APP_VERSION` in `version.py`.
2. Create a ZIP containing the app files only. Never include `venv`, `token.json`, `user_settings.json`, `.run_history`, or `client_secret_*.json`.
3. Calculate the ZIP SHA-256 and place it with the GitHub Release asset URL in `manifest.json` in `EE-Operations-Updates`.
4. Publish the ZIP as a GitHub Release asset, then push the new `manifest.json`.

Users choose **Check for updates** from Settings. The app verifies the SHA-256 before replacing code, preserves their local authentication and settings, installs any new dependencies, and restarts.
