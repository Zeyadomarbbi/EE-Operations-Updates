"""Safe, opt-in updater fed by the public EE Operations updates repository."""

import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile
from pathlib import Path

from version import APP_VERSION


UPDATE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/Zeyadomarbbi/EE-Operations-Updates/main/manifest.json"
)
PRESERVED_ITEMS = {
    "venv", "token.json", "user_settings.json", ".run_history",
    ".drive_upload_sessions.json",
}


def _version_key(value):
    return tuple(int(part) for part in str(value).split(".") if part.isdigit())


def check_for_update(timeout=8):
    """Return public release metadata only when it is newer than this build."""
    request = urllib.request.Request(UPDATE_MANIFEST_URL, headers={"User-Agent": "EE-Operations-Updater"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        manifest = json.loads(response.read().decode("utf-8"))
    required = {"version", "download_url", "sha256"}
    missing = required.difference(manifest)
    if missing:
        raise ValueError(f"ملف التحديث لا يحتوي على: {', '.join(sorted(missing))}")
    manifest["is_newer"] = _version_key(manifest["version"]) > _version_key(APP_VERSION)
    return manifest


def download_update(manifest, progress_callback=None):
    """Download a verified release ZIP without touching the installed app yet."""
    target_dir = Path(tempfile.mkdtemp(prefix="ee_operations_update_"))
    target = target_dir / "update.zip"
    request = urllib.request.Request(manifest["download_url"], headers={"User-Agent": "EE-Operations-Updater"})
    with urllib.request.urlopen(request, timeout=30) as response, open(target, "wb") as output:
        total = int(response.headers.get("Content-Length", 0))
        downloaded = 0
        while True:
            chunk = response.read(1024 * 256)
            if not chunk:
                break
            output.write(chunk)
            downloaded += len(chunk)
            if progress_callback:
                progress_callback(downloaded, total)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    if digest.lower() != str(manifest["sha256"]).lower():
        raise ValueError("فشل التحقق الأمني من ملف التحديث. لم يتم تثبيته.")
    return target


def schedule_install(zip_path, app_directory):
    """Create a separate Windows script that updates files after the app exits."""
    app_directory = Path(app_directory).resolve()
    staging = Path(tempfile.mkdtemp(prefix="ee_operations_apply_"))
    extract_dir = staging / "files"
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(extract_dir)
    children = [item for item in extract_dir.iterdir()]
    source_dir = children[0] if len(children) == 1 and children[0].is_dir() else extract_dir
    script = staging / "apply_update.cmd"
    script.write_text(
        "@echo off\r\n"
        "timeout /t 2 /nobreak >nul\r\n"
        f"robocopy \"{source_dir}\" \"{app_directory}\" /E /R:2 /W:1 /XD venv .run_history .updates /XF token.json user_settings.json client_secret_*.json .drive_upload_sessions.json >nul\r\n"
        f"if exist \"{app_directory / 'venv' / 'Scripts' / 'python.exe'}\" \"{app_directory / 'venv' / 'Scripts' / 'python.exe'}\" -m pip install -r \"{app_directory / 'requirements.lock.txt'}\" >nul 2>&1\r\n"
        f"start \"\" wscript.exe \"{app_directory / 'run_app_silent.vbs'}\"\r\n"
        "del \"%~f0\"\r\n",
        encoding="ascii",
    )
    subprocess.Popen(["cmd.exe", "/c", str(script)], creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
