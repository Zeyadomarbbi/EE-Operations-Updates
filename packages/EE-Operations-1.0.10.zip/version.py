"""Single source of truth for the desktop application's release version."""

APP_VERSION = "1.0.10"
