"""Small, shared display rules used by every WhatsApp workflow."""

import re


# The spreadsheets can contain roles beyond the common أ./د./م. forms. Any
# standalone token ending in a period is treated as the supplied title.
_TITLE = re.compile(r"^\S+\.$")


def short_teacher_name(value):
    """Return only the first name, keeping one existing dotted title if present."""
    parts = str(value or "").strip().split()
    if not parts:
        return "أ."

    if _TITLE.fullmatch(parts[0]):
        title = parts.pop(0)
    else:
        title = "أ."
    return title if not parts else f"{title} {parts[0]}"
