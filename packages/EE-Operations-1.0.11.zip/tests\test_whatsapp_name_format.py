import unittest

import pandas as pd

import msgs
import upload_files
from name_format import render_teacher_name_placeholders, short_teacher_name


class WhatsAppNameFormatTests(unittest.TestCase):
    def test_short_name_keeps_only_first_name_and_title(self):
        cases = {
            "محمد أحمد علي": "أ. محمد",
            "د. محمد أحمد": "د. محمد",
            "م. أحمد علي": "م. أحمد",
            "أ. علي حسن": "أ. علي",
            "أستاذ. سامي عبد الله": "أستاذ. سامي",
            "": "أ.",
        }
        for source, expected in cases.items():
            with self.subTest(source=source):
                self.assertEqual(short_teacher_name(source), expected)

    def test_old_title_templates_do_not_duplicate_the_title(self):
        self.assertEqual(
            render_teacher_name_placeholders("السلام عليكم أ. {الاسم}", "د. محمد أحمد"),
            "السلام عليكم د. محمد",
        )
        self.assertEqual(
            render_teacher_name_placeholders("السلام عليكم د. {اسم المعلم}", "د. محمد أحمد"),
            "السلام عليكم د. محمد",
        )

    def test_direct_messages_ignore_raw_name_columns(self):
        rows = pd.DataFrame({
            "اسم المعلم": ["د. محمد أحمد"],
            "الاسم": ["محمد أحمد بالكامل"],
            "رقم الواتس": ["01000000000"],
        })
        message = msgs._render_message("السلام عليكم أ. {اسم المعلم} / {الاسم}", rows)
        self.assertEqual(message, "السلام عليكم د. محمد / د. محمد")

    def test_delivery_template_reserves_both_name_placeholders(self):
        rows = pd.DataFrame({
            "اسم المعلم": ["م. أحمد علي"],
            "الاسم": ["أحمد علي بالكامل"],
            "كود العميل": ["1"],
            "الرابط": ["https://example.test/order"],
        })
        original = upload_files.settings.get_teacher_whatsapp_template
        upload_files.settings.get_teacher_whatsapp_template = lambda: "السلام عليكم أ. {اسم المعلم} / {الاسم}"
        try:
            message = upload_files.build_teacher_whatsapp_message("م. أحمد علي", rows, "شغل 2026", False)
        finally:
            upload_files.settings.get_teacher_whatsapp_template = original
        self.assertEqual(message, "السلام عليكم م. أحمد / م. أحمد")


if __name__ == "__main__":
    unittest.main()
