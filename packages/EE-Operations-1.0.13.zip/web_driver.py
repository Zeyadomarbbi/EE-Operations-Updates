from selenium import webdriver
from selenium.webdriver.edge.service import Service
from selenium.webdriver.edge.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import SessionNotCreatedException, TimeoutException, StaleElementReferenceException
from webdriver_manager.microsoft import EdgeChromiumDriverManager
import os
import threading
import time

import config
import settings


driver = None
_whatsapp_ready = False
driver_lock = threading.RLock()
_send_rate_lock = threading.Lock()
_last_confirmed_send_at = 0.0

_SEND_BUTTON_XPATH = "//button[contains(@aria-label, 'إرسال') or contains(@aria-label, 'Send')]"
_OUTGOING_MESSAGE_XPATH = "//*[contains(@class, 'message-out')]"


def _chat_hint_variants(*hints):
    """Normalize caller supplied phone/name hints before matching sidebar rows."""
    variants = set()
    for hint in hints:
        value = str(hint or "").strip()
        if not value:
            continue
        variants.add(value)
        variants.add(value.lstrip("+"))
        variants.add(" ".join(value.split()))
    return variants


def _find_chat_row(d, hints):
    """Find an existing sidebar chat by phone or display-name without opening it."""
    variants = _chat_hint_variants(*hints)
    if not variants:
        return None
    try:
        rows = d.find_elements(
            By.XPATH,
            "//*[@id='pane-side']//*[(@role='row' or @role='listitem')]",
        )
        for row in rows:
            titles = row.find_elements(By.XPATH, ".//*[@title]")
            labels = [item.get_attribute("title") for item in titles]
            labels.append(row.get_attribute("aria-label"))
            for label in labels:
                label = str(label or "").strip()
                compact = label.lstrip("+")
                if label in variants or compact in variants:
                    return row
    except Exception:
        pass
    return None


def capture_chat_unread_state(d, *chat_hints):
    """Capture unread state before navigating, when WhatsApp may mark it read."""
    row = _find_chat_row(d, chat_hints)
    if row is None:
        return {"hints": _chat_hint_variants(*chat_hints), "was_unread": False}
    try:
        unread = bool(row.find_elements(By.XPATH,
            ".//*[@data-icon='unread-count' or contains(@aria-label, 'unread') or contains(@aria-label, 'غير مقروء')]"))
        return {"hints": _chat_hint_variants(*chat_hints), "was_unread": unread}
    except Exception:
        return {"hints": _chat_hint_variants(*chat_hints), "was_unread": False}


def _installed_edge_version():
    """Returns the installed Edge version so its driver stays update-compatible."""
    edge_paths = [
        os.path.join(os.environ.get("PROGRAMFILES(X86)", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("PROGRAMFILES", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Edge", "Application", "msedge.exe"),
    ]
    for edge_path in edge_paths:
        if os.path.isfile(edge_path):
            try:
                import win32api
                version = win32api.GetFileVersionInfo(edge_path, "\\")
                return ".".join(
                    str((version[key] >> shift) & 0xFFFF)
                    for key in ("FileVersionMS", "FileVersionLS")
                    for shift in (16, 0)
                )
            except Exception as error:
                print(f"[EDGE] Could not read installed Edge version: {error}")
    return None


def _installed_edge_path():
    """Return Edge's executable so Selenium never starts a stale browser binary."""
    roots = (
        os.environ.get("PROGRAMFILES(X86)", ""),
        os.environ.get("PROGRAMFILES", ""),
        os.environ.get("LOCALAPPDATA", ""),
    )
    for root in roots:
        edge_path = os.path.join(root, "Microsoft", "Edge", "Application", "msedge.exe")
        if os.path.isfile(edge_path):
            return edge_path
    return None


def _build_edge_options(user_data_dir, profile_directory=None):
    edge_options = Options()
    edge_options.add_experimental_option("detach", True)
    edge_options.add_experimental_option("excludeSwitches", ["enable-logging"])
    edge_options.add_argument("--no-first-run")
    edge_options.add_argument("--no-default-browser-check")
    edge_options.add_argument("--disable-backgrounding-occluded-windows")
    edge_options.add_argument("--disable-dev-shm-usage")
    edge_options.add_argument("--disable-gpu")
    edge_options.add_argument("--remote-debugging-port=0")
    edge_options.add_argument(f"--user-data-dir={user_data_dir}")
    edge_path = _installed_edge_path()
    if edge_path:
        edge_options.binary_location = edge_path
    if profile_directory:
        edge_options.add_argument(f"--profile-directory={profile_directory}")
    return edge_options


def _create_edge_driver():
    edge_version = _installed_edge_version()
    try:
        manager = EdgeChromiumDriverManager(driver_version=edge_version) if edge_version else EdgeChromiumDriverManager()
        service = Service(manager.install())
        print(f"[EDGE] Browser version: {edge_version or 'unknown'} | matching driver selected.")
    except Exception as manager_error:
        # Selenium Manager is maintained with Selenium and can recover if the
        # webdriver-manager cache is stale after a browser auto-update.
        print(f"[EDGE] Matching driver download failed: {manager_error}. Trying Selenium Manager.")
        service = None
    profile_candidates = [
        {
            "user_data_dir": config.EDGE_USER_DATA_DIR,
            "profile_directory": getattr(config, "EDGE_PROFILE_DIRECTORY", None),
            "label": "البروفايل الأساسي",
        },
        {
            "user_data_dir": config.EDGE_AUTOMATION_USER_DATA_DIR,
            "profile_directory": None,
            "label": "بروفايل الأتمتة الاحتياطي",
        },
    ]

    last_error = None
    for candidate in profile_candidates:
        try:
            os.makedirs(candidate["user_data_dir"], exist_ok=True)
            edge_options = _build_edge_options(
                candidate["user_data_dir"],
                candidate["profile_directory"],
            )
            created_driver = (
                webdriver.Edge(service=service, options=edge_options)
                if service
                else webdriver.Edge(options=edge_options)
            )
            print(f"✅ تم تشغيل المتصفح بنجاح باستخدام {candidate['label']}.")
            return created_driver
        except Exception as e:
            last_error = e
            print(f"⚠️ تعذر تشغيل Edge باستخدام {candidate['label']}: {e}")

    # A cached webdriver-manager binary may no longer match an Edge that has
    # auto-updated. Selenium Manager has its own version resolver, so retry it
    # before surfacing a session-not-created error to the user.
    for candidate in profile_candidates:
        try:
            edge_options = _build_edge_options(
                candidate["user_data_dir"],
                candidate["profile_directory"],
            )
            created_driver = webdriver.Edge(options=edge_options)
            print(f"[EDGE] Selenium Manager recovered the session using {candidate['label']}.")
            return created_driver
        except Exception as error:
            last_error = error
            print(f"[EDGE] Selenium Manager retry failed with {candidate['label']}: {error}")

    raise RuntimeError(
        "تعذر إنشاء جلسة Edge بعد إعادة المحاولة التلقائية. "
        "أغلق كل نوافذ Edge ثم أعد ضبط جلسة WhatsApp من الإعدادات. "
        f"التفاصيل: {last_error}"
    ) from last_error


def ensure_whatsapp_ready():
    global _whatsapp_ready
    started_at = time.perf_counter()
    with driver_lock:
        d = initialize_driver()
        if d is None:
            return None
        if not _whatsapp_ready:
            d.get(config.WHATSAPP_WEB_URL)
            wait_for_whatsapp_login()
            _whatsapp_ready = True
        elapsed = time.perf_counter() - started_at
        print(f"⏱️ تجهيز واتساب ويب: {elapsed:.2f} ث")
        return d


def reset_whatsapp_session():
    global _whatsapp_ready
    with driver_lock:
        d = initialize_driver()
        if d is None:
            return None
        _whatsapp_ready = False
        d.get(config.WHATSAPP_WEB_URL)
        return d


def initialize_driver():
    global driver
    if driver is None:
        driver = _create_edge_driver()
    else:
        try:
            driver.current_url
            print("⚠️ المتصفح يعمل بالفعل!")
        except Exception:
            try:
                driver.quit()
            except Exception:
                pass
            driver = _create_edge_driver()
    return driver


def wait_for_whatsapp_login():
    if driver is None:
        print("⚠️ المتصفح غير مُشغل! تأكد من تشغيل initialize_driver() أولًا.")
        return

    logged_in_selectors = [
        "div[contenteditable='true']",
        "#pane-side",
        "div[aria-label='Chat list']",
        "div[aria-label='قائمة الدردشات']",
    ]

    print("📢 يرجى تسجيل الدخول إلى واتساب ويب... الكود ينتظر تسجيل الدخول.")
    start = time.time()
    last_heartbeat = start

    while True:
        for selector in logged_in_selectors:
            try:
                if driver.find_elements(By.CSS_SELECTOR, selector):
                    elapsed = time.time() - start
                    print("✅ تم تسجيل الدخول بنجاح!")
                    print(f"⏱️ زمن تسجيل دخول واتساب: {elapsed:.2f} ث")
                    return
            except Exception:
                pass

        if time.time() - last_heartbeat >= 10:
            elapsed = int(time.time() - start)
            print(f"⏳ لسه مستني تسجيل الدخول لواتساب... ({elapsed} ثانية). لو الصفحة مش بتحميل، تأكد إن كل نوافذ Edge التانية مقفولة.")
            last_heartbeat = time.time()

        time.sleep(2)


def send_current_whatsapp_message(d, timeout=25):
    """Send once and require proof that a new outgoing WhatsApp message exists."""
    global _last_confirmed_send_at
    # This lock makes the configured delay global across normal, logo, retry,
    # and direct-message jobs, rather than merely delaying one local loop.
    with _send_rate_lock:
        delay = settings.get_whatsapp_delay_seconds()
        remaining = delay - (time.monotonic() - _last_confirmed_send_at)
        if remaining > 0:
            print(f"[WHATSAPP] Waiting {remaining:.1f}s before the next confirmed send.")
            time.sleep(remaining)

        send_button = WebDriverWait(d, timeout).until(
            EC.element_to_be_clickable((By.XPATH, _SEND_BUTTON_XPATH))
        )
        before_count = len(d.find_elements(By.XPATH, _OUTGOING_MESSAGE_XPATH))

        try:
            send_button.click()
        except Exception:
            # بعض إصدارات واتساب ويب تمنع click العادي بسبب طبقة حركة مؤقتة.
            d.execute_script("arguments[0].click();", send_button)

        def outgoing_message_added(current_driver):
            try:
                return len(current_driver.find_elements(By.XPATH, _OUTGOING_MESSAGE_XPATH)) > before_count
            except StaleElementReferenceException:
                return False

        try:
            WebDriverWait(d, 8).until(outgoing_message_added)
            _last_confirmed_send_at = time.monotonic()
            return True
        except TimeoutException:
            # Some WhatsApp Web builds ignore a button click while rendering.
            # Press Enter once as a fallback, then require the same proof.
            try:
                d.switch_to.active_element.send_keys(Keys.ENTER)
            except Exception:
                send_button.send_keys(Keys.ENTER)
            try:
                WebDriverWait(d, 8).until(outgoing_message_added)
                _last_confirmed_send_at = time.monotonic()
                return True
            except TimeoutException:
                raise TimeoutException("لم يؤكد WhatsApp ظهور رسالة صادرة جديدة بعد الإرسال.")


def restore_chat_unread(d, state):
    """Restore only a chat known to be unread before this automation opened it."""
    if not state or not state.get("was_unread"):
        return False
    try:
        row = _find_chat_row(d, state.get("hints", ()))
        if row is None:
            print("[WHATSAPP] Could not find the original unread chat to restore it.")
            return False
        try:
            ActionChains(d).context_click(row).perform()
        except Exception:
            menu = row.find_element(By.XPATH, ".//*[contains(@aria-label, 'Menu') or contains(@aria-label, 'القائمة')]")
            d.execute_script("arguments[0].click();", menu)
        item = WebDriverWait(d, 5).until(EC.element_to_be_clickable((By.XPATH,
            "//*[contains(normalize-space(), 'Mark as unread') or contains(normalize-space(), 'وضع علامة كغير مقروءة')]")))
        d.execute_script("arguments[0].click();", item)
        print("[WHATSAPP] Restored the chat to unread after the confirmed send.")
        return True
    except Exception:
        # WhatsApp changes its UI frequently; failure here must never turn a
        # confirmed sent message into a failed delivery.
        print("[WHATSAPP] Could not restore unread state; the message send remains confirmed.")
        return False


def current_chat_is_unread(d):
    """Compatibility wrapper for callers that have not supplied a chat hint."""
    try:
        active = d.find_element(By.XPATH, "//*[@aria-selected='true']")
        return bool(active.find_elements(By.XPATH, ".//*[@data-icon='unread-count']"))
    except Exception:
        return False


def restore_current_chat_unread(d):
    """Compatibility wrapper; supported flows use capture/restore_chat_unread."""
    return restore_chat_unread(d, {"was_unread": True, "hints": ()})
