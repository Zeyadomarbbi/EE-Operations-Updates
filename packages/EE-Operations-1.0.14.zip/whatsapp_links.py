import tkinter.messagebox as msgbox
import pandas as pd
import random
import urllib.parse
import urllib.parse
import time
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from tkinter import filedialog, messagebox
import tkinter as tk

from web_driver import initialize_driver
from web_driver import wait_for_whatsapp_login
import config
import web_driver
from name_format import short_teacher_name


excel_file_links = None

def upload_exel_links(label):
    global excel_file_links
    file_path_links = filedialog.askopenfilename(title="اختر ملف البيانات", filetypes=[("Excel files", "*.xlsx;*.xls")])

    if file_path_links:
        try:
            df = pd.read_excel(file_path_links)  # قراءة الملف
            if "رقم الواتس" not in df.columns:
                messagebox.showerror("خطأ", "⚠️ الملف لا يحتوي على عمود باسم 'رقم الواتس'!")
                return  # إيقاف التنفيذ

            excel_file_links = file_path_links
            label.config(text="✅ تم رفع الملف بنجاح!", foreground="green")

        except Exception as e:
            messagebox.showerror("خطأ", f"حدث خطأ أثناء قراءة الملف: {e}")
    else:
        label.config(text="⚠️ لم يتم اختيار أي ملف!", foreground="red")


# def send_links(label_file, label, year_entry):
#
#     global excel_file_links
#     # ✅ التأكد من تحميل ملف الإكسل
#     if not excel_file_links:
#         msgbox.showerror("خطأ", "⚠️ لم يتم تحميل ملف الإكسل! الرجاء رفع الملف أولاً.")
#         #label_file.config(text="⚠️ لم يتم تحميل ملف الإكسل!", foreground="red")
#         return
#
#     # ✅ قراءة ملف الإكسل
#     try:
#         df = pd.read_excel(excel_file_links, dtype=str)  # تحميل القيم كنص لتجنب الأخطاء
#
#         # 🔹 تنظيف أسماء الأعمدة من المسافات الزائدة
#         df.columns = [col.strip().replace("\u200b", "") for col in df.columns]
#
#         # 🔹 التحقق من وجود العمود "الرابط"
#         if "الرابط" not in df.columns:
#             msgbox.showerror("خطأ", "⚠️ ملف الإكسل لا يحتوي على عمود 'الرابط'! الرجاء التأكد من صحة الملف.")
#             #label_file.config(text="⚠️ الملف لا يحتوي على العمود المطلوب!", foreground="red")
#             print("❌ خطأ: لم يتم العثور على عمود 'الرابط' في ملف الإكسل.")
#             print("📌 الأعمدة المتاحة:", df.columns.tolist())  # طباعة أسماء الأعمدة لتصحيح الأخطاء
#             return
#
#         # 🔹 التحقق مما إذا كان عمود "الرابط" يحتوي فقط على قيم فارغة
#         if df["الرابط"].isna().all() or df["الرابط"].eq("").all():
#             msgbox.showerror("خطأ", "⚠️ عمود 'الرابط' موجود لكنه فارغ تمامًا! الرجاء التأكد من صحة البيانات.")
#             #label_file.config(text="⚠️ العمود 'الرابط' لا يحتوي على أي بيانات!", foreground="red")
#             print("❌ خطأ: العمود 'الرابط' فارغ بالكامل.")
#             return
#
#     except Exception as e:
#         msgbox.showerror("خطأ", f"⚠️ خطأ أثناء قراءة ملف الإكسل: {str(e)}")
#         #label_file.config(text="⚠️ خطأ في قراءة ملف الإكسل!", foreground="red")
#         return
#
#     driver = initialize_driver()  # ✅ استخدم `initialize_driver()` بدلاً من `driver` مباشرة
#     if driver is None:
#         msgbox.showerror("خطأ", "⚠️ تعذر تشغيل المتصفح! تأكد من أن `msedgedriver.exe` موجود.")
#         return
#
#     driver.get(config.WHATSAPP_WEB_URL)
#     wait_for_whatsapp_login()
#     df = df[pd.notna(df['الرابط']) & df['الرابط'].str.strip().ne('')]
#
#     # تجميع البيانات لكل معلم مع دمج كلمات السر عند تكرار الرابط
#     grouped_data = df.groupby('اسم المعلم')
#     sent_messages_count = 0
#     failed_numbers = []  # قائمة لتخزين الأرقام التي فشل إرسال الرسائل إليها
#
#     # إرسال الرسائل لكل مدرس
#     for teacher, data in grouped_data:
#         try:
#             client_name = teacher.strip()
#
#             name_parts = client_name.split()
#             if name_parts[0] in ['أ.', 'د.', 'م.']:  # لو فيه لقب أ. أو د. أو م.
#                 if len(name_parts) > 1 and name_parts[1] in ['عبد', 'أبو']:
#                     first_name = f"{name_parts[1]} {name_parts[2]}"  # ياخد عبد الله مثلًا
#                 else:
#                     first_name = name_parts[1]  # ياخد الاسم اللي بعد اللقب مباشرة
#             elif name_parts[0] in ['عبد', 'أبو'] and len(name_parts) > 1:
#                 first_name = f"{name_parts[0]} {name_parts[1]}"  # ياخد عبد الله أو أبو بكر
#             else:
#                 first_name = name_parts[0]  # لو مش أي من دول، ياخد أول كلمة بس
#
#             message = f"السلام عليكم أ. {first_name}\n"
#             message += "اتفضل حضرتك الملفات على الرابط ده:\n"
#
#             link_passwords = {}
#             for index, row in data.iterrows():
#                 link = str(row['الرابط']).strip()
#                 client_code = str(row['كود العميل']).strip().zfill(5)
#                 year = year_entry.get().strip()
#                 password = f"{config.PASSWORD_PREFIX}{client_code}{year}"
#
#                 if link not in link_passwords:
#                     link_passwords[link] = password
#
#             for link, password in link_passwords.items():
#                 message += f"{link}\n"
#                 message += f"كلمة السر: {password}\n\n"
#
#             message += "ــــــــــــــــــــــــــــــــــــــ\n"
#             message += "ولو حضرتك مش معانا في الجروب الخاص يا ريت تنورنا:\n"
#             message += config.WHATSAPP_GROUP_INVITE_LINK
#
#             number = str(data.iloc[0]['رقم الواتس'].strip()).strip().split('.')[0]
#
#             # إذا لم يكن الرقم يحتوي على كود البلد، أضف +20
#             if number.startswith("0"):
#                 full_number = config.EGYPT_COUNTRY_CODE + number[1:]  # يستبدل الصفر الأول بكود مصر
#             elif not number.startswith("+"):
#                 full_number = config.EGYPT_COUNTRY_CODE + number  # يضيف كود مصر إذا لم يكن موجودًا
#             else:
#                 full_number = number  # إذا كان الرقم صحيحًا، يتركه كما هو
#
#             if not full_number[1:].isdigit():
#                 print(f"❌ الرقم غير صالح: {full_number}")
#                 failed_numbers.append(full_number)
#                 continue  # ⬅️ تخطي هذا الرقم
#
#             print(f"📞 الرقم بعد التعديل: {full_number}")
#
#             encoded_message = urllib.parse.quote(message)
#             whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"
#             driver.get(whatsapp_url)
#             print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")
#             time.sleep(10)  # ⏳ انتظار تحميل الصفحة
#
#             # ✅ **التحقق مما إذا كان الرقم غير مسجل على واتساب**
#
#             try:
#                 WebDriverWait(driver, 5).until(
#                     EC.presence_of_element_located((By.CLASS_NAME, "x12lqup9"))
#                     # 🔥 استهداف النافذة
#                 )
#                 print(f"🚫 الرقم {full_number} غير مسجل على واتساب، سيتم تخطيه.")
#                 failed_numbers.append(full_number)
#                 continue  # ⬅️ تخطي هذا الرقم
#
#             except TimeoutException:
#                 print(f"✅ الرقم {full_number} صالح على واتساب.")
#
#             # ✅ **البحث عن زر الإرسال**
#             send_button = None
#             for _ in range(5):
#                 try:
#                     send_button = driver.find_element(By.XPATH,
#                                                       "//button[contains(@aria-label, 'إرسال') or contains(@aria-label, 'Send')]")
#                     driver.execute_script("arguments[0].click();", send_button)
#                     sent_messages_count += 1
#                     time.sleep(random.randint(5, 15))
#                     break
#                 except:
#                     time.sleep(10)
#             else:
#                 failed_numbers.append(full_number)  # ✅ إضافة الرقم فقط إذا فشلت جميع المحاولات الخمس
#
#         # if send_button:
#             #     send_button.click()
#             #     print(f"✅ تم إرسال الرسالة إلى {full_number}")
#             # else:
#             #     print(f"⚠️ لم يتم العثور على زر الإرسال للرقم: {full_number}")
#
#             # تأخير عشوائي بين 5 و 15 ثانية لتجنب الحظر من واتساب
#
#
#         except Exception as e:
#             print(f"❌ فشل الإرسال للرقم: {full_number}. الخطأ: {str(e)}")
#
#     summary_text = f"📢 **ملخص الإرسال** 📢\n✅ تم إرسال {sent_messages_count} رسالة بنجاح.\n"
#
#     if failed_numbers:
#         summary_text += f"❌ لم يتم إرسال الرسائل إلى {len(failed_numbers)} رقم:\n"
#         summary_text += "\n".join([f"   - {num}" for num in failed_numbers])
#     else:
#         summary_text += "🎉 تم إرسال جميع الرسائل بنجاح! 🚀"
#
#     # ✅ تحديث النص بعد الإرسال
#     label.config(text=summary_text, foreground="green" if not failed_numbers else "red")

def send_links(label_file, label, year_entry):
    global excel_file_links

    # ✅ التأكد من تحميل ملف الإكسل
    if not excel_file_links:
        msgbox.showerror("خطأ", "⚠️ لم يتم تحميل ملف الإكسل! الرجاء رفع الملف أولاً.")
        return

    # ✅ قراءة ملف الإكسل
    try:
        df = pd.read_excel(excel_file_links, dtype=str)  # تحميل القيم كنص
        df.columns = [col.strip().replace("\u200b", "") for col in df.columns]  # تنظيف الأعمدة

        if "الرابط" not in df.columns:
            msgbox.showerror("خطأ", "⚠️ ملف الإكسل لا يحتوي على عمود 'الرابط'!")
            return

        if df["الرابط"].isna().all() or df["الرابط"].eq("").all():
            msgbox.showerror("خطأ", "⚠️ عمود 'الرابط' موجود لكنه فارغ تمامًا!")
            return

    except Exception as e:
        msgbox.showerror("خطأ", f"⚠️ خطأ أثناء قراءة ملف الإكسل: {str(e)}")
        return

    driver = initialize_driver()
    if driver is None:
        msgbox.showerror("خطأ", "⚠️ تعذر تشغيل المتصفح! تأكد من أن msedgedriver.exe موجود.")
        return

    driver.get(config.WHATSAPP_WEB_URL)
    wait_for_whatsapp_login()
    df = df[pd.notna(df['الرابط']) & df['الرابط'].str.strip().ne('')]

    grouped_data = df.groupby('اسم المعلم')
    sent_messages_count = 0
    failed_numbers = []

    for teacher, data in grouped_data:
        try:
            client_name = teacher.strip()
            name_parts = client_name.split()

            if name_parts[0] in ['أ.', 'د.', 'م.']:
                if len(name_parts) > 1 and name_parts[1] in ['عبد', 'أبو']:
                    first_name = f"{name_parts[1]} {name_parts[2]}"
                else:
                    first_name = name_parts[1]
            elif name_parts[0] in ['عبد', 'أبو'] and len(name_parts) > 1:
                first_name = f"{name_parts[0]} {name_parts[1]}"
            else:
                first_name = name_parts[0]

            message = f"السلام عليكم {short_teacher_name(teacher)}\n"
            message += "اتفضل حضرتك الملفات على الرابط ده:\n"

            link_passwords = {}
            for index, row in data.iterrows():
                link = str(row['الرابط']).strip()
                client_code = str(row['كود العميل']).strip().zfill(5)
                year = year_entry.get().strip()
                password = f"{config.PASSWORD_PREFIX}{client_code}{year}"
                if link not in link_passwords:
                    link_passwords[link] = password

            for link, password in link_passwords.items():
                message += f"{link}\n"
                message += f"كلمة السر: {password}\n\n"

            message += "ــــــــــــــــــــــــــــــــــــــ\n"
            message += "ولو حضرتك مش معانا في الجروب الخاص يا ريت تنورنا:\n"
            message += config.WHATSAPP_GROUP_INVITE_LINK

            number = str(data.iloc[0]['رقم الواتس'].strip()).split('.')[0]

            # ✅ تنسيق الرقم
            if number.startswith("0"):
                full_number = config.EGYPT_COUNTRY_CODE + number[1:]
            elif not number.startswith("+"):
                full_number = config.EGYPT_COUNTRY_CODE + number
            else:
                full_number = number

            if not full_number[1:].isdigit():
                print(f"❌ الرقم غير صالح: {full_number}")
                failed_numbers.append(full_number)
                continue

            print(f"📞 الرقم بعد التعديل: {full_number}")

            encoded_message = urllib.parse.quote(message)
            whatsapp_url = f"{config.WHATSAPP_SEND_URL_BASE}?phone={full_number}&text={encoded_message}"
            unread_state = web_driver.capture_chat_unread_state(driver, full_number, teacher)
            driver.get(whatsapp_url)
            print(f"🔍 محاولة فتح محادثة مع الرقم: {full_number}")

            try:
                web_driver.send_current_whatsapp_message(driver)
                web_driver.restore_chat_unread(driver, unread_state)
                sent_messages_count += 1
                print(f"✅ تم إرسال الرسالة إلى {full_number}")
            except TimeoutException:
                print(f"🚫 الرقم {full_number} غير مسجل على واتساب أو زر الإرسال غير متاح.")
                failed_numbers.append(full_number)
                continue

        except Exception as e:
            print(f"❌ فشل الإرسال للرقم: {full_number}. الخطأ: {str(e)}")

    summary_text = f"📢 **ملخص الإرسال** 📢\n✅ تم إرسال {sent_messages_count} رسالة بنجاح.\n"
    if failed_numbers:
        summary_text += f"❌ لم يتم إرسال الرسائل إلى {len(failed_numbers)} رقم:\n"
        summary_text += "\n".join([f"   - {num}" for num in failed_numbers])
    else:
        summary_text += "🎉 تم إرسال جميع الرسائل بنجاح! 🚀"

    label.config(text=summary_text, foreground="green" if not failed_numbers else "red")
