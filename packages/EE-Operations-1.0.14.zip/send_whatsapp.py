import os
import pandas as pd
import time
import subprocess
import urllib.parse
import pyautogui
import pyperclip
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime

import config
import web_driver
from name_format import render_teacher_name_placeholders, short_teacher_name
import settings

# نفس المجلد الرئيسي المحفوظ من أول استخدام للبرنامج (أو بيتسأل عنه لو أول مرة)
business_root_folder = settings.get_business_root_folder()

# اختيار فولدر الشغل (زي "شغل 2025") — بيتحدد بيه لاحقة باسورد حماية الملفات فقط
work_folders = settings.list_work_folders(business_root_folder)
if not work_folders:
    raise SystemExit("⚠️ لا توجد أي فولدرات جوه المجلد الرئيسي المختار.")

print("📁 فولدرات الشغل المتاحة:")
for i, name in enumerate(work_folders, 1):
    print(f"  {i}. {name}")
choice = int(input("اختر رقم فولدر الشغل (لحساب كلمة السر): ").strip())
work_folder_name = work_folders[choice - 1]
password_year_suffix = settings.get_password_year_suffix(work_folder_name) or ""

# اختيار ملف بيانات الرسائل يدويًا
_root = tk.Tk()
_root.withdraw()

messagebox.showwarning(
    "⚠️ شكل ملف البيانات المطلوب",
    "قبل ما تختار الملف، تأكد إنه ملف Excel فيه الأعمدة دي بالظبط:\n\n"
    "• رقم الواتساب  (أو رقم الهاتف)\n"
    "• اسم المعلم\n"
    "• كود العميل\n"
    "• الرابط  (اختياري)\n"
    "• الرسالة  (اختياري — لو فاضي هيتبعت نص افتراضي فيه كلمة السر والرابط)\n\n"
    "لو الملف ناقص عمود منهم أو الأعمدة مسمّاة غلط، الإرسال هيفشل أو هيبعت بيانات غلط."
)

default_dir = os.path.join(business_root_folder, work_folder_name, "رسائل واتساب")
file_path = filedialog.askopenfilename(
    title="اختر ملف بيانات رسائل واتساب",
    initialdir=default_dir if os.path.isdir(default_dir) else business_root_folder,
    filetypes=[("Excel files", "*.xlsx;*.xls")]
)
if not file_path:
    raise SystemExit("⚠️ لم يتم اختيار أي ملف.")

# قراءة ملف الإكسيل
df = pd.read_excel(file_path, dtype={'رقم الواتساب': str, 'رقم الهاتف': str})

# قوائم لحفظ نتائج الإرسال
sent_records = []
failed_records = []

def safe_get(value, default=""):
    """ضمان تحويل كل القيم إلى نصوص وتجنب الأخطاء عند التعامل مع الأرقام"""
    if pd.isna(value):
        return default
    return str(value).strip() if isinstance(value, str) else str(int(value))

def format_phone_number(number):
    """تنسيق الأرقام وإضافة كود الدولة تلقائيًا"""
    number = safe_get(number)
    if number.endswith(".0"): 
        number = number[:-2]
    if len(number) == 10 and number.startswith("1"):
        number = "0" + number
    if number.startswith("01") and len(number) == 11:
        return config.EGYPT_COUNTRY_CODE + number[1:]
    elif number.startswith("+"):
        return number
    return None  # إرجاع None إذا كان الرقم غير صالح

def extract_first_name(full_name):
    """Use the same one-name rule as every WhatsApp entry point."""
    return short_teacher_name(safe_get(full_name))

# التأكد من فتح واتساب بيتا قبل بدء الإرسال
with web_driver.driver_lock:
    driver = web_driver.ensure_whatsapp_ready()
if driver is None:
    raise SystemExit("تعذر تجهيز WhatsApp Web للإرسال المؤكد.")

for index, row in df.iterrows():
    try:
        whatsapp_number = format_phone_number(row.get('رقم الواتساب'))
        phone_number = format_phone_number(row.get('رقم الهاتف'))
        message_template = safe_get(row.get('الرسالة'))
        teacher_name = safe_get(row.get('اسم المعلم'))
        client_code = safe_get(row.get('كود العميل', '00000')).zfill(5)
        file_link = safe_get(row.get('الرابط'), 'رابط غير متوفر')
        
        teacher_first_name = extract_first_name(teacher_name)
        
        # الانتقال بين رقم الواتساب والهاتف بسلاسة
        formatted_number = whatsapp_number if whatsapp_number else phone_number
        if not formatted_number:
            print(f"❌ فشل الإرسال إلى {teacher_first_name}: لا يوجد رقم صالح")
            failed_records.append([None, teacher_first_name, "لا يوجد رقم صالح", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            continue
        
        print(f"🔄 جاري إرسال الرسالة إلى: {formatted_number}")
        
        if not message_template:
            message_template = f"السلام عليكم {teacher_first_name}\nاتفضل حضرتك الملفات على الرابط ده:\n{file_link}\nكلمة السر: {config.PASSWORD_PREFIX}{client_code}{password_year_suffix}\n\nلو حضرتك مش معانا في الجروب يا ريت تنورنا:\n{config.WHATSAPP_GROUP_INVITE_LINK}"

        # Keep both supported name placeholders on the shared short-name rule
        # even when the input sheet also has a raw "الاسم" column.
        message_template = render_teacher_name_placeholders(message_template, teacher_name)
        
        for col in df.columns:
            placeholder = f"{{{col}}}"
            if placeholder in message_template:
                value = safe_get(row.get(col))
                if col in {"اسم المعلم", "الاسم"}:
                    value = teacher_first_name
                message_template = message_template.replace(placeholder, value)
        
        if "{كلمة السر}" in message_template:
            message_template = message_template.replace("{كلمة السر}", f"{config.PASSWORD_PREFIX}{client_code}{password_year_suffix}")
        
        encoded_message = urllib.parse.quote(message_template, safe='')
        with web_driver.driver_lock:
            unread_state = web_driver.capture_chat_unread_state(
                driver, formatted_number, teacher_name
            )
            driver.get(f"{config.WHATSAPP_SEND_URL_BASE}?phone={formatted_number}&text={encoded_message}")
            web_driver.send_current_whatsapp_message(driver)
            web_driver.restore_chat_unread(driver, unread_state)
        
        print(f"✅ تم الإرسال إلى {formatted_number}")
        sent_records.append([formatted_number, teacher_first_name, message_template, datetime.now().strftime("%Y-%m-%d %H:%M:%S")])

    except Exception as e:
        failed_records.append([formatted_number, teacher_first_name, str(e), datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
        print(f"❌ فشل الإرسال إلى {formatted_number}: {str(e)}")
        continue  # الانتقال للرقم التالي
