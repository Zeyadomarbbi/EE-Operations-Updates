import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import update_service


class UpdateRestartTests(unittest.TestCase):
    def test_updater_stops_only_the_application_pid_before_restarting(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            temporary_path = Path(temporary_directory)
            package = temporary_path / "update.zip"
            with zipfile.ZipFile(package, "w") as archive:
                archive.writestr("release/version.py", 'APP_VERSION = "test"')

            with patch("update_service.subprocess.Popen") as popen:
                update_service.schedule_install(package, temporary_path / "app", app_pid=12345)

            script_path = Path(popen.call_args.args[0][2])
            script = script_path.read_text(encoding="ascii")

        self.assertIn("taskkill /PID 12345 /F", script)
        self.assertNotIn("taskkill /PID 12345 /F /T", script)
        self.assertIn("timeout /t 3 /nobreak", script)
        self.assertIn('start "" wscript.exe', script)


if __name__ == "__main__":
    unittest.main()
