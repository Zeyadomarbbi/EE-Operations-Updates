"""Delivery-only retry for locally completed normal and logo orders."""

import concurrent.futures
import os
import shutil
import sys
import tempfile
import threading
import time
import urllib.parse

import pandas as pd

import config
import drive
import settings
import upload_files
import web_driver
import run_history


def _phone(value):
    number = str(value).strip().split(".")[0]
    if number.startswith("0"):
        number = config.EGYPT_COUNTRY_CODE + number[1:]
    elif not number.startswith("+"):
        number = config.EGYPT_COUNTRY_CODE + number
    if not number[1:].isdigit():
        raise ValueError(f"رقم واتساب غير صالح: {number}")
    return number


def _atomic_write(data, excel_path):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as temporary_file:
        temporary_path = temporary_file.name
    data.to_excel(temporary_path, index=False)
    shutil.move(temporary_path, excel_path)


def send_teacher_message(teacher_name, teacher_rows, work_folder_name):
    """WhatsApp is always serial and accepted only after the composer clears."""
    phone = _phone(teacher_rows.iloc[0]["رقم الواتس"])
    message = upload_files.build_teacher_whatsapp_message(teacher_name, teacher_rows, work_folder_name, False)
    with web_driver.driver_lock:
        driver = web_driver.ensure_whatsapp_ready()
        if driver is None:
            raise RuntimeError("تعذر تشغيل WhatsApp Web")
        driver.get(f"{config.WHATSAPP_SEND_URL_BASE}?phone={phone}&text={urllib.parse.quote(message)}")
        was_unread = web_driver.current_chat_is_unread(driver)
        web_driver.send_current_whatsapp_message(driver)
        if was_unread:
            web_driver.restore_current_chat_unread(driver)
    time.sleep(settings.get_whatsapp_delay_seconds())


def _row_keys(data):
    columns = [column for column in data.columns if column not in {"الرابط", "_retry_key"}]
    return [tuple("" if pd.isna(value) else str(value).strip() for value in row)
            for row in data[columns].itertuples(index=False, name=None)]


def main(excel_path, business_root_folder, work_folder_name, mode="normal", progress_callback=None, upload_workers=1, run_id=None):
    """Rescan the sheet while active; newly saved rows join later retry batches."""
    upload_workers = max(1, int(upload_workers))
    upload_function = drive.upload_order_files_logo if mode == "logo" else drive.upload_order_files
    output_subdir = settings.get_logo_orders_subdir() if mode == "logo" else settings.get_orders_subdir()
    known_keys, idle_scans = set(), 0
    state_lock = threading.Lock()

    while True:
        data = upload_files.prepare_delivery_data(pd.read_excel(excel_path))
        upload_files.validate_delivery_data(data)
        if "الرابط" not in data.columns:
            data["الرابط"] = None
        data["الرابط"] = data["الرابط"].astype("object")
        data["_retry_key"] = _row_keys(data)
        new_rows = data[~data["_retry_key"].isin(known_keys)].drop(columns=["_retry_key"])
        if new_rows.empty:
            idle_scans += 1
            if idle_scans >= 3:
                break
            if run_id:
                run_history.update(run_id, stage="Waiting briefly for newly added retry rows")
            time.sleep(5)
            continue
        idle_scans = 0
        known_keys.update(data["_retry_key"])

        pending = []
        for client_code, rows in new_rows.groupby("كود العميل", sort=False):
            order_codes = [str(value).strip() for value in rows["كود الطلب"].dropna().unique()]
            folder_name = "_".join(order_codes)
            local_folder = os.path.join(business_root_folder, work_folder_name, output_subdir, folder_name)
            if not os.path.isdir(local_folder) or not any(
                name.lower().endswith(".pdf") for _root, _dirs, files in os.walk(local_folder) for name in files
            ):
                print(f"[RETRY] Local PDFs missing | order {folder_name}")
                continue
            pending.append((client_code, rows.copy(), folder_name))

        total = len(pending)
        if not total:
            continue
        if run_id:
            run_history.add_detail(run_id, f"Retry batch: {total} orders, Drive workers={upload_workers}")
        if progress_callback:
            progress_callback(0, total, f"إعادة رفع {total} طلبات ({'متوازي' if upload_workers > 1 else 'متوالي'})")

        def upload_one(client_code, rows, folder_name):
            upload_files.wait_if_paused("retry", run_id)
            raw = rows["فتح الملف"].iloc[0]
            share_value = str(raw).strip() if pd.notna(raw) else ""
            if run_id:
                run_history.add_detail(run_id, f"Drive upload started | order {folder_name}")
            link = upload_function(client_code, folder_name, business_root_folder, work_folder_name, share_value)
            return client_code, rows, folder_name, link

        completed = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=upload_workers) as executor:
            futures = {executor.submit(upload_one, *item): item for item in pending}
            for future in concurrent.futures.as_completed(futures):
                fallback = futures[future]
                try:
                    client_code, rows, folder_name, link = future.result()
                    if not link:
                        raise RuntimeError("Drive did not confirm the uploaded order")
                    with state_lock:
                        data.loc[rows.index, "الرابط"] = link
                    if run_id:
                        run_history.add_detail(run_id, f"Drive verified | order {folder_name}")
                    # Uploads may be parallel, but this loop serializes WhatsApp and sends
                    # immediately after each verified order rather than after the whole batch.
                    teacher = str(rows.iloc[0]["اسم المعلم"]).strip()
                    if run_id:
                        run_history.update(run_id, stage=f"Sending WhatsApp | order {folder_name}")
                        run_history.add_detail(run_id, f"WhatsApp sending | order {folder_name}")
                    send_teacher_message(teacher, rows.assign(الرابط=link), work_folder_name)
                    if run_id:
                        run_history.add_detail(run_id, f"WhatsApp confirmed | order {folder_name}")
                except Exception as exc:
                    folder_name = fallback[2]
                    print(f"[RETRY] Failed | order {folder_name}: {exc}")
                    if run_id:
                        run_history.add_detail(run_id, f"Retry failed | order {folder_name}: {exc}")
                finally:
                    completed += 1
                    if progress_callback:
                        progress_callback(completed, total, f"إعادة الرفع: {completed} من {total}")

        _atomic_write(data.drop(columns=["_retry_key"], errors="ignore"), excel_path)


def run_saved_delivery(run_id, progress_callback=None, upload_workers=1):
    run = run_history.get(run_id)
    if not run:
        raise ValueError("لم يتم العثور على سجل التشغيل.")
    if not os.path.exists(run["snapshot"]):
        raise FileNotFoundError("ملف Excel المحفوظ للتشغيل غير موجود.")
    run_history.update(run_id, status="retrying", stage="Delivery retry")
    try:
        main(run["snapshot"], run["business_root"], run["work_folder"], run["mode"], progress_callback, upload_workers, run_id)
        run_history.update(run_id, status="completed", stage="Drive and WhatsApp completed")
    except Exception as exc:
        run_history.update(run_id, status="failed", stage="Delivery retry failed", details=str(exc))
        raise


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("Usage: retry_delivery_only.py <excel_path> <business_root_folder> <work_folder_name>")
    main(*sys.argv[1:])
